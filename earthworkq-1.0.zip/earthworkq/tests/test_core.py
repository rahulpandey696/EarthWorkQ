# -*- coding: utf-8 -*-
"""
Regression tests for the parts of EarthWorkQ that do not need QGIS.

The volume tests use surfaces whose exact volume is known in closed form, so
the assertions have real authority rather than merely locking in whatever the
code happened to produce.  Run them with:

    python -m pytest tests/test_core.py      (from the plugin folder)
    python tests/test_core.py                (no pytest required)
"""

from __future__ import annotations

import math
import os
import sys
import unittest

import numpy as np

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from core import balance as balance_mod           # noqa: E402
from core import volume as vol_mod                # noqa: E402
from core.soil import (                            # noqa: E402
    SoilModel,
    SoilParameterError,
    dry_density_from_void_ratio,
    void_ratio_from_dry_density,
)


# ----------------------------------------------------------------------
class TestSoilModel(unittest.TestCase):

    def test_shrinkage_factor_from_void_ratios(self):
        soil = SoilModel(e_insitu=0.80, e_compacted=0.55)
        self.assertAlmostEqual(soil.shrinkage_factor, 1.80 / 1.55, places=9)

    def test_solids_are_conserved(self):
        """The defining property: cut and fill hold the same solids volume."""
        soil = SoilModel(e_insitu=0.75, e_compacted=0.55)
        v_fill = 1000.0
        v_cut = soil.cut_for_fill(v_fill)
        self.assertAlmostEqual(v_cut / (1 + soil.e_insitu),
                               v_fill / (1 + soil.e_compacted), places=6)

    def test_density_round_trip(self):
        e = 0.68
        gs = 2.67
        rho = dry_density_from_void_ratio(e, gs)
        self.assertAlmostEqual(void_ratio_from_dry_density(rho, gs), e, places=9)

    def test_from_compaction_spec(self):
        soil = SoilModel.from_compaction_spec(
            rho_d_insitu=1.55, max_dry_density=1.85,
            compaction_fraction=0.95, gs=2.65)
        self.assertAlmostEqual(
            dry_density_from_void_ratio(soil.e_compacted, 2.65),
            1.85 * 0.95, places=6)
        self.assertGreater(soil.shrinkage_factor, 1.0)

    def test_impossible_saturation_is_rejected(self):
        with self.assertRaises(SoilParameterError):
            SoilModel(e_insitu=0.40, e_compacted=0.35, gs=2.65, w_natural=0.30)

    def test_rock_swells_rather_than_shrinks(self):
        soil = SoilModel(e_insitu=0.30, e_compacted=0.40, gs=2.70)
        self.assertLess(soil.shrinkage_factor, 1.0)

    def test_conditioning_water_direction(self):
        soil = SoilModel(e_insitu=0.75, e_compacted=0.55, gs=2.65,
                         w_natural=0.08, w_target=0.14)
        water = soil.conditioning_water(1000.0)
        self.assertGreater(water, 0.0)
        dry_soil = SoilModel(e_insitu=0.75, e_compacted=0.55, gs=2.65,
                             w_natural=0.18, w_target=0.14)
        self.assertLess(dry_soil.conditioning_water(1000.0), 0.0)


# ----------------------------------------------------------------------
def _plane_grid(n, cell, slope=0.02):
    """Ground plane z = slope * x over an n x n grid of unit weight."""
    xs = (np.arange(n) + 0.5) * cell
    ground = np.tile(slope * xs, (n, 1))
    weight = np.ones((n, n))
    return ground, weight


class TestGridIntegration(unittest.TestCase):

    def test_tilted_plane_against_closed_form(self):
        """Cut over a tilted plane below a level equals a known triangle prism."""
        n, cell, slope = 200, 0.5, 0.02
        ground, weight = _plane_grid(n, cell, slope)
        length = n * cell
        level = slope * length / 2.0        # halfway up the slope
        depth = level - ground
        res = vol_mod.integrate(depth, weight, cell * cell)

        # exact: two triangular prisms of equal size
        half = length / 2.0
        exact = 0.5 * half * (slope * half) * length
        self.assertAlmostEqual(res.fill / exact, 1.0, places=3)
        self.assertAlmostEqual(res.cut / exact, 1.0, places=3)
        self.assertAlmostEqual(res.net, 0.0, delta=exact * 1e-3)

    def test_cone_volume_converges(self):
        """A cone of known volume is recovered as the grid is refined."""
        radius, height = 40.0, 8.0
        exact = math.pi * radius ** 2 * height / 3.0

        errors = []
        for cell in (2.0, 1.0, 0.5):
            n = int(2 * radius / cell)
            xs = (np.arange(n) + 0.5) * cell - radius
            gx, gy = np.meshgrid(xs, xs)
            r = np.sqrt(gx ** 2 + gy ** 2)
            ground = np.where(r <= radius, height * (1 - r / radius), 0.0)
            weight = np.ones_like(ground)
            depth = 0.0 - ground            # design at zero, all cut
            res = vol_mod.integrate(depth, weight, cell * cell)
            errors.append(abs(res.cut - exact) / exact)

        self.assertLess(errors[-1], 0.005)
        self.assertLess(errors[-1], errors[0])

    def test_fractional_weights_change_the_answer(self):
        ground = np.zeros((10, 10))
        depth = np.full((10, 10), 2.0)
        full = vol_mod.integrate(depth, np.ones((10, 10)), 1.0)
        half = vol_mod.integrate(depth, np.full((10, 10), 0.5), 1.0)
        self.assertAlmostEqual(half.fill, full.fill / 2.0, places=9)
        self.assertAlmostEqual(half.area, full.area / 2.0, places=9)

    def test_nodata_is_excluded_and_reported(self):
        depth = np.full((10, 10), 1.0)
        depth[0, :] = np.nan
        res = vol_mod.integrate(depth, np.ones((10, 10)), 1.0)
        self.assertAlmostEqual(res.fill, 90.0, places=9)
        self.assertAlmostEqual(res.nodata_area, 10.0, places=9)


# ----------------------------------------------------------------------
class TestBalance(unittest.TestCase):

    def test_flat_sweep_matches_direct_integration(self):
        rng = np.random.default_rng(3)
        ground = rng.normal(10.0, 2.0, (60, 60))
        weight = rng.uniform(0.2, 1.0, (60, 60))
        cell_area = 4.0
        sweeper = balance_mod.FlatLevelSweeper(ground, weight, cell_area)

        for level in (6.0, 9.5, 12.0):
            cut, fill = sweeper.cut_fill(level)
            direct = vol_mod.integrate(level - ground, weight, cell_area)
            self.assertAlmostEqual(cut, direct.cut, places=6)
            self.assertAlmostEqual(fill, direct.fill, places=6)

    def test_balance_level_is_exact_for_a_symmetric_surface(self):
        """A tilted plane balances exactly at its mean elevation."""
        ground, weight = _plane_grid(100, 1.0, slope=0.05)
        sweeper = balance_mod.FlatLevelSweeper(ground, weight, 1.0)
        level = sweeper.solve_balance(1.0)
        self.assertAlmostEqual(level, ground.mean(), places=4)

    def test_shrinkage_lowers_the_balance_level(self):
        """Needing more cut than fill means digging deeper: the level drops."""
        ground, weight = _plane_grid(100, 1.0, slope=0.05)
        sweeper = balance_mod.FlatLevelSweeper(ground, weight, 1.0)
        plain = sweeper.solve_balance(1.0)
        with_shrinkage = sweeper.solve_balance(1.25)
        self.assertLess(with_shrinkage, plain)

    def test_curve_balance_matches_the_solver(self):
        ground, weight = _plane_grid(80, 1.0, slope=0.04)
        curve, sweeper = balance_mod.sweep_levels(ground, weight, 1.0,
                                                  n_steps=400,
                                                  shrinkage_factor=1.15)
        self.assertAlmostEqual(curve.balance_level(),
                               sweeper.solve_balance(1.15), places=2)

    def test_no_balance_when_design_is_above_everything(self):
        ground = np.zeros((20, 20))
        weight = np.ones((20, 20))
        sweeper = balance_mod.FlatLevelSweeper(ground, weight, 1.0)
        cut, fill = sweeper.cut_fill(5.0)
        self.assertAlmostEqual(cut, 0.0, places=9)
        self.assertAlmostEqual(fill, 20 * 20 * 5.0, places=6)


# ----------------------------------------------------------------------
class TestTinIntegration(unittest.TestCase):

    def setUp(self):
        try:
            import scipy  # noqa: F401
        except ImportError:
            self.skipTest("SciPy is not installed")

    def test_tin_matches_a_tilted_plane(self):
        from core.design import FlatLevel
        rng = np.random.default_rng(11)
        n = 900
        x = rng.uniform(0, 100, n)
        y = rng.uniform(0, 100, n)
        slope = 0.03
        z = slope * x
        # include the corners so the hull covers the full square
        x = np.concatenate([x, [0, 100, 0, 100]])
        y = np.concatenate([y, [0, 0, 100, 100]])
        z = np.concatenate([z, [0, slope * 100, 0, slope * 100]])

        level = slope * 50.0
        res = vol_mod.tin_volume(x, y, z, FlatLevel(level))
        self.assertIsNotNone(res)
        exact = 0.5 * 50.0 * (slope * 50.0) * 100.0
        self.assertAlmostEqual(res.cut / exact, 1.0, places=4)
        self.assertAlmostEqual(res.fill / exact, 1.0, places=4)

    def test_tin_agrees_with_grid_on_a_paraboloid(self):
        from core.design import FlatLevel
        rng = np.random.default_rng(5)
        n = 20000
        x = rng.uniform(-50, 50, n)
        y = rng.uniform(-50, 50, n)
        z = 10.0 - (x ** 2 + y ** 2) / 500.0
        x = np.concatenate([x, [-50, 50, -50, 50]])
        y = np.concatenate([y, [-50, -50, 50, 50]])
        z = np.concatenate([z, [10 - 5000 / 500.0] * 4])

        level = 5.0
        tin = vol_mod.tin_volume(x, y, z, FlatLevel(level))

        cell = 0.5
        xs = np.arange(-50 + cell / 2, 50, cell)
        gx, gy = np.meshgrid(xs, xs)
        ground = 10.0 - (gx ** 2 + gy ** 2) / 500.0
        grid_res = vol_mod.integrate(level - ground, np.ones_like(ground),
                                     cell * cell)

        # A linear TIN chords a curved surface, so exact agreement is not
        # expected - only agreement to within the facet discretisation error.
        self.assertLess(abs(tin.cut - grid_res.cut) / grid_res.cut, 0.01)
        self.assertLess(abs(tin.fill - grid_res.fill) / grid_res.fill, 0.01)


# ----------------------------------------------------------------------
class TestInterpolationEngines(unittest.TestCase):

    def setUp(self):
        try:
            import scipy  # noqa: F401
        except ImportError:
            self.skipTest("SciPy is not installed")
        rng = np.random.default_rng(7)
        self.x = rng.uniform(0, 100, 700)
        self.y = rng.uniform(0, 100, 700)
        self.z = (0.02 * self.x + 0.01 * self.y
                  + 2.0 * np.sin(self.x / 18.0) * np.cos(self.y / 22.0))

    def test_exact_engines_reproduce_their_own_points(self):
        from core.interpolation import CloughTocherEngine, LinearTinEngine
        for cls in (LinearTinEngine, CloughTocherEngine):
            eng = cls().fit(self.x, self.y, self.z)
            pred = eng.evaluate(self.x, self.y)
            ok = np.isfinite(pred)
            self.assertTrue(ok.sum() > 0.9 * self.x.size)
            self.assertLess(np.max(np.abs(pred[ok] - self.z[ok])), 1e-6,
                            "%s is not an exact interpolator" % cls.id)

    def test_no_extrapolation_outside_the_hull(self):
        from core.interpolation import LinearTinEngine
        eng = LinearTinEngine().fit(self.x, self.y, self.z)
        far = eng.evaluate(np.array([500.0]), np.array([500.0]))
        self.assertTrue(np.all(~np.isfinite(far)))

    def test_cross_validation_reports_sensible_error(self):
        from core.interpolation import CloughTocherEngine
        stats = CloughTocherEngine().cross_validate(self.x, self.y, self.z,
                                                    folds=5)
        self.assertIsNotNone(stats)
        self.assertGreater(stats["rmse"], 0.0)
        self.assertLess(stats["rmse"], 2.0)

    def test_idw_cannot_exceed_its_neighbours(self):
        """The known weakness, asserted so it never silently changes."""
        from core.interpolation import IdwEngine
        eng = IdwEngine(power=2.0, neighbours=8).fit(self.x, self.y, self.z)
        gx, gy = np.meshgrid(np.linspace(10, 90, 60), np.linspace(10, 90, 60))
        pred = eng.evaluate(gx, gy)
        self.assertLessEqual(np.nanmax(pred), self.z.max() + 1e-9)
        self.assertGreaterEqual(np.nanmin(pred), self.z.min() - 1e-9)


if __name__ == "__main__":
    unittest.main(verbosity=2)
