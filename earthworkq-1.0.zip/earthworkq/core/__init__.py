# -*- coding: utf-8 -*-
"""Engineering core of EarthWorkQ - no Qt user interface code lives here."""
