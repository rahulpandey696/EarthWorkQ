# -*- coding: utf-8 -*-
"""User interface for EarthWorkQ."""
