# FMB tools (QGIS plugin)

Build, check and run **TUFLOW Classic/HPC** models from QGIS — no external text editor needed.

> Independent open-source project (GPL-2.0-or-later). Not developed, endorsed or supported by BMT or the
> TUFLOW team. TUFLOW is a trademark of BMT. A TUFLOW licence (or the free demo mode) is needed to run
> simulations.

## Features

| Tab | What it does |
|---|---|
| **Project** | Radio-button quick set-up of a new model (solver, hardware, units, GIS format, hydrology input) (standard folders, TCF/TGC/TBC, optional ECF/QCF/TEF, `bc_dbase.csv`, `materials.csv`), grid size/origin from a layer extent, or open an existing `.tcf` (all referenced control files are discovered). |
| **Empty layers** | Create TUFLOW empty GIS layers (one GeoPackage, GeoPackage per layer, or Shapefiles) named `<type>_<name>[_<descriptor>]_<P|L|R>`. Tick list grouped by control file with P/L/R geometry ticks and presets (2D base model, direct rainfall, 1D/2D culverts, open channel, bridges, quadtree …). Each layer shows what to draw and, for every field, its type, Shapefile (10-character) name, what to enter (from the TUFLOW manual) and a default-value editor — 2d_mat offers the material IDs of materials.csv; the layers open in QGIS grouped, with those defaults and dropdowns (saved as the layer's default style), and the matching `Read GIS` commands are added to the control files. Built-in structures were cross-checked against real TUFLOW layers; any other type is copied exactly from TUFLOW's own empty files (point to the folder or click *Write with TUFLOW*, which runs `Write Empty GIS Files`). |
| **TCF, TGC, TBC, ECF, TEF** | One editor per control file. Command browser with a guided *Essentials* list (required / recommended), each command with a brief plain-language explanation shown underneath, and **all 696 commands of the TUFLOW Classic/HPC manual 2026.3, Appendices A–K**, grouped by topic (e.g. TCF: control files, solver, time, SGS, HPC options, boundaries, 1D/2D linking, map output, time series, GIS …) with *Expand all* / *Collapse all*, an A–Z view and search. The TEF editor also offers every TCF and ECF command, as the manual allows. Values use the right widget: radio buttons for short option sets (ON/OFF, CPU/GPU, METHOD A/B), dropdowns for longer lists, number boxes with units and a *not set* state, X/Y pair boxes (Origin, Grid Size, Zpt Range Check…), keyword + value choices (e.g. `AUTO` or a number), file/folder pickers, QGIS-layer pickers (GeoPackage `>>` syntax handled), checkable pickers for map output types/formats, and dropdowns filled from the model (scenarios, events, BC database names, material IDs). An `abc` toggle keeps `<<variables>>` and `~s1~` tokens as text. Modifiers (e.g. `Read GIS Z Shape RIDGE`) are dropdowns. Live syntax-highlighted preview, optional direct text editing, If Scenario / If Event wrapping, comment-out, reorder, per-command manual link. |
| **Other files** | QCF, TRFC, TOC, TESF, TSCF, ADCF editors (created and linked on demand). |
| **TEF** | Event generator that writes `Define Event` / `BC Event Source` / `End Define` blocks. |
| **Databases** | Table editor for bc_dbase, materials and time-series CSVs; source-file check; quick plot. |
| **Batch & Run** | `.bat` / `.sh` builder: tick scenarios and events found in the model, all `-s1..-s9` / `-e1..-e9` slots, single/double precision, run mode and script type as radio buttons, test mode, GPU ids; run the queue from QGIS with live console output. |
| **QC** | Pre-run checks: required commands, missing files and GeoPackage layers, If/Define block balance, unknown commands, solver/hardware conflicts, Classic timestep vs cell size, wet/dry depth for direct rainfall, material IDs, BC database sources (with event substitution), events vs TEF, outputs. Loads TUFLOW check files into QGIS. |
| **Logs** | `.tlf` / `.hpc.tlf` viewer with ERROR/WARNING/CHECK highlighting and navigation, messages table linked to the wiki message pages and to map locations, simulations register. |
| **Stability** | Stability flags (status, errors, NaNs, negative depths, peak cumulative mass error, repeated timesteps, timestep drops, HPC control numbers), charts (mass error, HPC dt, Nu/Nc/Nd, PO time series), load result grids into QGIS. |
| **Outputs** | Every output of a simulation in one tick list — maximum/summary grids, time-step grids, XMDF / NetCDF / DAT mesh results, plot output and 1D result GIS layers, CSV time series, check files and the messages layer. *Load ticked* adds them to *Results / <simulation>* in the layer panel with TUFLOW-style symbology: fixed flood-mapping classes for depth, velocity, Z0 and AEM hazard (H1–H6), stretched colours for water level and other grids, the same colours per mesh dataset, and the official TUFLOW plugin's .qml styles for check files and plot output when that plugin is installed. Depth cut-off and opacity options. |
| **Help** | Each control file explained, an *Essentials guide* with a brief explanation of every guided command (syntax, default, tips, manual link), and every manual chapter and appendix, tutorial, message database page, check-file page and tip with a short note on what it covers — searchable by title or explanation. |

The bottom bar has **New Project**, **Reset All**, **Close Project** and **Save** (unsaved edits are always offered for saving first).

## Install

QGIS → *Plugins → Manage and Install Plugins → Install from ZIP* → select `fmb_tools.zip`.
Then *Plugins → FMB tools*, or the toolbar button. Requires QGIS 3.22+ (Qt6/QGIS 4 ready).

## Notes

* Control files are written with Windows paths relative to each control file, aligned `==`, CRLF endings.
* Unknown lines, comments and blocks in existing files are preserved.
* Command names/syntax come from the manual's command index (`core/catalog_data.py`); explanations are
  always opened from the official manual so they stay current. Update `catalog_data.py` for new releases.
* QC thresholds (mass error ±1 %, Classic Δt ≈ ¼–½ of the cell size in metres, 0.0002 m wet/dry depth for
  rainfall) follow the TUFLOW manual guidance.

## Development

```
python -m pytest tests          # core tests (no QGIS needed)
```
