# -*- coding: utf-8 -*-
"""
'Empty layers' tab: create TUFLOW empty GIS layers (GeoPackage or Shapefile)
with the attribute structure TUFLOW expects, a drawing guide for each layer,
default attribute values and dropdowns set up in QGIS, and the matching
Read GIS commands added to the control files.
"""
import os

from qgis.PyQt.QtCore import Qt, pyqtSignal, QProcess
from qgis.PyQt.QtGui import QBrush, QColor
from qgis.PyQt.QtWidgets import (QWidget, QVBoxLayout, QHBoxLayout, QGridLayout, QGroupBox, QLabel, QLineEdit,
                                 QPushButton, QCheckBox, QSplitter, QTreeWidget, QTreeWidgetItem, QTableWidget,
                                 QTableWidgetItem, QHeaderView, QTextBrowser, QMessageBox, QPlainTextEdit,
                                 QAbstractItemView)

from ..core import empty_layers as EL
from ..core.catalog import FILE_TYPE_INFO
from ..core.control_file import resolve_path
from . import qgis_utils as qu
from .widgets import PathEdit, RadioChoice, ChoiceEdit, bold_font, mono_font

GEOM_COLS = {"P": 1, "L": 2, "R": 3}
FORMATS = ["One GeoPackage", "GeoPackage per layer", "Shapefiles"]
FMT_KEY = {FORMATS[0]: "gpkg", FORMATS[1]: "gpkg_each", FORMATS[2]: "shp"}
SOURCES = ["Built-in structures", "TUFLOW empties folder"]
ROLE_CODE = Qt.ItemDataRole.UserRole


class EmptyLayersTab(QWidget):
    commandsReady = pyqtSignal(list)          # [(ftype, lhs, value)]

    def __init__(self, context, parent=None):
        super().__init__(parent)
        self.ctx = context
        self.defaults = {}        # code -> {field name: value}
        self.descriptors = {}     # code -> extra name part
        self.empties = {}         # scan of the TUFLOW empties folder
        self._building = False
        self._proc = None
        self._build()
        self.apply_preset("2D base model")

    # ================================================================ UI
    def _build(self):
        lay = QVBoxLayout(self)
        g = QGroupBox("Output")
        gl = QGridLayout(g)
        gl.addWidget(QLabel("Format"), 0, 0)
        self.fmt = RadioChoice(FORMATS)
        self.fmt.setValue(FORMATS[0])
        self.fmt.setToolTip("One GeoPackage: all layers in one database (use it as the TCF Spatial Database).\n"
                            "GeoPackage per layer / Shapefiles: one file per layer.")
        self.fmt.changed.connect(self._format_changed)
        gl.addWidget(self.fmt, 0, 1, 1, 3)
        gl.addWidget(QLabel("Save to"), 1, 0)
        self.target = PathEdit("gis_out", "GeoPackage (*.gpkg)", lambda: "")
        self.target.line.setPlaceholderText("GeoPackage file, e.g. model\\gis\\M01_001.gpkg")
        self.target.changed.connect(lambda _v: self._update_names())
        gl.addWidget(self.target, 1, 1, 1, 3)
        gl.addWidget(QLabel("Name part"), 2, 0)
        self.stem = QLineEdit("M01_001")
        self.stem.setToolTip("Layer names are  <type>_<name part>[_<descriptor>]_<P|L|R>, e.g. 2d_code_M01_001_R")
        self.stem.textChanged.connect(lambda _t: self._update_names())
        gl.addWidget(self.stem, 2, 1)
        gl.addWidget(QLabel("CRS"), 2, 2)
        self.crs = self._crs_widget()
        gl.addWidget(self.crs, 2, 3)
        gl.addWidget(QLabel("Attribute structures"), 3, 0)
        self.source = RadioChoice(SOURCES)
        self.source.setValue(SOURCES[0])
        self.source.setToolTip("Built-in: structures checked against TUFLOW's own layers.\n"
                               "TUFLOW empties folder: copy the exact structure of TUFLOW's empty files "
                               "(needed for layer types marked 'TUFLOW empties').")
        self.source.changed.connect(lambda _v: self._source_changed())
        gl.addWidget(self.source, 3, 1)
        row = QHBoxLayout()
        self.empty_dir = PathEdit("folder", "", lambda: "")
        self.empty_dir.line.setPlaceholderText("folder with TUFLOW empty files, e.g. model\\gis\\empty")
        self.empty_dir.changed.connect(lambda _v: self._scan_empties())
        row.addWidget(self.empty_dir, 1)
        b = QPushButton("Write with TUFLOW...")
        b.setToolTip("Run TUFLOW once with 'Write Empty GIS Files' to get its own empty files")
        b.clicked.connect(self.write_with_tuflow)
        row.addWidget(b)
        gl.addLayout(row, 3, 2, 1, 2)
        gl.setColumnStretch(1, 1)
        gl.setColumnStretch(3, 1)
        lay.addWidget(g)

        split = QSplitter(Qt.Orientation.Horizontal)
        lay.addWidget(split, 1)

        left = QWidget()
        ll = QVBoxLayout(left)
        ll.setContentsMargins(0, 0, 0, 0)
        top = QHBoxLayout()
        top.addWidget(QLabel("Preset"))
        self.preset = ChoiceEdit(list(EL.PRESETS))
        self.preset.setToolTip("Tick the layers a typical model of this kind needs (adds to the current ticks)")
        top.addWidget(self.preset, 1)
        pb = QPushButton("Tick preset")
        pb.clicked.connect(lambda: self.apply_preset(self.preset.value(), clear=False))
        top.addWidget(pb)
        cb = QPushButton("Clear")
        cb.clicked.connect(self.clear_ticks)
        top.addWidget(cb)
        self.search = QLineEdit()
        self.search.setPlaceholderText("Filter...")
        self.search.textChanged.connect(self._filter)
        top.addWidget(self.search, 1)
        ll.addLayout(top)
        self.tree = QTreeWidget()
        self.tree.setHeaderLabels(["Layer type", "P", "L", "R", "Layer name(s)", "Read by"])
        hh = self.tree.header()
        hh.setSectionResizeMode(0, QHeaderView.ResizeMode.Interactive)
        for c in (1, 2, 3):
            hh.setSectionResizeMode(c, QHeaderView.ResizeMode.Fixed)
            self.tree.setColumnWidth(c, 34)
        self.tree.setColumnWidth(0, 300)
        self.tree.setColumnWidth(4, 230)
        self.tree.itemChanged.connect(self._item_changed)
        self.tree.currentItemChanged.connect(lambda cur, _p: self._show_details(cur))
        ll.addWidget(self.tree, 1)
        leg = QLabel("<i>Tick a layer type, then the geometries to create: P points, L lines, R regions. "
                     "<span style='color:#888'>Grey</span> = needs the TUFLOW empties folder.</i>")
        leg.setWordWrap(True)
        ll.addWidget(leg)
        split.addWidget(left)

        right = QSplitter(Qt.Orientation.Vertical)
        self.info = QTextBrowser()
        self.info.setOpenExternalLinks(True)
        self.info.setMinimumHeight(120)
        right.addWidget(self.info)
        lower = QWidget()
        rl = QVBoxLayout(lower)
        rl.setContentsMargins(0, 0, 0, 0)
        drow = QHBoxLayout()
        drow.addWidget(QLabel("Descriptor"))
        self.desc = QLineEdit()
        self.desc.setPlaceholderText("optional extra name part, e.g. inflows  ->  2d_bc_M01_001_inflows_L")
        self.desc.textChanged.connect(self._desc_changed)
        drow.addWidget(self.desc, 1)
        rl.addLayout(drow)
        rl.addWidget(QLabel("<b>Attributes</b> - default values are filled in for every object you draw"))
        self.attr = QTableWidget(0, 5)
        self.attr.setHorizontalHeaderLabels(["Field", "SHP name", "Type", "Default value",
                                             "What to enter (TUFLOW manual)"])
        self.attr.horizontalHeader().setSectionResizeMode(4, QHeaderView.ResizeMode.Stretch)
        self.attr.horizontalHeaderItem(1).setToolTip("Shapefiles limit field names to 10 characters - "
                                                     "TUFLOW only uses the field order, so this is fine")
        self.attr.setColumnWidth(0, 130)
        self.attr.setColumnWidth(1, 92)
        self.attr.setColumnWidth(2, 96)
        self.attr.setColumnWidth(3, 160)
        self.attr.setWordWrap(True)
        self.attr.verticalHeader().setVisible(False)
        self.attr.setSelectionMode(QAbstractItemView.SelectionMode.NoSelection)
        rl.addWidget(self.attr, 1)
        right.addWidget(lower)
        right.setSizes([260, 300])
        split.addWidget(right)
        split.setSizes([600, 700])

        opts = QHBoxLayout()
        self.opt_load = QCheckBox("Open in QGIS")
        self.opt_load.setChecked(True)
        self.opt_defaults = QCheckBox("Set default values && dropdowns")
        self.opt_defaults.setChecked(True)
        self.opt_edit = QCheckBox("Start editing first layer")
        self.opt_cmds = QCheckBox("Add Read GIS commands to the control files")
        self.opt_cmds.setChecked(True)
        self.opt_over = QCheckBox("Overwrite existing")
        for w in (self.opt_load, self.opt_defaults, self.opt_edit, self.opt_cmds, self.opt_over):
            opts.addWidget(w)
        opts.addStretch(1)
        self.go = QPushButton("Create layers")
        self.go.setStyleSheet("font-weight: bold; padding: 6px 16px;")
        self.go.clicked.connect(self.create)
        opts.addWidget(self.go)
        lay.addLayout(opts)
        self.log = QPlainTextEdit()
        self.log.setReadOnly(True)
        self.log.setFont(mono_font())
        self.log.setMaximumHeight(80)
        self.log.setPlaceholderText("Results appear here.")
        lay.addWidget(self.log)
        self._fill_tree()

    def _crs_widget(self):
        try:
            from qgis.gui import QgsProjectionSelectionWidget
            w = QgsProjectionSelectionWidget()
            try:
                from qgis.core import QgsProject
                w.setCrs(QgsProject.instance().crs())
            except Exception:
                pass
            return w
        except Exception:
            w = QLineEdit()
            authid, _wkt = qu.project_crs()
            w.setText(authid)
            w.setPlaceholderText("EPSG code, e.g. EPSG:28356")
            return w

    def crs_args(self):
        """(wkt, epsg) for the writer."""
        if hasattr(self.crs, "crs"):
            try:
                c = self.crs.crs()
                if c.isValid():
                    return c.toWkt(), None
            except Exception:
                pass
            return None, None
        txt = self.crs.text().strip().upper().replace("EPSG:", "")
        return None, (int(txt) if txt.isdigit() else None)

    # ================================================================ tree
    def _fill_tree(self):
        self._building = True
        self.tree.clear()
        groups = {}
        for gname in EL.GROUP_ORDER:
            gi = QTreeWidgetItem([gname])
            gi.setFont(0, bold_font())
            gi.setFlags(Qt.ItemFlag.ItemIsEnabled)
            self.tree.addTopLevelItem(gi)
            groups[gname] = gi
        for lt in EL.LAYER_TYPES:
            gi = groups.get(lt.group)
            if gi is None:
                gi = QTreeWidgetItem([lt.group])
                gi.setFont(0, bold_font())
                self.tree.addTopLevelItem(gi)
                groups[lt.group] = gi
            it = QTreeWidgetItem(["{}  -  {}".format(lt.code, lt.title)])
            it.setData(0, ROLE_CODE, lt.code)
            it.setFlags(Qt.ItemFlag.ItemIsEnabled | Qt.ItemFlag.ItemIsSelectable | Qt.ItemFlag.ItemIsUserCheckable)
            it.setCheckState(0, Qt.CheckState.Unchecked)
            for g, col in GEOM_COLS.items():
                if g in lt.geoms:
                    it.setCheckState(col, Qt.CheckState.Checked if g in lt.default_geoms else Qt.CheckState.Unchecked)
                    it.setToolTip(col, EL.GEOM_NAMES[g])
            cmd = "{} {} ==".format(FILE_TYPE_INFO[lt.ftype][0], lt.command) if lt.ftype and lt.command else \
                "(add the command manually)"
            it.setText(5, cmd)
            gi.addChild(it)
        self.tree.expandAll()
        self._building = False
        self._refresh_availability()
        self._update_names()

    def _items(self):
        for i in range(self.tree.topLevelItemCount()):
            g = self.tree.topLevelItem(i)
            for j in range(g.childCount()):
                yield g.child(j)

    def _available(self, lt, geom=None):
        if self.source.value() == SOURCES[1] and lt.code in self.empties:
            return True if geom is None else (geom in self.empties[lt.code] or "?" in self.empties[lt.code]
                                              or lt.has_schema)
        return lt.has_schema

    def _refresh_availability(self):
        self._building = True
        for it in self._items():
            lt = EL.BY_CODE[it.data(0, ROLE_CODE)]
            ok = self._available(lt)
            col = QBrush() if ok else QBrush(QColor("#9a9a9a"))
            for c in range(6):
                it.setForeground(c, col)
            it.setToolTip(0, lt.title if ok else "{} - needs TUFLOW's own empty files (set the empties folder)"
                          .format(lt.title))
        self._building = False
        self._update_names()

    def _item_changed(self, it, col):
        if self._building:
            return
        if col == 0 and it.checkState(0) == Qt.CheckState.Checked:
            lt = EL.BY_CODE[it.data(0, ROLE_CODE)]
            if not any(it.checkState(c) == Qt.CheckState.Checked for g, c in GEOM_COLS.items() if g in lt.geoms):
                self._building = True
                for g in lt.default_geoms:
                    it.setCheckState(GEOM_COLS[g], Qt.CheckState.Checked)
                self._building = False
        if col in GEOM_COLS.values() and it.checkState(col) == Qt.CheckState.Checked:
            self._building = True
            it.setCheckState(0, Qt.CheckState.Checked)
            self._building = False
        self._update_names()

    def _filter(self, text):
        t = text.lower().strip()
        for i in range(self.tree.topLevelItemCount()):
            g = self.tree.topLevelItem(i)
            vis = 0
            for j in range(g.childCount()):
                it = g.child(j)
                show = not t or t in it.text(0).lower() or t in it.text(5).lower()
                it.setHidden(not show)
                vis += show
            g.setHidden(vis == 0)

    def apply_preset(self, name, clear=True):
        preset = EL.PRESETS.get(name)
        if not preset:
            return
        self._building = True
        for it in self._items():
            code = it.data(0, ROLE_CODE)
            lt = EL.BY_CODE[code]
            if code in preset:
                it.setCheckState(0, Qt.CheckState.Checked)
                for g, c in GEOM_COLS.items():
                    if g in lt.geoms:
                        it.setCheckState(c, Qt.CheckState.Checked if g in preset[code] else Qt.CheckState.Unchecked)
            elif clear:
                it.setCheckState(0, Qt.CheckState.Unchecked)
        self._building = False
        self._update_names()

    def clear_ticks(self):
        self._building = True
        for it in self._items():
            it.setCheckState(0, Qt.CheckState.Unchecked)
        self._building = False
        self._update_names()

    def selected(self):
        """[(LayerType, [geoms])] ticked and available."""
        out = []
        for it in self._items():
            if it.checkState(0) != Qt.CheckState.Checked:
                continue
            lt = EL.BY_CODE[it.data(0, ROLE_CODE)]
            geoms = [g for g, c in GEOM_COLS.items() if g in lt.geoms and it.checkState(c) == Qt.CheckState.Checked]
            if geoms:
                out.append((lt, geoms))
        return out

    def _name(self, lt, geom):
        stem = self.stem.text().strip()
        d = self.descriptors.get(lt.code, "").strip()
        return EL.layer_name(lt.code, "_".join(x for x in (stem, d) if x), geom)

    def _update_names(self):
        if self._building:
            return
        n = 0
        for it in self._items():
            lt = EL.BY_CODE[it.data(0, ROLE_CODE)]
            if it.checkState(0) == Qt.CheckState.Checked:
                names = [self._name(lt, g) for g, c in GEOM_COLS.items()
                         if g in lt.geoms and it.checkState(c) == Qt.CheckState.Checked]
                it.setText(4, ", ".join(names))
                if self._available(lt):
                    n += len(names)
            else:
                it.setText(4, "")
        self.go.setText("Create {} layer{}".format(n, "" if n == 1 else "s"))
        self.go.setEnabled(n > 0)

    # ============================================================= details
    def _show_details(self, it):
        if it is None or not it.data(0, ROLE_CODE):
            return
        lt = EL.BY_CODE[it.data(0, ROLE_CODE)]
        self._current = lt
        h = ["<h3>{} &nbsp;<span style='font-weight:normal'>{}</span></h3>".format(lt.code, lt.title)]
        if lt.ftype and lt.command:
            h.append("<p>Read by the <b>{}</b> with <code>{} == ...</code></p>".format(
                FILE_TYPE_INFO[lt.ftype][1], lt.command))
        h.append("<p><b>What to draw</b></p><ul>")
        order = list(lt.default_geoms) + [g for g in "LPR" if g not in lt.default_geoms]
        for g in order:
            if g in lt.guide and g in lt.geoms:
                h.append("<li><b>{}</b> ({}): {}</li>".format(g, EL.GEOM_NAMES[g], _esc(lt.guide[g])))
        if "" in lt.guide:
            h.append("<li>{}</li>".format(_esc(lt.guide[""])))
        h.append("</ul>")
        if lt.fields is None:
            src = "TUFLOW empties folder" if lt.code in self.empties else "not available yet"
            h.append("<p><i>Attribute structure: {}.</i></p>".format(src))
        else:
            h.append("<p><i>Attribute structure: {} (TUFLOW reads attributes by position and type, "
                     "so keep the order).</i></p>".format(lt.source))
        h.append('<p><a href="https://wiki.tuflow.com/TUFLOW_Empty_Files">TUFLOW empty files (wiki)</a> &nbsp; '
                 '<a href="https://docs.tuflow.com/classic-hpc/manual/latest/04-ControlFiles-and-Inputs.html">'
                 'Control files and input layers (manual)</a></p>')
        if lt.code == "2d_mat":
            n = len(self.ctx.model_names("materials")) if self.ctx is not None else 0
            h.append("<p><b>Materials:</b> the Material dropdown lists the {} IDs in your materials.csv "
                     "(edit it in the <i>Databases</i> tab). In QGIS the attribute form shows the same list, so "
                     "every polygon gets a valid ID.</p>".format(n))
        h.append("<p><b>Tip:</b> turn on snapping (vertex) in QGIS so lines, points and 1D network ends "
                 "connect exactly.</p>")
        self.info.setHtml("".join(h))
        self.desc.blockSignals(True)
        self.desc.setText(self.descriptors.get(lt.code, ""))
        self.desc.blockSignals(False)
        self._fill_attr(lt)

    def _fields_for(self, lt, geom=None):
        if self.source.value() == SOURCES[1] and lt.code in self.empties:
            e = self.empties[lt.code]
            key = geom if geom in e else (next(iter(e)) if e else None)
            if key:
                path, layer = e[key]
                try:
                    fields, _g = EL.read_schema(path, layer)
                    return fields
                except Exception:
                    pass
        return lt.fields

    def _field_choices(self, lt, f):
        builtin = next((bf for bf in (lt.fields or []) if bf.name.lower() == f.name.lower()), None)
        choices = list(f.choices or (builtin.choices if builtin else []))
        if lt.code == "2d_mat" and f.name.lower().startswith("material") and self.ctx is not None:
            choices = [(v, lbl) for v, lbl in self.ctx.model_names("materials")] or choices
        return choices

    def _fill_attr(self, lt):
        fields = self._fields_for(lt) or []
        vals = self.defaults.setdefault(lt.code, {})
        shp = FMT_KEY.get(self.fmt.value()) == "shp"
        shp_names = EL.shp_field_names(fields) if fields else []
        self.attr.setColumnHidden(1, not shp)
        for r in range(self.attr.rowCount()):          # drop the previous editors immediately
            w = self.attr.cellWidget(r, 3)
            if w is not None:
                w.hide()
        self.attr.setRowCount(0)
        self.attr.setRowCount(len(fields))
        for r, f in enumerate(fields):
            guide = EL.field_guide(lt.code, f.name) or (f.desc if f.desc != "from TUFLOW empty" else "")
            if not guide:
                guide = "See the manual for this field (structure copied from TUFLOW's empty file)."
            for c, text in ((0, f.name), (1, shp_names[r]), (2, f.type_label), (4, guide)):
                item = QTableWidgetItem(text)
                item.setFlags(Qt.ItemFlag.ItemIsEnabled)
                item.setToolTip("<p>{}</p>".format(_esc(guide)))
                self.attr.setItem(r, c, item)
            self.attr.item(r, 0).setFont(bold_font())
            choices = self._field_choices(lt, f)
            if choices:
                ed = ChoiceEdit(["{}".format(v) for v, _m in choices if v != ""], editable=True)
                for i in range(1, ed.count()):
                    m = next((mm for v, mm in choices if v == ed.itemData(i)), "")
                    ed.setItemText(i, "{}  -  {}".format(ed.itemData(i), m) if m else ed.itemData(i))
            else:
                ed = ChoiceEdit([], editable=True)
                ed.lineEdit().setPlaceholderText({"I": "integer", "F": "number", "C": "text"}[f.kind])
            ed.setToolTip(guide)
            ed.setValue(vals.get(f.name, ""))
            ed.changed.connect(lambda v, name=f.name, code=lt.code: self.defaults.setdefault(code, {}).__setitem__(name, v))
            self.attr.setCellWidget(r, 3, ed)
        self.attr.resizeRowsToContents()

    def _desc_changed(self, text):
        lt = getattr(self, "_current", None)
        if lt is None:
            return
        self.descriptors[lt.code] = text.strip().replace(" ", "_")
        self._update_names()

    # ========================================================== settings
    def _format_changed(self, v):
        fmt = FMT_KEY.get(v, "gpkg")
        cur = self.target.value().strip()
        if fmt == "gpkg":
            self.target.kind = "gis_out"
            self.target.file_filter = "GeoPackage (*.gpkg)"
            if cur and not cur.lower().endswith(".gpkg"):
                self.target.setValue(os.path.join(cur, (self.stem.text().strip() or "model") + ".gpkg"))
        else:
            self.target.kind = "folder"
            if cur.lower().endswith(".gpkg"):
                self.target.setValue(os.path.dirname(cur))
        self._update_names()
        if getattr(self, "_current", None) is not None:
            self._fill_attr(self._current)

    def _source_changed(self):
        if self.source.value() == SOURCES[1] and not self.empty_dir.value().strip():
            p = self.ctx.current_project() if self.ctx else None
            if p is not None:
                guess = os.path.join(p.root, "model", "gis", "empty")
                if os.path.isdir(guess):
                    self.empty_dir.setValue(guess)
        self._scan_empties()

    def _scan_empties(self):
        self.empties = EL.scan_empty_folder(self.empty_dir.value().strip())
        self._refresh_availability()
        cur = self.tree.currentItem()
        if cur is not None:
            self._show_details(cur)

    def set_project(self, project):
        """Fill sensible defaults from the current model."""
        if project is None:
            return
        self.stem.setText(project.base_name)
        tcf = project.files.get("TCF")
        target = ""
        if tcf is not None:
            sdb = tcf.value("Spatial Database")
            if sdb and sdb.upper() not in ("OFF", "TCF") and sdb.lower().strip().endswith(".gpkg"):
                target = resolve_path(sdb, os.path.dirname(tcf.path))
        if not target:
            target = os.path.join(project.root, "model", "gis", project.base_name + ".gpkg")
        if FMT_KEY.get(self.fmt.value()) != "gpkg":
            target = os.path.dirname(target)
        self.target.setValue(target)
        guess = os.path.join(project.root, "model", "gis", "empty")
        if os.path.isdir(guess) and not self.empty_dir.value():
            self.empty_dir.setValue(guess)
            self._scan_empties()

    def reset(self):
        self.defaults = {}
        self.descriptors = {}
        self._current = None
        self.stem.setText("M01_001")
        self.target.setValue("")
        self.empty_dir.setValue("")
        self.source.setValue(SOURCES[0])
        self.empties = {}
        self.fmt.setValue(FORMATS[0])
        self._format_changed(FORMATS[0])
        self.clear_ticks()
        self.apply_preset("2D base model")
        self._refresh_availability()
        self.attr.setRowCount(0)
        self.desc.setText("")
        self.info.setHtml("<i>Select a layer type to see what to draw and what each attribute means.</i>")
        self.log.clear()

    # ============================================================ create
    def build_jobs(self):
        jobs, missing = [], []
        for lt, geoms in self.selected():
            for g in geoms:
                fields = self._fields_for(lt, g)
                if not fields:
                    missing.append(self._name(lt, g))
                    continue
                vals = self.defaults.get(lt.code, {})
                jobs.append(EL.LayerJob(lt, g, self._name(lt, g), fields,
                                        {f.name: vals.get(f.name, "") for f in fields}))
        return jobs, missing

    def create(self):
        fmt = FMT_KEY.get(self.fmt.value(), "gpkg")
        target = self.target.value().strip()
        if not target:
            QMessageBox.warning(self, "Empty layers", "Choose where to save the layers.")
            return
        if fmt == "gpkg" and not target.lower().endswith(".gpkg"):
            target += ".gpkg"
            self.target.setValue(target)
        if not EL.valid_stem(self.stem.text().strip()):
            QMessageBox.warning(self, "Empty layers", "Use only letters, numbers, _ and - in the name part.")
            return
        jobs, missing = self.build_jobs()
        if not jobs:
            QMessageBox.information(self, "Empty layers", "Tick at least one available layer type and geometry.")
            return
        wkt, epsg = self.crs_args()
        if not wkt and not epsg and QMessageBox.question(
                self, "Empty layers", "No CRS set - TUFLOW checks that all layers share one projection.\n"
                                      "Create the layers without a CRS?") != QMessageBox.StandardButton.Yes:
            return
        try:
            written, skipped = EL.write_layers(jobs, fmt, target, wkt, epsg, self.opt_over.isChecked())
        except ImportError:
            QMessageBox.critical(self, "Empty layers", "GDAL/OGR (osgeo) is not available in this Python.")
            return
        except Exception as ex:
            QMessageBox.critical(self, "Empty layers", "Could not write the layers:\n{}".format(ex))
            return
        lines = ["Created {} layer(s) in {}".format(len(written), target)]
        lines += ["  + {}".format(j.name) for j in written]
        lines += ["  - skipped {}: {}".format(j.name, r) for j, r in skipped]
        lines += ["  - not created {}: no attribute structure (set the TUFLOW empties folder)".format(n) for n in missing]
        if written and self.opt_load.isChecked():
            first = True
            for j in written:
                defaults, closed = {}, {}
                if self.opt_defaults.isChecked():
                    for i, f in enumerate(j.fields):
                        expr = EL.default_expression(f, j.defaults.get(f.name, ""))
                        if expr:
                            defaults[i] = expr
                        bf = next((b for b in (j.ltype.fields or []) if b.name.lower() == f.name.lower()), None)
                        if bf and (j.ltype.code, bf.name) in EL.CLOSED_FIELDS and bf.choices:
                            closed[i] = bf.choices
                        elif j.ltype.code == "2d_mat" and f.name.lower().startswith("material"):
                            mats = self._field_choices(j.ltype, f)
                            if mats:
                                closed[i] = mats
                lyr = qu.load_empty_layer(j, "TUFLOW inputs/{}".format(j.ltype.group), defaults, closed,
                                          save_style=self.opt_defaults.isChecked(),
                                          start_editing=self.opt_edit.isChecked() and first)
                first = False if lyr is not None else first
        if written and self.opt_cmds.isChecked():
            p = self.ctx.current_project() if self.ctx else None
            if p is None:
                lines.append("No model loaded - Read GIS commands were not added.")
            else:
                dirs = {ft: p.dir_of(ft) for ft in FILE_TYPE_INFO}
                sdb = None
                tcf = p.files.get("TCF")
                if tcf is not None and tcf.value("Spatial Database"):
                    v = tcf.value("Spatial Database")
                    if v.upper() not in ("OFF", "TCF"):
                        sdb = resolve_path(v, os.path.dirname(tcf.path))
                cmds = EL.build_commands(written, fmt, dirs, sdb)
                self.commandsReady.emit(cmds)
                lines += ["  > {}: {} == {}".format(ft, c, v) for ft, c, v in cmds]
        self.log.setPlainText("\n".join(lines))
        qu.message("{} empty layer(s) created".format(len(written)), "success" if written else "warning")
        return written

    # =================================================== TUFLOW empties
    def write_with_tuflow(self):
        exe = ""
        if self.ctx is not None and hasattr(self.ctx, "batch_tab"):
            exe = self.ctx.batch_tab.config().exe
        if not exe or not os.path.isfile(exe):
            QMessageBox.warning(self, "Write with TUFLOW", "Set the TUFLOW executable in the Batch && Run tab first.")
            return
        p = self.ctx.current_project()
        if p is None:
            QMessageBox.information(self, "Write with TUFLOW", "Create or open a model first.")
            return
        wkt, epsg = self.crs_args()
        if not wkt and not epsg:
            QMessageBox.warning(self, "Write with TUFLOW", "Choose a CRS first - TUFLOW writes the empties in it.")
            return
        fmt = "shp" if FMT_KEY.get(self.fmt.value()) == "shp" else "gpkg"
        empty = self.empty_dir.value().strip() or os.path.join(p.root, "model", "gis", "empty")
        runs = p.runs_dir
        os.makedirs(runs, exist_ok=True)
        try:
            proj = EL.write_projection_layer(os.path.join(p.root, "model", "gis"), fmt, wkt, epsg)
        except Exception as ex:
            QMessageBox.critical(self, "Write with TUFLOW", "Could not write the projection layer:\n{}".format(ex))
            return
        tcf = os.path.join(runs, "_fmb_write_empties.tcf")
        with open(tcf, "w", newline="") as fh:
            fh.write(EL.empties_tcf_text(empty, fmt, proj, runs))
        os.makedirs(empty, exist_ok=True)
        self.empty_dir.setValue(empty)
        self.log.setPlainText("Running TUFLOW to write its empty files...\n{} -b {}\n".format(exe, tcf))
        self._proc = QProcess(self)
        self._proc.setWorkingDirectory(runs)
        self._proc.setProcessChannelMode(QProcess.ProcessChannelMode.MergedChannels)
        self._proc.readyReadStandardOutput.connect(
            lambda: self.log.appendPlainText(bytes(self._proc.readAllStandardOutput()).decode("utf-8", "replace")))
        self._proc.finished.connect(self._tuflow_done)
        self._proc.start(exe, ["-b", tcf])

    def _tuflow_done(self, *_):
        self.source.setValue(SOURCES[1])
        self._scan_empties()
        n = len(self.empties)
        self.log.appendPlainText("\nFound {} TUFLOW empty layer types in {}".format(n, self.empty_dir.value()))
        if not n:
            self.log.appendPlainText("TUFLOW did not write empty files - check the log above.")


def _esc(t):
    return (t or "").replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
