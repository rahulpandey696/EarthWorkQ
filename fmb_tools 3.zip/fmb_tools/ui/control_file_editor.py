# -*- coding: utf-8 -*-
"""
Interactive editor for one TUFLOW control file.

Left:   command browser (guided 'Essentials' + every command in the manual)
Centre: the commands in the file as editable rows (value widgets are chosen
        from the command syntax: dropdowns, file/layer pickers, text)
Right:  live preview of the file text (syntax highlighted) with optional
        direct text editing - no external text editor needed.
"""
import os

from qgis.PyQt.QtCore import Qt, pyqtSignal, QTimer
from qgis.PyQt.QtGui import QBrush
from qgis.PyQt.QtWidgets import (QWidget, QVBoxLayout, QHBoxLayout, QSplitter, QTreeWidget, QTreeWidgetItem,
                                 QLineEdit, QTextBrowser, QPushButton, QTableWidget, QTableWidgetItem, QHeaderView,
                                 QAbstractItemView, QToolButton, QMenu, QLabel, QPlainTextEdit, QCheckBox,
                                 QComboBox, QFileDialog, QMessageBox, QInputDialog, QFrame)

from ..core.catalog import catalog, FILE_TYPE_INFO
from ..core.command_groups import grouped, group_of
from ..core.control_file import ControlFile, Entry, split_value_paths, looks_like_path, resolve_path, TOKEN_RE
from ..core.essentials import ESSENTIALS, REQUIRED
from ..core.help_links import CONTROL_FILE_HELP
from ..core.explanations import explain, explain_spec, FILE_OVERVIEW, GROUP_EXPLAIN
from . import qgis_utils as qu
from .widgets import (make_value_editor, TuflowHighlighter, SEVERITY_COLORS, LEVEL_COLORS, mono_font, bold_font,
                      ExplainDelegate)

ROLE_SPEC = Qt.ItemDataRole.UserRole
ROLE_VALUE = Qt.ItemDataRole.UserRole + 1
ROLE_TIP = Qt.ItemDataRole.UserRole + 2
ROLE_LEVEL = Qt.ItemDataRole.UserRole + 3
ROLE_FT = Qt.ItemDataRole.UserRole + 4
ROLE_GROUP = Qt.ItemDataRole.UserRole + 5
ROLE_BRIEF = Qt.ItemDataRole.UserRole + 6
APPENDIX_LETTER = {"TCF": "A", "ECF": "B", "TGC": "C", "TBC": "D", "TOC": "E", "TRFC": "F", "TESF": "G",
                   "QCF": "H", "TSCF": "I", "ADCF": "J", "TEF": "K"}


class CommandCell(QWidget):
    """Shows the command name with dropdowns for its modifiers."""
    changed = pyqtSignal(str, list)      # new lhs, choices

    def __init__(self, entry, depth, parent=None):
        super().__init__(parent)
        self.entry = entry
        lay = QHBoxLayout(self)
        lay.setContentsMargins(2, 0, 2, 0)
        lay.setSpacing(3)
        if depth:
            lay.addSpacing(14 * depth)
        spec = entry.spec
        self.widgets = []
        exact = spec is not None and " ".join(entry.lhs.lower().split()) == \
            spec.build_lhs(list(entry.choices) or spec.default_choices()).lower()
        if spec is None or (not exact and not spec.variable_parts()):
            self.free = QLineEdit(entry.lhs)
            if spec is None:
                self.free.setToolTip("Command not found in the manual index - check the spelling.")
                self.free.setStyleSheet("color: #b35900;")
            else:
                self.free.setToolTip("Variant of '{}'".format(spec.name))
                self.free.setFont(bold_font())
            self.free.editingFinished.connect(lambda: self.changed.emit(self.free.text().strip(), []))
            lay.addWidget(self.free, 1)
            return
        choices = list(entry.choices) or spec.default_choices()
        vi = 0
        for part in spec.parts:
            if part.kind == "lit":
                lbl = QLabel(part.text)
                lbl.setFont(bold_font())
                lay.addWidget(lbl)
                continue
            cur = choices[vi] if vi < len(choices) else part.default
            vi += 1
            if part.kind == "mod":
                cb = QComboBox()
                cb.setEditable(part.editable)
                opts = list(part.options)
                if "" not in opts and not part.default:
                    pass
                for o in opts:
                    cb.addItem(o if o else "—", o)
                idx = next((i for i in range(cb.count()) if (cb.itemData(i) or "").lower() == (cur or "").lower()), -1)
                if idx < 0 and cur:
                    cb.addItem(cur, cur)
                    idx = cb.count() - 1
                cb.setCurrentIndex(max(0, idx))
                cb.currentIndexChanged.connect(self._emit)
                if part.editable:
                    cb.lineEdit().editingFinished.connect(self._emit)
                cb.setSizeAdjustPolicy(QComboBox.SizeAdjustPolicy.AdjustToContents)
                self.widgets.append(cb)
                lay.addWidget(cb)
            else:
                le = QLineEdit(cur)
                le.setPlaceholderText(part.text)
                le.setMaximumWidth(140)
                le.editingFinished.connect(self._emit)
                self.widgets.append(le)
                lay.addWidget(le)
        lay.addStretch(1)

    def _emit(self, *_a):
        choices = []
        for w in self.widgets:
            if isinstance(w, QComboBox):
                txt = w.currentText()
                data = w.itemData(w.currentIndex())
                choices.append(data if (data is not None and w.itemText(w.currentIndex()) == txt) else txt)
            else:
                choices.append(w.text().strip())
        lhs = self.entry.spec.build_lhs(choices)
        self.changed.emit(lhs, choices)


class ControlFileEditor(QWidget):
    changed = pyqtSignal()
    openChildRequested = pyqtSignal(str)          # ftype
    openDatabaseRequested = pyqtSignal(str)       # absolute path
    createRequested = pyqtSignal(str)             # ftype
    fileReplaced = pyqtSignal(str)                # ftype (after open / save as)

    def __init__(self, ftype, parent=None):
        super().__init__(parent)
        self.ftype = ftype
        self.cf = None
        self._building = False
        self._preview_timer = QTimer(self)
        self._preview_timer.setSingleShot(True)
        self._preview_timer.setInterval(250)
        self._preview_timer.timeout.connect(self.refresh_preview)
        self.dirty = False
        self.names_fn = lambda kind: []       # set by the main dialog: scenarios, events, bc, materials
        self._build_ui()
        self.set_control_file(None)

    # ------------------------------------------------------------------ UI
    def _build_ui(self):
        outer = QVBoxLayout(self)
        outer.setContentsMargins(4, 4, 4, 4)
        bar = QHBoxLayout()
        title = QLabel("<b>{}</b> - {}".format(FILE_TYPE_INFO[self.ftype][0], FILE_TYPE_INFO[self.ftype][1]))
        bar.addWidget(title)
        self.path_label = QLabel("")
        self.path_label.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)
        self.path_label.setStyleSheet("color: gray;")
        bar.addWidget(self.path_label, 1)
        for text, tip, slot in (("Open...", "Open an existing file into this tab", self.open_file),
                                ("Save", "Save this control file", self.save),
                                ("Save as...", "Save to a new file name", self.save_as),
                                ("Reload", "Discard edits and reload from disk", self.reload)):
            b = QPushButton(text)
            b.setToolTip(tip)
            b.clicked.connect(slot)
            bar.addWidget(b)
        hb = QToolButton()
        hb.setText("Help")
        hb.setPopupMode(QToolButton.ToolButtonPopupMode.InstantPopup)
        hm = QMenu(hb)
        for label, url, note in CONTROL_FILE_HELP.get(self.ftype, []):
            a = hm.addAction(label)
            a.setToolTip(note)
            a.triggered.connect(lambda _=False, u=url: qu.open_url(u))
        hm.setToolTipsVisible(True)
        hb.setMenu(hm)
        bar.addWidget(hb)
        outer.addLayout(bar)

        # placeholder shown when the model has no file of this type
        self.placeholder = QFrame()
        pl = QVBoxLayout(self.placeholder)
        self.ph_label = QLabel()
        self.ph_label.setWordWrap(True)
        self.ph_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        pl.addStretch(1)
        pl.addWidget(self.ph_label)
        pb = QPushButton("Create {} for this model".format(FILE_TYPE_INFO[self.ftype][0]))
        pb.clicked.connect(lambda: self.createRequested.emit(self.ftype))
        pl.addWidget(pb, 0, Qt.AlignmentFlag.AlignHCenter)
        ob = QPushButton("Open an existing {} ...".format(FILE_TYPE_INFO[self.ftype][0]))
        ob.clicked.connect(self.open_file)
        pl.addWidget(ob, 0, Qt.AlignmentFlag.AlignHCenter)
        pl.addStretch(2)
        outer.addWidget(self.placeholder)

        self.splitter = QSplitter(Qt.Orientation.Horizontal)
        outer.addWidget(self.splitter, 1)

        # -- browser
        left = QWidget()
        ll = QVBoxLayout(left)
        ll.setContentsMargins(0, 0, 0, 0)
        self.search = QLineEdit()
        self.search.setPlaceholderText("Search commands...")
        self.search.textChanged.connect(self._filter_tree)
        ll.addWidget(self.search)
        vrow = QHBoxLayout()
        self.view = QComboBox()
        self.view.addItems(["By topic", "A - Z"])
        self.view.setToolTip("Group the manual's commands by topic or list them alphabetically")
        self.view.currentIndexChanged.connect(lambda _i: self._fill_tree())
        vrow.addWidget(self.view, 1)
        for text, tip, slot in (("Expand all", "Expand every group", lambda: self._expand(True)),
                                ("Collapse all", "Collapse every group", lambda: self._expand(False))):
            b = QToolButton()
            b.setText(text)
            b.setToolTip(tip)
            b.clicked.connect(slot)
            vrow.addWidget(b)
        self.explain_cb = QCheckBox("Explain")
        self.explain_cb.setChecked(True)
        self.explain_cb.setToolTip("Show a brief explanation under each Essentials command")
        vrow.addWidget(self.explain_cb)
        ll.addLayout(vrow)
        self.tree = QTreeWidget()
        self.tree.setHeaderHidden(True)
        self.tree.setUniformRowHeights(False)
        self.explain_delegate = ExplainDelegate(self.tree, ROLE_BRIEF)
        self.tree.setItemDelegate(self.explain_delegate)
        self.explain_cb.toggled.connect(self._toggle_explain)
        self.tree.itemSelectionChanged.connect(self._show_info)
        self.tree.itemDoubleClicked.connect(lambda it, _c: self.add_from_tree(it))
        ll.addWidget(self.tree, 3)
        self.info = QTextBrowser()
        self.info.setOpenExternalLinks(True)
        ll.addWidget(self.info, 2)
        addb = QPushButton("Add command  >>")
        addb.clicked.connect(lambda: self.add_from_tree(self.tree.currentItem()))
        ll.addWidget(addb)
        self.splitter.addWidget(left)

        # -- table
        mid = QWidget()
        ml = QVBoxLayout(mid)
        ml.setContentsMargins(0, 0, 0, 0)
        tb = QHBoxLayout()
        for text, tip, slot in (("Up", "Move selected rows up", lambda: self.move(-1)),
                                ("Down", "Move selected rows down", lambda: self.move(1)),
                                ("Delete", "Delete selected rows", self.delete_rows),
                                ("Duplicate", "Duplicate selected rows", self.duplicate_rows),
                                ("On/Off", "Comment out / restore selected commands", self.toggle_rows),
                                ("+ Comment", "Insert a comment line", self.add_comment),
                                ("+ Blank", "Insert a blank line", lambda: self.insert_entries([Entry("blank")])),
                                ("If block...", "Wrap selected rows in an If Scenario / If Event block", self.wrap_if)):
            b = QPushButton(text)
            b.setToolTip(tip)
            b.clicked.connect(slot)
            tb.addWidget(b)
        tb.addStretch(1)
        ml.addLayout(tb)
        self.table = QTableWidget(0, 5)
        self.table.setHorizontalHeaderLabels(["", "Command", "Value", "Comment", ""])
        hh = self.table.horizontalHeader()
        hh.setSectionResizeMode(0, QHeaderView.ResizeMode.Fixed)
        hh.setSectionResizeMode(1, QHeaderView.ResizeMode.Interactive)
        hh.setSectionResizeMode(2, QHeaderView.ResizeMode.Stretch)
        hh.setSectionResizeMode(3, QHeaderView.ResizeMode.Interactive)
        hh.setSectionResizeMode(4, QHeaderView.ResizeMode.Fixed)
        self.table.setColumnWidth(0, 28)
        self.table.setColumnWidth(1, 300)
        self.table.setColumnWidth(3, 95)
        self.table.setColumnWidth(4, 28)
        self.table.verticalHeader().setDefaultSectionSize(28)
        self.table.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self.table.setSelectionMode(QAbstractItemView.SelectionMode.ExtendedSelection)
        self.table.itemChanged.connect(self._item_changed)
        ml.addWidget(self.table, 1)
        self.status = QLabel("")
        self.status.setWordWrap(True)
        ml.addWidget(self.status)
        self.splitter.addWidget(mid)

        # -- preview
        right = QWidget()
        rl = QVBoxLayout(right)
        rl.setContentsMargins(0, 0, 0, 0)
        ph = QHBoxLayout()
        ph.addWidget(QLabel("<b>File preview</b>"))
        ph.addStretch(1)
        self.edit_text = QCheckBox("Edit text directly")
        self.edit_text.toggled.connect(self._toggle_text_edit)
        ph.addWidget(self.edit_text)
        self.apply_btn = QPushButton("Apply text")
        self.apply_btn.setEnabled(False)
        self.apply_btn.clicked.connect(self.apply_text)
        ph.addWidget(self.apply_btn)
        rl.addLayout(ph)
        self.preview = QPlainTextEdit()
        self.preview.setReadOnly(True)
        self.preview.setFont(mono_font())
        self.preview.setLineWrapMode(QPlainTextEdit.LineWrapMode.NoWrap)
        self.highlighter = TuflowHighlighter(self.preview.document())
        rl.addWidget(self.preview, 1)
        self.splitter.addWidget(right)
        self.splitter.setSizes([360, 680, 310])
        self._fill_tree()

    # --------------------------------------------------------------- browser
    def _fill_tree(self):
        self.tree.clear()
        ess_root = QTreeWidgetItem(["Essentials (guided)"])
        ess_root.setFont(0, bold_font())
        ess_root.setToolTip(0, _wrap_tip(FILE_OVERVIEW.get(self.ftype, "")))
        self.tree.addTopLevelItem(ess_root)
        for group, cmds in ESSENTIALS.get(self.ftype, []):
            g = QTreeWidgetItem([group])
            g.setToolTip(0, GROUP_EXPLAIN.get((self.ftype, group), ""))
            g.setData(0, ROLE_GROUP, group)
            ess_root.addChild(g)
            for key, level, value, tip in cmds:
                spec, _ = catalog().match(self.ftype, key)
                brief = explain(self.ftype, key, tip)
                it = QTreeWidgetItem([key + {"req": "  *", "rec": "  +", "opt": ""}[level]])
                it.setData(0, ROLE_SPEC, key)
                it.setData(0, ROLE_VALUE, value)
                it.setData(0, ROLE_TIP, tip)
                it.setData(0, ROLE_LEVEL, level)
                it.setData(0, ROLE_FT, spec.ftype if spec else self.ftype)
                it.setData(0, ROLE_BRIEF, brief)
                it.setForeground(0, QBrush(LEVEL_COLORS[level]))
                tt = brief + ("\n\nTip: " + tip if tip and tip not in brief else "")
                it.setToolTip(0, _wrap_tip(tt or (spec.syntax if spec else key)))
                g.addChild(it)
        ess_root.setExpanded(True)
        for i in range(ess_root.childCount()):
            ess_root.child(i).setExpanded(True)
        sources = [(self.ftype, "All {} commands - {} ({})")]
        if self.ftype == "TEF":        # the manual allows every TCF and ECF command in the event file
            sources += [("TCF", "TCF commands usable in the TEF - {} ({})"),
                        ("ECF", "ECF commands usable in the TEF - {} ({})")]
        for ft, title in sources:
            specs = catalog().specs(ft)
            appendix = "Appendix {}".format(APPENDIX_LETTER.get(ft, "?"))
            label = title.format(self.ftype, appendix, len(specs)) if ft == self.ftype else \
                title.format(appendix, len(specs))
            root = QTreeWidgetItem([label])
            root.setFont(0, bold_font())
            root.setToolTip(0, "Every command of the TUFLOW 2026 manual, {}".format(appendix))
            self.tree.addTopLevelItem(root)
            if self.view.currentIndex() == 0:
                for group, gspecs in grouped(ft, specs):
                    g = QTreeWidgetItem(["{}  ({})".format(group, len(gspecs))])
                    g.setData(0, ROLE_GROUP, group)
                    root.addChild(g)
                    for spec in gspecs:
                        g.addChild(self._spec_item(spec))
            else:
                for spec in sorted(specs, key=lambda x: x.name.lower()):
                    root.addChild(self._spec_item(spec))
            root.setExpanded(ft == self.ftype)
        legend = QTreeWidgetItem(["*  required    +  recommended"])
        legend.setDisabled(True)
        self.tree.addTopLevelItem(legend)
        if self.search.text().strip():
            self._filter_tree(self.search.text())
        self._show_info()

    def _spec_item(self, spec):
        it = QTreeWidgetItem([spec.name])
        it.setData(0, ROLE_SPEC, spec.name)
        it.setData(0, ROLE_VALUE, "")
        it.setData(0, ROLE_FT, spec.ftype)
        brief = explain_spec(spec)
        it.setToolTip(0, _wrap_tip(spec.syntax + ("\n\n" + brief if brief else "")))
        return it

    def _toggle_explain(self, on):
        self.explain_delegate.enabled = bool(on)
        self.tree.doItemsLayout()
        self.tree.viewport().update()

    def _expand(self, on):
        def walk(item):
            if item.childCount():
                item.setExpanded(on)
                for i in range(item.childCount()):
                    walk(item.child(i))
        for i in range(self.tree.topLevelItemCount()):
            walk(self.tree.topLevelItem(i))

    def _filter_tree(self, text):
        t = text.lower().strip()

        def walk(item):
            vis_child = False
            for i in range(item.childCount()):
                if walk(item.child(i)):
                    vis_child = True
            match = (not t) or t in item.text(0).lower() or t in (item.toolTip(0) or "").lower()
            leaf = item.childCount() == 0
            show = (match if leaf else (vis_child or not t))
            item.setHidden(not show)
            if t and vis_child:
                item.setExpanded(True)
            return show
        for i in range(self.tree.topLevelItemCount()):
            walk(self.tree.topLevelItem(i))

    def _show_info(self):
        it = self.tree.currentItem()
        if not it or not it.data(0, ROLE_SPEC):
            name, desc = FILE_TYPE_INFO[self.ftype][0], FILE_TYPE_INFO[self.ftype][1]
            html = ["<b>{} - {}</b>".format(_esc(name), _esc(desc)),
                    "<p>{}</p>".format(_esc(FILE_OVERVIEW.get(self.ftype, "")))]
            grp = it.data(0, ROLE_GROUP) if it else None
            if grp and (self.ftype, grp) in GROUP_EXPLAIN:
                html.append("<p><b>{}</b>: {}</p>".format(_esc(grp), _esc(GROUP_EXPLAIN[(self.ftype, grp)])))
            html.append("<p><i>Select a command to see what it does and its syntax. Double-click to add it."
                        "</i></p>")
            self.info.setHtml("".join(html))
            return
        spec, _ = catalog().match(it.data(0, ROLE_FT) or self.ftype, it.data(0, ROLE_SPEC))
        tip = it.data(0, ROLE_TIP) or ""
        brief = it.data(0, ROLE_BRIEF) or explain_spec(spec)
        sugg = it.data(0, ROLE_VALUE) or ""
        lvl = {"req": "Required", "rec": "Recommended", "opt": "Optional"}.get(it.data(0, ROLE_LEVEL), "")
        html = []
        if spec:
            html.append("<b>{}</b>".format(spec.name))
            html.append("<br><span style='color:gray'>{} - Appendix {} - {}</span>".format(
                spec.ftype, APPENDIX_LETTER.get(spec.ftype, "?"), group_of(spec.ftype, spec)))
            if brief:
                html.append("<p style='background:#eef4fb; padding:4px'>{}</p>".format(_esc(brief)))
            html.append("<p><code>{}</code></p>".format(_esc(spec.syntax)))
            if spec.default:
                html.append("<p>Default: <b>{}</b></p>".format(_esc(spec.default)))
            words = [o for o in spec.options if o and not o.replace(".", "", 1).replace("-", "", 1).replace(",", "").replace(" ", "").isdigit()]
            if words:
                html.append("<p>Options: {}</p>".format(", ".join(_esc(o) for o in words)))
        if lvl:
            html.append("<p><i>{}</i></p>".format(lvl))
        if tip and tip not in brief:
            html.append("<p><b>Tip:</b> {}</p>".format(_esc(tip)))
        if sugg:
            html.append("<p>Suggested value: <code>{}</code></p>".format(_esc(sugg)))
        if spec:
            html.append('<p><a href="{}">Open this command in the TUFLOW manual</a></p>'.format(spec.url))
        self.info.setHtml("".join(html))

    def add_from_tree(self, it):
        if it is None or not it.data(0, ROLE_SPEC):
            return
        if self.cf is None:
            self.createRequested.emit(self.ftype)
            if self.cf is None:
                return
        key = it.data(0, ROLE_SPEC)
        spec, choices = catalog().match(it.data(0, ROLE_FT) or self.ftype, key)
        value = (it.data(0, ROLE_VALUE) or "").replace("{model}", self._model_base())
        if spec is None:
            self.insert_entries([Entry("command", lhs=key, value=value)])
            return
        if not choices:
            choices = spec.default_choices()
        lhs = spec.build_lhs(choices)
        if "<" in lhs:   # free-text parts (e.g. Set Variable <name>, IGW Conc Layer <layers> Tracer <tracers>)
            choices = list(choices)
            for i, part in enumerate(spec.variable_parts()):
                if part.kind != "free" or (i < len(choices) and choices[i] and not choices[i].startswith("<")):
                    continue
                val, ok = QInputDialog.getText(self, spec.name, "Value for <{}>:".format(part.text))
                if not ok or not val.strip():
                    return
                while len(choices) <= i:
                    choices.append("")
                choices[i] = val.strip()
            lhs = spec.build_lhs(choices)
        k = spec.key.lower()
        if k in ("if scenario", "if event"):
            self.insert_entries([Entry("command", lhs=lhs, value="", spec=spec, choices=choices),
                                 _entry(self.ftype, "End If")])
            return
        if k == "define event" or k == "define output zone" or (k.startswith("define") and k.endswith("control")):
            name, ok = QInputDialog.getText(self, spec.name, "Name / ID:")
            if not ok:
                return
            self.insert_entries([Entry("command", lhs=lhs, value=name.strip(), spec=spec, choices=choices),
                                 _entry(self.ftype, "End Define")])
            return
        if not spec.has_value:
            value = ""
        self.insert_entries([Entry("command", lhs=lhs, value=value, spec=spec, choices=choices)])

    def _model_base(self):
        if self.cf and self.cf.path:
            return os.path.splitext(os.path.basename(self.cf.path))[0]
        return "model"

    # ---------------------------------------------------------------- model
    def set_control_file(self, cf):
        self.cf = cf
        has = cf is not None
        self.placeholder.setVisible(not has)
        self.splitter.setVisible(has)
        if not has:
            self.ph_label.setText("This model has no {} ({}).\n\nCreate one to start adding commands, "
                                  "or open an existing file.".format(FILE_TYPE_INFO[self.ftype][1],
                                                                     FILE_TYPE_INFO[self.ftype][0]))
            self.path_label.setText("")
            return
        self.path_label.setText(cf.path or "(not saved)")
        self.dirty = False
        self.rebuild_table()

    def base_dir(self):
        return os.path.dirname(self.cf.path) if self.cf and self.cf.path else ""

    def rebuild_table(self, select_rows=None):
        if self.cf is None:
            return
        self._building = True
        self.table.clearSpans()
        self.table.setRowCount(0)
        depth = 0
        self.table.setRowCount(len(self.cf.entries))
        for row, e in enumerate(self.cf.entries):
            role = e.block_role
            if role in ("close", "mid"):
                depth = max(0, depth - 1)
            self._build_row(row, e, depth)
            if role in ("open", "mid"):
                depth += 1
        self._building = False
        if select_rows:
            self.table.clearSelection()
            for r in select_rows:
                if 0 <= r < self.table.rowCount():
                    self.table.selectRow(r)
        self.refresh_preview()
        self.update_status()

    def _build_row(self, row, e, depth):
        on = QTableWidgetItem()
        on.setFlags(Qt.ItemFlag.ItemIsUserCheckable | Qt.ItemFlag.ItemIsEnabled | Qt.ItemFlag.ItemIsSelectable)
        self.table.setItem(row, 0, on)
        if e.kind == "blank":
            on.setFlags(Qt.ItemFlag.ItemIsEnabled | Qt.ItemFlag.ItemIsSelectable)
            it = QTableWidgetItem("")
            it.setFlags(Qt.ItemFlag.ItemIsEnabled | Qt.ItemFlag.ItemIsSelectable)
            self.table.setItem(row, 1, it)
            self.table.setSpan(row, 1, 1, 3)
            return
        if e.kind == "comment":
            on.setFlags(Qt.ItemFlag.ItemIsEnabled | Qt.ItemFlag.ItemIsSelectable)
            on.setText("!")
            le = QLineEdit(e.comment.strip())
            le.setStyleSheet("color: #5f7f5f; font-style: italic;")
            le.textChanged.connect(lambda t, en=e: self._set_attr(en, "comment", " " + t))
            self.table.setCellWidget(row, 1, le)
            self.table.setSpan(row, 1, 1, 3)
            return
        on.setCheckState(Qt.CheckState.Checked if e.enabled else Qt.CheckState.Unchecked)
        on.setToolTip("Untick to comment the command out")
        cell = CommandCell(e, depth)
        cell.changed.connect(lambda lhs, ch, en=e: self._set_lhs(en, lhs, ch))
        self.table.setCellWidget(row, 1, cell)
        ed = make_value_editor(e.spec, self.base_dir, names_fn=self.names_fn)
        ed.setValue(e.value)
        ed.changed.connect(lambda v, en=e, r=row: self._set_value(en, v))
        if hasattr(ed, "openRequested"):
            ed.openRequested.connect(lambda en=e: self._open_linked(en))
        if e.spec is not None and not e.spec.has_value:
            ed.setEnabled(False)
        self.table.setCellWidget(row, 2, ed)
        cm = QLineEdit(e.comment)
        cm.setPlaceholderText("comment")
        cm.textChanged.connect(lambda t, en=e: self._set_attr(en, "comment", t))
        self.table.setCellWidget(row, 3, cm)
        if e.spec is not None:
            hb = QToolButton()
            hb.setText("?")
            hb.setToolTip("{}\n\nOpen in the TUFLOW manual".format(e.spec.syntax))
            hb.clicked.connect(lambda _=False, u=e.spec.url: qu.open_url(u))
            self.table.setCellWidget(row, 4, hb)
        self._update_row_status(row, e)

    def _set_attr(self, entry, attr, value):
        if self._building:
            return
        setattr(entry, attr, value)
        self._touch()

    def _set_value(self, entry, value):
        if self._building:
            return
        entry.value = value
        self._touch()
        row = self._row_of(entry)
        if row is not None:
            self._update_row_status(row, entry)

    def _set_lhs(self, entry, lhs, choices):
        if self._building or not lhs:
            return
        old_role = entry.block_role
        entry.lhs = lhs
        entry.choices = choices
        if entry.spec is None:
            spec, ch = catalog().match(self.ftype, lhs)
            if spec is not None:
                entry.spec, entry.choices = spec, ch
                self._touch()
                self.rebuild_table()
                return
        self._touch()
        if entry.block_role != old_role:
            self.rebuild_table()

    def _row_of(self, entry):
        for i, e in enumerate(self.cf.entries):
            if e is entry:
                return i
        return None

    def _item_changed(self, item):
        if self._building or item.column() != 0 or self.cf is None:
            return
        row = item.row()
        e = self.cf.entries[row]
        if e.kind != "command":
            return
        enabled = item.checkState() == Qt.CheckState.Checked
        if enabled != e.enabled:
            e.enabled = enabled
            self._touch()
            self._update_row_status(row, e)

    def _touch(self):
        self.dirty = True
        self._preview_timer.start()
        self.changed.emit()

    # -------------------------------------------------------------- status
    def entry_issue(self, e):
        """Return (severity, text) for a row or (None, '')."""
        if e.kind != "command" or not e.enabled:
            return None, ""
        if e.spec is None:
            return "WARNING", "Unknown command"
        if e.spec.has_value and not e.value.strip() and e.spec.key not in ("Write Check Files",) \
                and e.block_role is None:
            lvl = "ERROR" if e.spec.key in REQUIRED.get(self.ftype, []) else "WARNING"
            return lvl, "No value"
        if e.spec.value_kind in ("gis", "grid", "file", "file_or_choice") and e.value.strip():
            if e.spec.value_kind == "file_or_choice" and e.value.strip().upper() in [o.upper() for o in e.spec.options]:
                return None, ""
            if TOKEN_RE.search(e.value):
                return "INFO", "Uses ~s~/~e~/<<variable>> tokens - checked in QC tab"
            for path, _layers in split_value_paths(e.value):
                if not path or not looks_like_path(path):
                    continue
                full = resolve_path(path, self.base_dir())
                variants = [full] if os.path.splitext(full)[1] else [full + x for x in (".shp", ".mif", ".gpkg", ".tif")]
                if not any(os.path.exists(v) for v in variants):
                    return "ERROR", "File not found: {}".format(full)
        return None, ""

    def _update_row_status(self, row, e):
        it = self.table.item(row, 0)
        if it is None:
            return
        sev, text = self.entry_issue(e)
        it.setBackground(QBrush(SEVERITY_COLORS[sev].lighter(170)) if sev else QBrush())
        tip = text or ("Untick to comment out" if e.kind == "command" else "")
        it.setToolTip(tip)

    def update_status(self):
        if self.cf is None:
            return
        errs = self.cf.block_errors()
        n_err = sum(1 for e in self.cf.entries if self.entry_issue(e)[0] == "ERROR")
        n_warn = sum(1 for e in self.cf.entries if self.entry_issue(e)[0] == "WARNING")
        present = {e.key.lower() for e in self.cf.commands()}
        missing = [k for k in REQUIRED.get(self.ftype, []) if k.lower() not in present
                   and not k.lower().startswith(("define", "end define", "bc event source"))]
        parts = []
        if missing:
            parts.append("<span style='color:#c0392b'>Missing required: {}</span>".format(", ".join(missing)))
        if errs:
            parts.append("<span style='color:#c0392b'>Block errors: {}</span>".format(
                "; ".join("line {}: {}".format(l, m) for l, m in errs)))
        parts.append("{} commands | {} row errors | {} row warnings".format(len(self.cf.commands()), n_err, n_warn))
        self.status.setText("<br>".join(parts))

    # ------------------------------------------------------------ editing
    def selected_rows(self):
        return sorted({i.row() for i in self.table.selectedIndexes()})

    def insert_entries(self, entries):
        if self.cf is None:
            return
        rows = self.selected_rows()
        pos = (rows[-1] + 1) if rows else len(self.cf.entries)
        if not rows and self.ftype == "TCF":
            # keep 'Event File' last, as the manual recommends
            ev = [i for i, e in enumerate(self.cf.entries) if e.kind == "command" and e.key == "Event File"]
            if ev:
                pos = ev[-1]
                while pos > 0 and self.cf.entries[pos - 1].kind in ("comment", "blank"):
                    pos -= 1
        for i, e in enumerate(entries):
            self.cf.entries.insert(pos + i, e)
        self._touch()
        self.rebuild_table(select_rows=list(range(pos, pos + len(entries))))
        self.table.scrollToItem(self.table.item(pos, 0))

    def add_comment(self):
        text, ok = QInputDialog.getText(self, "Comment", "Comment text:")
        if ok:
            self.insert_entries([Entry("comment", comment=" " + text)])

    def delete_rows(self):
        rows = self.selected_rows()
        if not rows:
            return
        for r in reversed(rows):
            del self.cf.entries[r]
        self._touch()
        self.rebuild_table(select_rows=[min(rows[0], len(self.cf.entries) - 1)])

    def duplicate_rows(self):
        rows = self.selected_rows()
        if not rows:
            return
        copies = [self.cf.entries[r].copy() for r in rows]
        pos = rows[-1] + 1
        for i, e in enumerate(copies):
            self.cf.entries.insert(pos + i, e)
        self._touch()
        self.rebuild_table(select_rows=list(range(pos, pos + len(copies))))

    def move(self, d):
        rows = self.selected_rows()
        if not rows:
            return
        ents = self.cf.entries
        if d < 0 and rows[0] == 0 or d > 0 and rows[-1] == len(ents) - 1:
            return
        block = [ents[r] for r in rows]
        for r in reversed(rows):
            del ents[r]
        pos = rows[0] + d
        for i, e in enumerate(block):
            ents.insert(pos + i, e)
        self._touch()
        self.rebuild_table(select_rows=list(range(pos, pos + len(block))))

    def toggle_rows(self):
        rows = self.selected_rows()
        for r in rows:
            e = self.cf.entries[r]
            if e.kind == "command":
                e.enabled = not e.enabled
        self._touch()
        self.rebuild_table(select_rows=rows)

    def wrap_if(self):
        rows = self.selected_rows()
        if self.cf is None or not rows:
            QMessageBox.information(self, "If block", "Select the rows to wrap first.")
            return
        kind, ok = QInputDialog.getItem(self, "If block", "Block type:", ["If Scenario", "If Event"], 0, False)
        if not ok:
            return
        names, ok = QInputDialog.getText(self, kind, "{} names (separate with |):".format(kind.split()[1]))
        if not ok or not names.strip():
            return
        with_else = QMessageBox.question(self, kind, "Add an 'Else' part?") == QMessageBox.StandardButton.Yes
        ents = self.cf.entries
        ents.insert(rows[-1] + 1, _entry(self.ftype, "End If"))
        if with_else:
            ents.insert(rows[-1] + 1, _entry(self.ftype, "Else"))
        ents.insert(rows[0], _entry(self.ftype, kind, names.strip()))
        self._touch()
        self.rebuild_table(select_rows=[rows[0]])

    def _open_linked(self, entry):
        spec = entry.spec
        if spec is None:
            return
        if spec.child_type:
            self.openChildRequested.emit(spec.child_type)
            return
        paths = split_value_paths(entry.value)
        if paths:
            self.openDatabaseRequested.emit(resolve_path(paths[0][0], self.base_dir()))

    # ------------------------------------------------------------- preview
    def refresh_preview(self):
        if self.cf is None or self.edit_text.isChecked():
            return
        sb = self.preview.verticalScrollBar().value()
        self.preview.setPlainText(self.cf.to_text())
        self.preview.verticalScrollBar().setValue(sb)
        self.update_status()

    def _toggle_text_edit(self, on):
        self.preview.setReadOnly(not on)
        self.apply_btn.setEnabled(on)
        self.table.setEnabled(not on)
        if not on:
            self.refresh_preview()

    def apply_text(self):
        if self.cf is None:
            return
        self.cf.set_text(self.preview.toPlainText())
        self.edit_text.setChecked(False)
        self._touch()
        self.rebuild_table()

    # ---------------------------------------------------------------- files
    def open_file(self):
        ext = FILE_TYPE_INFO[self.ftype][0]
        start = self.base_dir()
        f, _ = QFileDialog.getOpenFileName(self, "Open " + ext, start,
                                           "{} (*{});;All files (*)".format(FILE_TYPE_INFO[self.ftype][1], ext))
        if not f:
            return
        self.set_control_file(ControlFile.read(self.ftype, f))
        self.fileReplaced.emit(self.ftype)

    def save(self):
        if self.cf is None:
            return False
        if not self.cf.path:
            return self.save_as()
        try:
            self.cf.save()
        except Exception as ex:
            QMessageBox.critical(self, "Save", "Could not save:\n{}".format(ex))
            return False
        self.dirty = False
        self.path_label.setText(self.cf.path)
        qu.message("Saved {}".format(self.cf.path), "success", 3)
        return True

    def save_as(self):
        if self.cf is None:
            return False
        ext = FILE_TYPE_INFO[self.ftype][0]
        f, _ = QFileDialog.getSaveFileName(self, "Save " + ext, self.cf.path or self.base_dir(), "*{}".format(ext))
        if not f:
            return False
        if not f.lower().endswith(ext):
            f += ext
        self.cf.path = f
        ok = self.save()
        self.fileReplaced.emit(self.ftype)
        return ok

    def reload(self):
        if self.cf is None or not self.cf.path or not os.path.isfile(self.cf.path):
            return
        if self.dirty and QMessageBox.question(self, "Reload", "Discard unsaved edits?") != QMessageBox.StandardButton.Yes:
            return
        fresh = ControlFile.read(self.ftype, self.cf.path)
        self.cf.entries = fresh.entries
        self.set_control_file(self.cf)


def _entry(ftype, key, value=""):
    spec, ch = catalog().match(ftype, key)
    return Entry("command", lhs=spec.build_lhs(ch) if spec else key, value=value, spec=spec, choices=ch or [])


def _esc(t):
    return (t or "").replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")


def _wrap_tip(t):
    """Rich-text tooltip so long explanations wrap instead of running off the screen."""
    return "<qt>{}</qt>".format(_esc(t).replace("\n", "<br>")) if t else ""
