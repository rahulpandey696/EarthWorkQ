# -*- coding: utf-8 -*-
"""Project, databases, batch/run, QC, logs, results and help tabs."""
import csv
import io
import os
import re

from qgis.PyQt.QtCore import Qt, pyqtSignal, QProcess, QObject, QTimer
from qgis.PyQt.QtGui import QBrush, QColor, QTextCursor
from qgis.PyQt.QtWidgets import (QWidget, QVBoxLayout, QHBoxLayout, QFormLayout, QGridLayout, QGroupBox, QLabel,
                                 QLineEdit, QPushButton, QComboBox, QCheckBox, QDoubleSpinBox, QSpinBox,
                                 QFileDialog, QMessageBox, QTreeWidget, QTreeWidgetItem, QTableWidget,
                                 QTableWidgetItem, QHeaderView, QAbstractItemView, QPlainTextEdit, QTabWidget,
                                 QSplitter, QTextBrowser, QListWidget, QListWidgetItem, QToolButton, QMenu,
                                 QScrollArea, QInputDialog)

from ..core import logs as L
from ..core.batch import BatchConfig, SWITCH_HELP
from ..core.catalog import FILE_TYPE_INFO, CONTROL_FILE_TYPES
from ..core.help_links import HELP_TREE, CONTROL_FILE_HELP
from ..core.project import BC_DBASE_HEADER, MATERIALS_HEADER
from ..core.qc import ModelChecker
from ..core.essentials import MAP_DATA_TYPES, MAP_FORMATS
from . import qgis_utils as qu
from .widgets import (PathEdit, TokenListEdit, LineChart, LogHighlighter, SEVERITY_COLORS, mono_font, bold_font,
                      RadioChoice, NumberSpin, ChoiceEdit, ExplainDelegate, LEVEL_COLORS, SmartDoubleSpin, LogView,
                      SEVERITY_TINTS,
                      SmartIntSpin, link_spins, TableClipboard)


def _btn(text, slot, tip=""):
    b = QPushButton(text)
    b.clicked.connect(slot)
    if tip:
        b.setToolTip(tip)
    return b


def _tint_row(table, row, sev):
    """Light red / amber / blue / green background for a whole table row."""
    col = SEVERITY_TINTS.get(str(sev).upper())
    if col is None:
        return
    for c in range(table.columnCount()):
        it = table.item(row, c)
        if it is not None:
            it.setBackground(QBrush(col))


def _sev_item(sev):
    it = QTableWidgetItem(sev)
    col = SEVERITY_COLORS.get(sev)
    if col is not None:
        it.setForeground(QBrush(col))
        it.setFont(bold_font())
    return it


# ===========================================================================
class ProjectTab(QWidget):
    newModelRequested = pyqtSignal(dict)
    openModelRequested = pyqtSignal(str)
    saveAllRequested = pyqtSignal()
    showTab = pyqtSignal(str)

    def __init__(self, parent=None):
        super().__init__(parent)
        self._build()

    def _build(self):
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        host = QWidget()
        lay = QVBoxLayout(host)
        outer = QVBoxLayout(self)
        outer.setContentsMargins(0, 0, 0, 0)
        outer.addWidget(scroll)
        scroll.setWidget(host)

        intro = QLabel("<h3>FMB tools</h3>Build, check and run TUFLOW Classic/HPC models from QGIS. "
                       "Start a new model with the quick set-up below, or open an existing <b>.tcf</b> - every "
                       "control file it references opens in its own tab.")
        intro.setWordWrap(True)
        lay.addWidget(intro)

        # -- open / current
        g0 = QGroupBox("Current model")
        f0 = QGridLayout(g0)
        self.cur_label = QLabel("No model loaded")
        self.cur_label.setWordWrap(True)
        f0.addWidget(self.cur_label, 0, 0, 1, 4)
        f0.addWidget(_btn("Open existing .tcf ...", self._open), 1, 0)
        f0.addWidget(_btn("Save all control files", self.saveAllRequested.emit), 1, 1)
        f0.addWidget(_btn("Open model folder", lambda: qu.open_path(self.root.value())), 1, 2)
        self.folders_btn = _btn("Create TUFLOW folder structure...", self.create_folders,
                                "Create bc_dbase, check, model (gis, grid), results and runs (log) folders at a "
                                "location you choose")
        f0.addWidget(self.folders_btn, 1, 3)
        self.last_btn = _btn("Reopen last model", lambda: self.openModelRequested.emit(self._last))
        self.last_btn.setVisible(False)
        self._last = ""
        f0.addWidget(self.last_btn, 1, 4)
        self.files_tree = QTreeWidget()
        self.files_tree.setHeaderLabels(["File", "Path", "Status"])
        self.files_tree.setMinimumHeight(150)
        self.files_tree.itemDoubleClicked.connect(lambda it, _c: self.showTab.emit(it.text(0)))
        f0.addWidget(self.files_tree, 2, 0, 1, 5)
        lay.addWidget(g0)

        # -- new model
        g1 = QGroupBox("Quick set-up of a new model")
        form = QFormLayout(g1)
        self.root = PathEdit("folder", "", lambda: "")
        self.root.line.setPlaceholderText("Model root folder (bc_dbase, check, model, results, runs are created)")
        rrow = QHBoxLayout()
        rrow.addWidget(self.root, 1)
        rrow.addWidget(_btn("Create folders...", self.create_folders,
                            "Create only the TUFLOW folder structure (no control files)"))
        form.addRow("Root folder", rrow)
        self.name = QLineEdit("M01_001")
        self.name.setToolTip("TCF name. You can use ~s1~ and ~e1~ tokens, e.g. M01_~s1~_~e1~_001")
        form.addRow("Model (TCF) name", self.name)

        self.solver = RadioChoice(["HPC", "CLASSIC"], "HPC")
        self.solver.setValue("HPC")
        self.solver.setToolTip("HPC: adaptive timestep, CPU or GPU, required for Quadtree and SGS.\n"
                               "CLASSIC: fixed timestep implicit solver.")
        form.addRow("Solution scheme", self.solver)
        self.hardware = RadioChoice(["GPU", "CPU"], "CPU")
        self.hardware.setValue("GPU")
        form.addRow("Hardware", self.hardware)
        row = QHBoxLayout()
        self.sgs = QCheckBox("Sub-grid sampling (SGS)")
        self.sgs.setChecked(True)
        self.quadtree = QCheckBox("Quadtree mesh (QCF)")
        self.one_d = QCheckBox("1D network (ECF)")
        for w in (self.sgs, self.quadtree, self.one_d):
            row.addWidget(w)
        row.addStretch(1)
        form.addRow("Features", row)
        self.solver.changed.connect(self._solver_changed)

        self.units = RadioChoice(["METRIC", "US Customary"], "METRIC")
        self.units.setValue("METRIC")
        form.addRow("Units", self.units)
        self.gisfmt = RadioChoice(["GPKG", "SHP", "MIF"], "")
        self.gisfmt.setValue("GPKG")
        self.gisfmt.setToolTip("GPKG: one GeoPackage spatial database (recommended). SHP / MIF: one file per layer.")
        form.addRow("GIS format", self.gisfmt)

        row = QHBoxLayout()
        self.cell = SmartDoubleSpin()
        self.cell.setRange(0.1, 10000)
        self.cell.setValue(5)
        self.cell.setSuffix(" m")
        self.gx = SmartDoubleSpin()
        self.gy = SmartDoubleSpin()
        for s in (self.gx, self.gy):
            s.setRange(0, 1e7)
            s.setDecimals(1)
            s.setSuffix(" m")
        link_spins([self.gx, self.gy])
        self.gx.setToolTip("Domain length in X. Paste 'X, Y' here to fill both boxes.")
        self.gy.setToolTip("Domain length in Y")
        for w in (QLabel("Cell size"), self.cell, QLabel("Domain X"), self.gx, QLabel("Y"), self.gy):
            row.addWidget(w)
        row.addStretch(1)
        form.addRow("2D grid", row)
        row = QHBoxLayout()
        self.ox = NumberSpin("m", False, -1e9, 1e9, 1.0, prefix="X")
        self.oy = NumberSpin("m", False, -1e9, 1e9, 1.0, prefix="Y")
        link_spins([self.ox, self.oy])
        self.ox.setToolTip("Grid origin X (lower-left corner). Paste 'X, Y' or 'X Y' here to fill both boxes.")
        self.ox.setMinimumWidth(170)
        self.oy.setMinimumWidth(170)
        for w in (self.ox, self.oy, QLabel("<i>or use a 2d_loc line below</i>")):
            row.addWidget(w)
        row.addStretch(1)
        form.addRow("Grid origin", row)
        self.extent_layer = QComboBox()
        self.extent_layer.setToolTip("Fill grid size and origin from a layer's extent")
        erow = QHBoxLayout()
        erow.addWidget(self.extent_layer, 1)
        erow.addWidget(_btn("Refresh layers", self.refresh_layers))
        erow.addWidget(_btn("Use extent", self._use_extent))
        form.addRow("Grid from layer", erow)

        self.dem = PathEdit("grid", "Grids (*.tif *.asc *.flt)", self._tgc_dir)
        form.addRow("DEM (Read Grid Zpts)", self.dem)
        self.code = PathEdit("gis", "", self._tgc_dir)
        form.addRow("2d_code (active area)", self.code)
        self.loc = PathEdit("gis", "", self._tgc_dir)
        form.addRow("2d_loc (optional)", self.loc)
        self.mat = PathEdit("gis", "", self._tgc_dir)
        form.addRow("2d_mat (materials)", self.mat)
        self.bc = PathEdit("gis", "", self._tgc_dir)
        form.addRow("2d_bc (boundaries)", self.bc)
        self.proj = PathEdit("gis", "", self._tcf_dir)
        form.addRow("Projection layer", self.proj)

        row = QHBoxLayout()
        self.start = SmartDoubleSpin()
        self.end = SmartDoubleSpin()
        self.dt = SmartDoubleSpin()
        self.start.setRange(-1e5, 1e5)
        self.end.setRange(-1e5, 1e5)
        self.end.setValue(3)
        self.dt.setRange(0.001, 3600)
        self.dt.setDecimals(3)
        self.dt.setValue(1)
        link_spins([self.start, self.end])
        self.start.setSuffix(" h")
        self.end.setSuffix(" h")
        self.dt.setSuffix(" s")
        for w in (QLabel("Start"), self.start, QLabel("End"), self.end, QLabel("Timestep"), self.dt):
            row.addWidget(w)
        row.addStretch(1)
        form.addRow("Time", row)
        self.cell.valueChanged.connect(self._suggest_dt)

        row = QHBoxLayout()
        self.mapfmt = TokenListEdit([(f, "") for f in MAP_FORMATS])
        self.mapfmt.setValue("XMDF TIF")
        self.maptypes = TokenListEdit(MAP_DATA_TYPES)
        self.maptypes.setValue("h d V q Z0")
        self.mapint = SmartIntSpin()
        self.mapint.setRange(1, 864000)
        self.mapint.setValue(300)
        self.mapint.setSuffix(" s")
        self.tsint = SmartIntSpin()
        self.tsint.setRange(1, 864000)
        self.tsint.setValue(60)
        self.tsint.setSuffix(" s")
        for w in (QLabel("Formats"), self.mapfmt, QLabel("Types"), self.maptypes, QLabel("Map every"), self.mapint,
                  QLabel("TS every"), self.tsint):
            row.addWidget(w)
        form.addRow("Output", row)

        self.inflow = RadioChoice(["Boundary inflows (2d_bc)", "Direct rainfall", "Both"])
        self.inflow.setValue("Boundary inflows (2d_bc)")
        self.inflow.setToolTip("Direct rainfall adds a Global Rainfall BC and sets Cell Wet/Dry Depth to 0.0002 m")
        form.addRow("Hydrology input", self.inflow)
        self.events = ChoiceEdit(["1p, 5p, 10p", "1p, 2p, 5p, 10p, 20p, 50p", "Q010, Q050, Q100",
                                  "1p, 1p_CC", "PMF"], editable=True)
        self.events.lineEdit().setPlaceholderText("none - or type names separated by commas (creates an event file)")
        form.addRow("Events", self.events)
        self.create_btn = _btn("Create new model", self._create)
        self.create_btn.setStyleSheet("font-weight: bold; padding: 6px;")
        form.addRow("", self.create_btn)
        lay.addWidget(g1)
        lay.addStretch(1)
        self.refresh_layers()

    def create_folders(self):
        """Create the standard TUFLOW folders at a location the user picks."""
        from .folders_dialog import FolderStructureDialog
        cur = self.root.value().strip()
        start = os.path.dirname(cur.rstrip("/\\")) if cur and os.path.isdir(cur) else cur
        dlg = FolderStructureDialog(start, self)
        if cur and os.path.isdir(cur) and os.path.isdir(os.path.join(cur, "model")):
            dlg.location.setValue(cur)           # an existing model root - add the missing folders
            dlg.use_sub.setChecked(False)
        from .widgets import qexec
        qexec(dlg)
        if dlg.root and dlg.set_root.isChecked():
            self.root.setValue(dlg.root)
        return dlg.root

    def reset_form(self):
        """Put every quick set-up field back to its default."""
        self.root.setValue("")
        self.name.setText("M01_001")
        self.solver.setValue("HPC")
        self.hardware.setValue("GPU")
        self._solver_changed("HPC")
        self.sgs.setChecked(True)
        self.quadtree.setChecked(False)
        self.one_d.setChecked(False)
        self.units.setValue("METRIC")
        self.gisfmt.setValue("GPKG")
        self.cell.setValue(5)
        self.gx.setValue(0)
        self.gy.setValue(0)
        self.ox.unset()
        self.oy.unset()
        for w in (self.dem, self.code, self.loc, self.mat, self.bc, self.proj):
            w.setValue("")
        self.start.setValue(0)
        self.end.setValue(3)
        self.dt.setValue(1)
        self.mapfmt.setValue("XMDF TIF")
        self.maptypes.setValue("h d V q Z0")
        self.mapint.setValue(300)
        self.tsint.setValue(60)
        self.inflow.setValue("Boundary inflows (2d_bc)")
        self.events.setValue("")

    def set_last(self, path):
        self._last = path
        self.last_btn.setVisible(bool(path))
        self.last_btn.setToolTip(path)

    def _tcf_dir(self):
        return os.path.join(self.root.value(), "runs") if self.root.value() else ""

    def _tgc_dir(self):
        return os.path.join(self.root.value(), "model") if self.root.value() else ""

    def _solver_changed(self, v):
        hpc = v == "HPC"
        for w in (self.hardware, self.sgs, self.quadtree):
            w.setEnabled(hpc)
        self._suggest_dt()

    def _suggest_dt(self, *_):
        if self.solver.value() == "CLASSIC":
            self.dt.setValue(round(self.cell.value() / 4.0, 3) or 0.5)
            self.dt.setToolTip("Classic: ~1/4 of the cell size (m) in seconds")
        else:
            self.dt.setToolTip("HPC: initial timestep only (adaptive)")

    def refresh_layers(self):
        self.extent_layer.clear()
        for name, _src, _t, lyr in qu.project_layers():
            self.extent_layer.addItem(name, lyr)

    def _use_extent(self):
        lyr = self.extent_layer.currentData()
        ext = qu.layer_extent(lyr) if lyr is not None else None
        if not ext:
            QMessageBox.information(self, "Extent", "Pick a layer loaded in QGIS.")
            return
        cs = self.cell.value()
        import math
        x0 = math.floor(ext[0] / cs) * cs
        y0 = math.floor(ext[1] / cs) * cs
        self.ox.setValue(x0)
        self.oy.setValue(y0)
        self.gx.setValue(math.ceil((ext[2] - x0) / cs) * cs)
        self.gy.setValue(math.ceil((ext[3] - y0) / cs) * cs)

    def _open(self):
        f, _ = QFileDialog.getOpenFileName(self, "Open TUFLOW Control File", self.root.value(),
                                           "TUFLOW Control File (*.tcf);;All files (*)")
        if f:
            self.openModelRequested.emit(f)

    def options(self):
        def g(v):
            return "{:g}".format(v)
        tgc_dir = self._tgc_dir()
        rel = lambda w: w.value().strip()
        opts = dict(
            name=self.name.text().strip() or "M01_001",
            solver=self.solver.value() or "HPC", hardware=self.hardware.value() or "GPU",
            sgs=self.sgs.isChecked() and self.solver.value() == "HPC",
            quadtree=self.quadtree.isChecked() and self.solver.value() == "HPC",
            units=self.units.value() or "METRIC", gis_format=self.gisfmt.value() or "GPKG",
            cell_size=g(self.cell.value()),
            grid_size="{}, {}".format(g(self.gx.value()), g(self.gy.value())) if self.gx.value() and self.gy.value() else "",
            origin="{}, {}".format(self.ox.text_value(), self.oy.text_value()) if self.ox.is_set() and self.oy.is_set() else "",
            dem=None, code_layer=rel(self.code), loc_layer=rel(self.loc), mat_layer=rel(self.mat), bc_layer=rel(self.bc),
            projection_layer=self.proj.value().strip(),
            start=g(self.start.value()), end=g(self.end.value()), timestep=g(self.dt.value()),
            timestep_1d=g(self.dt.value() / 2.0),
            map_format=self.mapfmt.value(), map_types=self.maptypes.value(), map_interval=self.mapint.value(),
            ts_interval=self.tsint.value(), one_d=self.one_d.isChecked(),
            direct_rainfall=self.inflow.value() in ("Direct rainfall", "Both"),
            events=[e.strip() for e in self.events.value().replace(";", ",").replace("|", ",").split(",") if e.strip()],
        )
        dem = self.dem.value().strip()
        if dem:
            from ..core.control_file import resolve_path
            opts["dem"] = resolve_path(dem.split("|")[0], tgc_dir)
        return opts

    def _create(self):
        if not self.root.value().strip():
            QMessageBox.warning(self, "New model", "Choose a root folder first.")
            return
        self.newModelRequested.emit(self.options())

    def show_project(self, project, editors):
        if project is None:
            self.cur_label.setText("No model loaded")
            self.files_tree.clear()
            return
        self.root.setValue(project.root)
        self.cur_label.setText("<b>{}</b><br>{}".format(project.name, project.root))
        self.files_tree.clear()
        for ft in CONTROL_FILE_TYPES:
            cf = project.files.get(ft)
            if cf is None:
                continue
            ed = editors.get(ft)
            status = "not saved" if not os.path.isfile(cf.path) else ("modified" if ed and ed.dirty else "saved")
            it = QTreeWidgetItem([ft, cf.path, status])
            if status != "saved":
                it.setForeground(2, QBrush(SEVERITY_COLORS["WARNING"]))
            self.files_tree.addTopLevelItem(it)
        self.files_tree.resizeColumnToContents(0)


# ===========================================================================
class EventWizard(QGroupBox):
    """Generates Define Event blocks for the TEF."""
    generate = pyqtSignal(list)   # list of (event, [(text, value)])

    def __init__(self, parent=None):
        super().__init__("Event generator", parent)
        lay = QGridLayout(self)
        lay.addWidget(QLabel("Event text in bc_dbase / file names"), 0, 0)
        self.text1 = QLineEdit("~AEP~")
        lay.addWidget(self.text1, 0, 1)
        lay.addWidget(QLabel("Values (comma separated)"), 0, 2)
        self.vals1 = QLineEdit("1p, 5p, 10p")
        lay.addWidget(self.vals1, 0, 3)
        lay.addWidget(QLabel("Second event text (optional)"), 1, 0)
        self.text2 = QLineEdit("~DUR~")
        lay.addWidget(self.text2, 1, 1)
        lay.addWidget(QLabel("Values"), 1, 2)
        self.vals2 = QLineEdit("")
        self.vals2.setPlaceholderText("e.g. 60m, 120m (leave empty to skip)")
        lay.addWidget(self.vals2, 1, 3)
        b = _btn("Add Define Event blocks", self._go, "Creates one block per value (e1) and per second value (e2)")
        lay.addWidget(b, 0, 4, 2, 1)

    def _go(self):
        v1 = [v.strip() for v in self.vals1.text().split(",") if v.strip()]
        v2 = [v.strip() for v in self.vals2.text().split(",") if v.strip()]
        out = [(v, [(self.text1.text().strip(), v)]) for v in v1]
        out += [(v, [(self.text2.text().strip(), v)]) for v in v2]
        if out:
            self.generate.emit(out)


# ===========================================================================
class DatabaseTab(QWidget):
    TEMPLATES = {
        "BC database (bc_dbase.csv)": BC_DBASE_HEADER,
        "Materials (materials.csv)": MATERIALS_HEADER,
        "Flow hydrograph (Time, Flow)": ["Time (h)", "Flow (m3/s)"],
        "Water level (Time, Level)": ["Time (h)", "Level (m)"],
        "Rainfall hyetograph (Time, Rainfall)": ["Time (h)", "Rainfall (mm)"],
        "HQ curve (Level, Flow)": ["Level (m)", "Flow (m3/s)"],
        "Pit inlet database": ["Name", "Source", "Column 1", "Column 2", "Width"],
    }

    def __init__(self, parent=None):
        super().__init__(parent)
        self.path = ""
        self.known = []
        lay = QVBoxLayout(self)
        top = QHBoxLayout()
        self.combo = QComboBox()
        self.combo.setMinimumWidth(360)
        self.combo.activated.connect(lambda i: self.load(self.combo.itemData(i)))
        top.addWidget(QLabel("Table"))
        top.addWidget(self.combo, 1)
        top.addWidget(_btn("Open CSV...", self._open))
        nb = QToolButton()
        nb.setText("New from template")
        nb.setPopupMode(QToolButton.ToolButtonPopupMode.InstantPopup)
        m = QMenu(nb)
        for name in self.TEMPLATES:
            a = m.addAction(name)
            a.triggered.connect(lambda _=False, n=name: self.new_table(n))
        nb.setMenu(m)
        top.addWidget(nb)
        top.addWidget(_btn("Save", self.save))
        top.addWidget(_btn("Save as...", self.save_as))
        lay.addLayout(top)
        row = QHBoxLayout()
        for t, s in (("+ Row", self.add_row), ("- Row", self.del_row), ("+ Column", self.add_col),
                     ("- Column", self.del_col), ("Check source files", self.check_sources),
                     ("Browse source file...", self.browse_source), ("Open source file", self.open_source),
                     ("Plot selected columns", self.plot)):
            row.addWidget(_btn(t, s))
        row.addStretch(1)
        lay.addLayout(row)
        split = QSplitter(Qt.Orientation.Vertical)
        self.table = QTableWidget(0, 0)
        self.table.setSelectionMode(QAbstractItemView.SelectionMode.ExtendedSelection)
        self.table.setToolTip("Ctrl+C / Ctrl+V copy and paste blocks of cells (e.g. from Excel); Delete clears.")
        self.clip = TableClipboard(self.table, self._auto_col)
        split.addWidget(self.table)
        self.chart = LineChart()
        split.addWidget(self.chart)
        split.setSizes([500, 220])
        lay.addWidget(split, 1)
        self.msg = QLabel("")
        self.msg.setWordWrap(True)
        lay.addWidget(self.msg)

    def set_known(self, items):
        """items: [(label, path)]"""
        self.known = items
        cur = self.path
        self.combo.clear()
        for label, p in items:
            self.combo.addItem("{}  -  {}".format(label, p), p)
        if cur:
            i = self.combo.findData(cur)
            if i >= 0:
                self.combo.setCurrentIndex(i)

    def _open(self):
        f, _ = QFileDialog.getOpenFileName(self, "Open table", os.path.dirname(self.path), "CSV (*.csv);;All files (*)")
        if f:
            self.load(f)

    def load(self, path):
        self.path = path or ""
        self.table.clear()
        rows = []
        if path and os.path.isfile(path):
            with io.open(path, newline="", encoding="utf-8-sig", errors="replace") as fh:
                rows = list(csv.reader(fh))
        header = rows[0] if rows else []
        body = rows[1:] if rows else []
        ncol = max([len(header)] + [len(r) for r in body] + [1])
        self.table.setColumnCount(ncol)
        self.table.setHorizontalHeaderLabels(header + [""] * (ncol - len(header)))
        self.table.setRowCount(len(body))
        for r, row in enumerate(body):
            for c, v in enumerate(row):
                self.table.setItem(r, c, QTableWidgetItem(v))
        self.msg.setText(path if os.path.isfile(path or "") else "{} (new - not saved yet)".format(path or "untitled"))
        i = self.combo.findData(path)
        if i >= 0:
            self.combo.setCurrentIndex(i)

    def new_table(self, name):
        header = self.TEMPLATES[name]
        self.path = ""
        self.table.clear()
        self.table.setColumnCount(len(header))
        self.table.setRowCount(3)
        self.table.setHorizontalHeaderLabels(header)
        self.msg.setText("New table from template '{}' - use Save as.".format(name))

    def _header(self):
        return [self.table.horizontalHeaderItem(c).text() if self.table.horizontalHeaderItem(c) else ""
                for c in range(self.table.columnCount())]

    def rows(self):
        out = []
        for r in range(self.table.rowCount()):
            row = [(self.table.item(r, c).text() if self.table.item(r, c) else "") for c in range(self.table.columnCount())]
            out.append(row)
        while out and not any(out[-1]):
            out.pop()
        return out

    def save(self):
        if not self.path:
            return self.save_as()
        os.makedirs(os.path.dirname(self.path) or ".", exist_ok=True)
        with io.open(self.path, "w", newline="", encoding="utf-8") as fh:
            w = csv.writer(fh)
            w.writerow(self._header())
            for r in self.rows():
                w.writerow(r)
        self.msg.setText("Saved {}".format(self.path))
        return True

    def save_as(self):
        f, _ = QFileDialog.getSaveFileName(self, "Save table", self.path, "CSV (*.csv)")
        if not f:
            return False
        if not f.lower().endswith(".csv"):
            f += ".csv"
        self.path = f
        return self.save()

    def add_row(self):
        r = (self.table.currentRow() + 1) if self.table.currentRow() >= 0 else self.table.rowCount()
        self.table.insertRow(r)

    def del_row(self):
        for r in sorted({i.row() for i in self.table.selectedIndexes()}, reverse=True):
            self.table.removeRow(r)

    def add_col(self):
        name, ok = QInputDialog.getText(self, "Column", "Header:")
        if ok:
            c = self.table.columnCount()
            self.table.insertColumn(c)
            self.table.setHorizontalHeaderItem(c, QTableWidgetItem(name))

    def _auto_col(self):
        c = self.table.columnCount()
        self.table.insertColumn(c)
        self.table.setHorizontalHeaderItem(c, QTableWidgetItem("Column {}".format(c + 1)))

    def del_col(self):
        for c in sorted({i.column() for i in self.table.selectedIndexes()}, reverse=True):
            self.table.removeColumn(c)

    def _source_col(self):
        h = [x.lower() for x in self._header()]
        return h.index("source") if "source" in h else None

    def check_sources(self):
        sc = self._source_col()
        if sc is None:
            self.msg.setText("No 'Source' column in this table.")
            return
        base = os.path.dirname(self.path)
        missing, tokens = [], 0
        for r, row in enumerate(self.rows()):
            src = row[sc].strip() if sc < len(row) else ""
            if not src:
                continue
            if "~" in src or "<<" in src:
                tokens += 1
                continue
            full = os.path.normpath(os.path.join(base, src.replace("\\", os.sep)))
            ok = os.path.exists(full)
            it = self.table.item(r, sc)
            if it:
                it.setBackground(QBrush(QColor("#ffffff") if ok else SEVERITY_COLORS["ERROR"].lighter(170)))
            if not ok:
                missing.append(src)
        self.msg.setText("{} missing source file(s){}. {}".format(
            len(missing), "" if not missing else ": " + ", ".join(missing[:8]),
            "{} source(s) use event tokens and are checked in the QC tab.".format(tokens) if tokens else ""))

    def browse_source(self):
        sc = self._source_col()
        r = self.table.currentRow()
        if sc is None:
            self.msg.setText("No 'Source' column in this table.")
            return
        if r < 0:
            self.add_row()
            r = self.table.currentRow() if self.table.currentRow() >= 0 else self.table.rowCount() - 1
        base = os.path.dirname(self.path) if self.path else ""
        f, _ = QFileDialog.getOpenFileName(self, "Source file", base, "CSV / time series (*.csv *.ts1 *.nc);;All files (*)")
        if not f:
            return
        from ..core.control_file import to_tuflow_path
        self.table.setItem(r, sc, QTableWidgetItem(to_tuflow_path(f, base) if base else f))
        self.check_sources()

    def open_source(self):
        sc = self._source_col()
        r = self.table.currentRow()
        if sc is None or r < 0 or not self.table.item(r, sc):
            return
        src = self.table.item(r, sc).text().strip()
        full = os.path.normpath(os.path.join(os.path.dirname(self.path), src.replace("\\", os.sep)))
        if full.lower().endswith(".csv") and os.path.isfile(full):
            self.load(full)
        else:
            qu.open_path(full)

    def plot(self):
        cols = sorted({i.column() for i in self.table.selectedIndexes()})
        if not cols:
            cols = list(range(self.table.columnCount()))
        data = self.rows()

        def num(v):
            try:
                return float(v)
            except (TypeError, ValueError):
                return None
        xs_col = cols[0] if len(cols) > 1 else 0
        ycols = cols[1:] if len(cols) > 1 else [c for c in range(1, self.table.columnCount())]
        series = []
        hdr = self._header()
        for c in ycols:
            pts = [(num(r[xs_col]), num(r[c])) for r in data if c < len(r)]
            pts = [(x, y) for x, y in pts if x is not None and y is not None]
            if pts:
                series.append((hdr[c] or "col {}".format(c + 1), [p[0] for p in pts], [p[1] for p in pts]))
        self.chart.set_data(series, os.path.basename(self.path), hdr[xs_col] if hdr else "", "")


# ===========================================================================
class RunManager(QObject):
    """Runs TUFLOW simulations one after another with QProcess."""
    output = pyqtSignal(str)
    runFinished = pyqtSignal(str, int)
    allFinished = pyqtSignal()

    def __init__(self, parent=None):
        super().__init__(parent)
        self.queue = []
        self.proc = None
        self.current = ""

    def start(self, jobs, workdir):
        self.queue = list(jobs)
        self.workdir = workdir
        self._next()

    def _next(self):
        if not self.queue:
            self.proc = None
            self.allFinished.emit()
            return
        name, cmd = self.queue.pop(0)
        self.current = name
        self.proc = QProcess(self)
        self.proc.setWorkingDirectory(self.workdir)
        self.proc.setProcessChannelMode(QProcess.ProcessChannelMode.MergedChannels)
        self.proc.readyReadStandardOutput.connect(self._read)
        self.proc.finished.connect(self._done)
        self.output.emit("\n=== Starting {}\n$ {}\n".format(name, " ".join('"{}"'.format(c) if " " in c else c for c in cmd)))
        self.proc.start(cmd[0], cmd[1:])
        if not self.proc.waitForStarted(5000):
            self.output.emit("Could not start {} - check the TUFLOW executable path.\n".format(cmd[0]))
            self.runFinished.emit(name, -1)
            self._next()

    def _read(self):
        data = bytes(self.proc.readAllStandardOutput())
        self.output.emit(data.decode("utf-8", errors="replace"))

    def _done(self, code, _status=None):
        self.output.emit("\n=== {} finished with exit code {}\n".format(self.current, code))
        self.runFinished.emit(self.current, code)
        QTimer.singleShot(0, self._next)

    def stop(self):
        self.queue = []
        if self.proc is not None:
            self.proc.kill()

    @property
    def running(self):
        return self.proc is not None


class BatchTab(QWidget):
    runsFinished = pyqtSignal()

    def __init__(self, parent=None):
        super().__init__(parent)
        self.cfg = BatchConfig()
        self.tcf_default = ""
        self.runner = RunManager(self)
        self.runner.output.connect(self._console)
        self.runner.allFinished.connect(self._finished)
        lay = QVBoxLayout(self)
        split = QSplitter(Qt.Orientation.Horizontal)
        lay.addWidget(split, 1)
        left = QWidget()
        form = QFormLayout(left)
        self.names_fn = lambda kind: []          # set by the main dialog
        self.exe = PathEdit("file", "TUFLOW executable (*.exe);;All files (*)", lambda: "")
        self.exe.setValue(self.cfg.exe)
        form.addRow("TUFLOW exe", self.exe)
        self.precision = RadioChoice(["Single precision (iSP)", "Double precision (iDP)"])
        self.precision.setToolTip("Switches the executable between the _iSP_ and _iDP_ builds")
        self.precision.changed.connect(self._precision_changed)
        self.exe.changed.connect(self._exe_changed)
        form.addRow("Precision", self.precision)
        self.tcf = PathEdit("file", "TCF (*.tcf)", lambda: "")
        form.addRow("TCF", self.tcf)

        pick = QHBoxLayout()
        self.s_list = QListWidget()
        self.e_list = QListWidget()
        for lst, title in ((self.s_list, "Scenarios  (-s1 / ~s1~)"), (self.e_list, "Events  (-e1 / ~e1~)")):
            box = QVBoxLayout()
            box.addWidget(QLabel("<b>{}</b>".format(title)))
            lst.setMaximumHeight(130)
            lst.itemChanged.connect(self._lists_to_slots)
            box.addWidget(lst)
            pick.addLayout(box)
        side = QVBoxLayout()
        side.addWidget(_btn("Refresh\nfrom model", self.refresh_names,
                            "List the scenario names used in If Scenario blocks and the events defined in the TEF"))
        side.addWidget(_btn("Add...", self._add_name, "Add a scenario or event name"))
        side.addStretch(1)
        pick.addLayout(side)
        form.addRow("Run", pick)
        self.runs_label = QLabel("")
        form.addRow("", self.runs_label)

        self.slots_box = QGroupBox("All switch slots (-s1..-s9, -e1..-e9)")
        self.slots_box.setCheckable(True)
        self.slots_box.setChecked(False)
        self.slots_box.setFlat(True)
        self.slots_box.setToolTip("Tick to show the -s2..-s9 / -e2..-e9 slots for models with several scenario or event dimensions")
        sb = QVBoxLayout(self.slots_box)
        self.slots = QTableWidget(18, 2)
        self.slots.setHorizontalHeaderLabels(["Switch", "Values (comma separated)"])
        self.slots.horizontalHeader().setSectionResizeMode(1, QHeaderView.ResizeMode.Stretch)
        self.slots.verticalHeader().setVisible(False)
        for i in range(9):
            for j, pre in enumerate(("s", "e")):
                r = i + 9 * j
                it = QTableWidgetItem("-{}{}  (~{}{}~)".format(pre, i + 1, pre, i + 1))
                it.setFlags(Qt.ItemFlag.ItemIsEnabled)
                self.slots.setItem(r, 0, it)
                self.slots.setItem(r, 1, QTableWidgetItem(""))
        self.slots.setMinimumHeight(230)
        self.slots.itemChanged.connect(self._slot_edited)
        sb.addWidget(self.slots)
        self.slots_box.toggled.connect(self.slots.setVisible)
        self.slots.setVisible(False)
        form.addRow(self.slots_box)

        row = QHBoxLayout()
        self.test = QCheckBox("Test mode (-t)")
        self.test.setToolTip("Read the inputs and write check files without simulating")
        self.gpu = TokenListEdit([(str(i), "GPU device {}".format(i)) for i in range(8)], placeholder="default device")
        self.gpu.setToolTip("GPU device ids passed as -pu<id>")
        self.extra = QLineEdit()
        self.extra.setPlaceholderText("extra switches")
        for w in (self.test, QLabel("GPU ids"), self.gpu, self.extra):
            row.addWidget(w)
        form.addRow("Switches", row)
        self.mode = RadioChoice(["sequential", "parallel", "call"])
        self.mode.setToolTip("sequential: one after another (start /wait)\nparallel: all at once\ncall: in the same window")
        form.addRow("Run mode", self.mode)
        self.platform = RadioChoice(["windows", "linux"])
        form.addRow("Script type", self.platform)
        self.test.toggled.connect(self.update_preview)
        self.gpu.changed.connect(self.update_preview)
        self.extra.textChanged.connect(self.update_preview)
        for w in (self.mode, self.platform):
            w.changed.connect(self.update_preview)
        self.exe.changed.connect(self.update_preview)
        self.tcf.changed.connect(self.update_preview)
        row = QHBoxLayout()
        row.addWidget(_btn("Save batch file...", self.save_batch))
        self.run_btn = _btn("Run in QGIS", self.run_now, "Run every combination one after another; output below")
        row.addWidget(self.run_btn)
        row.addWidget(_btn("Run test (-t)", self.run_test, "Check the model inputs without simulating"))
        self.stop_btn = _btn("Stop", self.runner.stop)
        row.addWidget(self.stop_btn)
        form.addRow("", row)
        sw = QLabel("<br>".join("<b>{}</b> {}".format(a, b) for a, b in SWITCH_HELP) +
                    '<br><a href="https://wiki.tuflow.com/Run_TUFLOW_From_a_Batch-file">Run TUFLOW from a batch file (wiki)</a>')
        sw.setWordWrap(True)
        sw.setOpenExternalLinks(True)
        form.addRow("Switches help", sw)
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setWidget(left)
        split.addWidget(scroll)
        right = QSplitter(Qt.Orientation.Vertical)
        self.preview = QPlainTextEdit()
        self.preview.setFont(mono_font())
        self.preview.setReadOnly(True)
        right.addWidget(self.preview)
        self.console = LogView("TUFLOW console output appears here when running from QGIS - errors in red, "
                               "warnings in amber, checks in blue.", max_blocks=20000)
        right.addWidget(self.console)
        split.addWidget(right)
        split.setSizes([520, 600])

    # -- scenario / event pickers -------------------------------------------
    def _slot_values(self, row):
        it = self.slots.item(row, 1)
        return [v.strip() for v in (it.text() if it else "").split(",") if v.strip()]

    def _fill_list(self, lst, names, checked):
        lst.blockSignals(True)
        lst.clear()
        for n in list(names) + [c for c in checked if c not in names]:
            it = QListWidgetItem(n)
            it.setFlags(it.flags() | Qt.ItemFlag.ItemIsUserCheckable)
            it.setCheckState(Qt.CheckState.Checked if n in checked else Qt.CheckState.Unchecked)
            lst.addItem(it)
        lst.blockSignals(False)

    def refresh_names(self):
        self._fill_list(self.s_list, self.names_fn("scenarios"), self._slot_values(0))
        self._fill_list(self.e_list, self.names_fn("events"), self._slot_values(9))
        self._update_runs_label()

    def _add_name(self):
        kind, ok = QInputDialog.getItem(self, "Add", "Add a:", ["Scenario (-s1)", "Event (-e1)"], 0, False)
        if not ok:
            return
        name, ok = QInputDialog.getText(self, "Add", "Name:")
        if not ok or not name.strip():
            return
        lst = self.s_list if kind.startswith("Scenario") else self.e_list
        it = QListWidgetItem(name.strip())
        it.setFlags(it.flags() | Qt.ItemFlag.ItemIsUserCheckable)
        it.setCheckState(Qt.CheckState.Checked)
        lst.addItem(it)

    def _lists_to_slots(self, *_):
        for lst, row in ((self.s_list, 0), (self.e_list, 9)):
            vals = [lst.item(i).text() for i in range(lst.count())
                    if lst.item(i).checkState() == Qt.CheckState.Checked]
            self.slots.item(row, 1).setText(", ".join(vals))
        self._update_runs_label()

    def _slot_edited(self, item):
        if item.row() in (0, 9) and item.column() == 1:
            lst = self.s_list if item.row() == 0 else self.e_list
            vals = self._slot_values(item.row())
            names = [lst.item(i).text() for i in range(lst.count())]
            self._fill_list(lst, names, vals)
        self._update_runs_label()
        self.update_preview()

    def _update_runs_label(self):
        n = len(self.config().combinations())
        self.runs_label.setText("<i>{} simulation{} will be run</i>".format(n, "" if n == 1 else "s"))

    def _exe_changed(self, path):
        low = (path or "").lower()
        self.precision.blockSignals(True)
        self.precision.setValue("Double precision (iDP)" if "_idp" in low else
                                ("Single precision (iSP)" if "_isp" in low else ""))
        self.precision.blockSignals(False)

    def _precision_changed(self, v):
        exe = self.exe.value()
        if v.startswith("Double"):
            new = re.sub(r"_iSP_", "_iDP_", exe, flags=re.I)
        else:
            new = re.sub(r"_iDP_", "_iSP_", exe, flags=re.I)
        if new != exe:
            self.exe.line.setText(new)

    def set_tcf(self, path):
        self.tcf_default = path
        if not self.tcf.value():
            self.tcf.setValue(path)
        self.update_preview()

    def set_config(self, d):
        self.cfg = BatchConfig.from_dict(d)
        self.exe.setValue(self.cfg.exe)
        if self.cfg.tcf:
            self.tcf.setValue(self.cfg.tcf)
        self.slots.blockSignals(True)
        for i in range(9):
            self.slots.item(i, 1).setText(", ".join(self.cfg.scenarios[i]))
            self.slots.item(i + 9, 1).setText(", ".join(self.cfg.events[i]))
        self.slots.blockSignals(False)
        self.test.setChecked(bool(self.cfg.test_mode))
        self.gpu.setValue(self.cfg.gpu_ids)
        self.extra.setText(self.cfg.extra_switches)
        self.mode.setValue(self.cfg.mode)
        self.platform.setValue(self.cfg.platform)
        self._exe_changed(self.cfg.exe)
        self.refresh_names()
        self.update_preview()

    def config(self):
        c = self.cfg
        c.exe = self.exe.value().strip()
        c.tcf = self.tcf.value().strip() or self.tcf_default

        def vals(r):
            it = self.slots.item(r, 1)
            return [v.strip() for v in (it.text() if it else "").split(",") if v.strip()]
        c.scenarios = [vals(i) for i in range(9)]
        c.events = [vals(i + 9) for i in range(9)]
        c.test_mode = self.test.isChecked()
        c.gpu_ids = self.gpu.value().strip()
        c.extra_switches = self.extra.text().strip()
        c.mode = self.mode.value() or "sequential"
        c.platform = self.platform.value() or "windows"
        return c

    def first_scenarios_events(self):
        c = self.config()
        return [v[0] for v in c.scenarios if v], [v[0] for v in c.events if v]

    def update_preview(self, *_):
        c = self.config()
        if not c.tcf:
            self.preview.setPlainText("Set the TCF to preview the batch file.")
            return
        self.preview.setPlainText(c.build(os.path.dirname(c.tcf)))

    def save_batch(self):
        c = self.config()
        ext = ".sh" if c.platform == "linux" else ".bat"
        start = os.path.join(os.path.dirname(c.tcf), "run_all" + ext) if c.tcf else ""
        f, _ = QFileDialog.getSaveFileName(self, "Save batch file", start, "*" + ext)
        if f:
            if not f.endswith(ext):
                f += ext
            c.write(f)
            qu.message("Batch file written: {}".format(f), "success")

    def run_now(self, test=False):
        c = self.config()
        if self.runner.running:
            QMessageBox.information(self, "Run", "Simulations are already running.")
            return
        if not c.exe or not os.path.isfile(c.exe):
            QMessageBox.warning(self, "Run", "Set a valid TUFLOW executable first.")
            return
        if not c.tcf or not os.path.isfile(c.tcf):
            QMessageBox.warning(self, "Run", "Save the model and set the TCF first.")
            return
        old = c.test_mode
        c.test_mode = test or old
        jobs = c.command_lines()
        c.test_mode = old
        if len(jobs) > 1 and QMessageBox.question(self, "Run", "Run {} simulations one after another?".format(len(jobs))) \
                != QMessageBox.StandardButton.Yes:
            return
        self.console.clear()
        self.runner.start(jobs, os.path.dirname(c.tcf))

    def run_test(self):
        self.run_now(test=True)

    def _console(self, text):
        self.console.append_text(text)

    def _finished(self):
        qu.message("TUFLOW run(s) finished - see the Logs and Results tabs.", "info")
        self.runsFinished.emit()


# ===========================================================================
class QcTab(QWidget):
    def __init__(self, context, parent=None):
        super().__init__(parent)
        self.ctx = context
        lay = QVBoxLayout(self)
        g = QGroupBox("Pre-run model checks")
        gl = QVBoxLayout(g)
        row = QHBoxLayout()
        row.addWidget(QLabel("Scenarios"))
        self.sc = TokenListEdit(lambda: [(n, "") for n in self.ctx.model_names("scenarios")], sep=", ",
                                button_text="v", placeholder="first Batch-tab values if empty")
        self.sc.setToolTip("Scenario values (~s1~, ~s2~ ...) used to resolve file names and If Scenario blocks")
        row.addWidget(self.sc, 1)
        row.addWidget(QLabel("Events"))
        self.ev = TokenListEdit(lambda: [(n, "") for n in self.ctx.model_names("events")], sep=", ",
                                button_text="v", placeholder="first Batch-tab values if empty")
        row.addWidget(self.ev, 1)
        row.addWidget(_btn("Run checks", self.run_checks))
        row.addWidget(_btn("Run TUFLOW test (-t)", self.ctx.run_test))
        gl.addLayout(row)
        self.summary = QLabel("")
        gl.addWidget(self.summary)
        self.table = QTableWidget(0, 4)
        self.table.setHorizontalHeaderLabels(["Severity", "File", "Finding", "How to fix"])
        self.table.horizontalHeader().setSectionResizeMode(2, QHeaderView.ResizeMode.Stretch)
        self.table.horizontalHeader().setSectionResizeMode(3, QHeaderView.ResizeMode.Stretch)
        self.table.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self.table.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self.table.setWordWrap(True)
        self.table.cellDoubleClicked.connect(self._open_row)
        gl.addWidget(self.table)
        gl.addWidget(QLabel("<i>Double-click a finding to open the related manual page.</i>"))
        lay.addWidget(g, 3)

        g2 = QGroupBox("TUFLOW check files (written by a run or a -t test)")
        g2l = QVBoxLayout(g2)
        row = QHBoxLayout()
        row.addWidget(QLabel("Simulation"))
        self.sim = QComboBox()
        self.sim.setMinimumWidth(260)
        self.sim.currentTextChanged.connect(self.list_check_files)
        row.addWidget(self.sim, 1)
        row.addWidget(_btn("Refresh", self.refresh_sims))
        row.addWidget(_btn("Load selected into QGIS", self.load_selected))
        row.addWidget(_btn("Load all", self.load_all))
        row.addWidget(_btn("Open check folder", lambda: qu.open_path(self.ctx.dirs()[1])))
        row.addWidget(_btn("Check files (wiki)", lambda: qu.open_url("https://wiki.tuflow.com/TUFLOW_Check_Files")))
        g2l.addLayout(row)
        self.files = QListWidget()
        self.files.setSelectionMode(QAbstractItemView.SelectionMode.ExtendedSelection)
        self.files.itemDoubleClicked.connect(lambda it: qu.add_layer(it.data(Qt.ItemDataRole.UserRole)))
        g2l.addWidget(self.files)
        lay.addWidget(g2, 2)
        self._findings = []

    def _list(self, text):
        return [v.strip() for v in text.replace("|", ",").split(",") if v.strip()]

    def run_checks(self):
        p = self.ctx.current_project()
        if p is None:
            QMessageBox.information(self, "QC", "Create or open a model first.")
            return
        sc, ev = self._list(self.sc.value()), self._list(self.ev.value())
        if not sc and not ev:
            sc, ev = self.ctx.batch_first()
        self._findings = ModelChecker(p, scenarios=sc, events=ev).run()
        self.table.setRowCount(len(self._findings))
        counts = {}
        for r, f in enumerate(self._findings):
            counts[f.severity] = counts.get(f.severity, 0) + 1
            self.table.setItem(r, 0, _sev_item(f.severity))
            self.table.setItem(r, 1, QTableWidgetItem(f.ftype))
            self.table.setItem(r, 2, QTableWidgetItem(f.message))
            self.table.setItem(r, 3, QTableWidgetItem(f.hint))
            if f.url:
                self.table.item(r, 2).setToolTip(f.url)
            _tint_row(self.table, r, f.severity)
        self.table.resizeRowsToContents()
        self.summary.setText("  ".join("<b style='color:{}'>{} {}</b>".format(SEVERITY_COLORS[k].name(), counts.get(k, 0), k)
                                       for k in ("ERROR", "WARNING", "INFO", "PASS")) +
                             "   (scenarios: {} | events: {})".format(", ".join(sc) or "-", ", ".join(ev) or "-"))
        return self._findings

    def _open_row(self, r, _c):
        if 0 <= r < len(self._findings) and self._findings[r].url:
            qu.open_url(self._findings[r].url)

    def refresh_sims(self):
        log = self.ctx.dirs()[2]
        cur = self.sim.currentText()
        self.sim.blockSignals(True)
        self.sim.clear()
        self.sim.addItems(L.list_simulations(log))
        if cur:
            self.sim.setCurrentText(cur)
        self.sim.blockSignals(False)
        self.list_check_files()

    def list_check_files(self, *_):
        self.files.clear()
        name = self.sim.currentText()
        if not name:
            return
        res, chk, log = self.ctx.dirs()
        rf = L.RunFiles(name, log, res, chk)
        for p in rf.check_layers():
            desc = L.describe_check_file(p)
            it = QListWidgetItem("{}{}".format(os.path.basename(p), "   -  " + desc if desc else ""))
            it.setData(Qt.ItemDataRole.UserRole, p)
            self.files.addItem(it)
        if not self.files.count():
            it = QListWidgetItem("No check files found in {}".format(chk))
            it.setFlags(Qt.ItemFlag.NoItemFlags)
            self.files.addItem(it)

    def load_selected(self):
        for it in self.files.selectedItems():
            qu.add_layer(it.data(Qt.ItemDataRole.UserRole))

    def load_all(self):
        for i in range(self.files.count()):
            p = self.files.item(i).data(Qt.ItemDataRole.UserRole)
            if p:
                qu.add_layer(p)


# ===========================================================================
class LogsTab(QWidget):
    def __init__(self, context, parent=None):
        super().__init__(parent)
        self.ctx = context
        lay = QVBoxLayout(self)
        row = QHBoxLayout()
        row.addWidget(QLabel("Simulation"))
        self.sim = QComboBox()
        self.sim.setMinimumWidth(300)
        self.sim.currentTextChanged.connect(self.load)
        row.addWidget(self.sim, 1)
        row.addWidget(_btn("Refresh", self.refresh))
        row.addWidget(_btn("Folders...", self.ctx.edit_dirs))
        row.addWidget(_btn("Open log folder", lambda: qu.open_path(self.ctx.dirs()[2])))
        lay.addLayout(row)
        self.counts = QLabel("")
        lay.addWidget(self.counts)
        self.tabs = QTabWidget()
        lay.addWidget(self.tabs, 1)
        # tlf
        self.tlf = LogView("Select a simulation to show its .tlf log.")
        self.tabs.addTab(self.tlf, ".tlf log")
        self.hpc = LogView("The .hpc.tlf log of HPC runs appears here.")
        self.tabs.addTab(self.hpc, ".hpc.tlf log")
        # messages
        mw = QWidget()
        ml = QVBoxLayout(mw)
        self.msg_table = QTableWidget(0, 5)
        self.msg_table.setHorizontalHeaderLabels(["Type", "No.", "Message", "X", "Y"])
        self.msg_table.horizontalHeader().setSectionResizeMode(2, QHeaderView.ResizeMode.Stretch)
        self.msg_table.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self.msg_table.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self.msg_table.cellDoubleClicked.connect(self._msg_click)
        ml.addWidget(self.msg_table)
        r2 = QHBoxLayout()
        r2.addWidget(QLabel("<i>Double-click: No. opens the wiki page, X/Y zooms the map.</i>"))
        r2.addStretch(1)
        r2.addWidget(_btn("Load messages layer", self._load_msg_layer))
        ml.addLayout(r2)
        self.tabs.addTab(mw, "Messages")
        self.register = QPlainTextEdit()
        self.register.setReadOnly(True)
        self.register.setFont(mono_font())
        self.register.setLineWrapMode(QPlainTextEdit.LineWrapMode.NoWrap)
        self.tabs.addTab(self.register, "Simulations register")
        self._messages = []
        self._msg_path = ""

    def refresh(self):
        log = self.ctx.dirs()[2]
        cur = self.sim.currentText()
        self.sim.blockSignals(True)
        self.sim.clear()
        self.sim.addItems(L.list_simulations(log))
        if cur:
            self.sim.setCurrentText(cur)
        self.sim.blockSignals(False)
        self.load()
        p = self.ctx.current_project()
        if p and p.files.get("TCF"):
            tdir = os.path.dirname(p.files["TCF"].path)
            reg = [os.path.join(tdir, f) for f in os.listdir(tdir) if f.lower().endswith("simulations.log")] \
                if os.path.isdir(tdir) else []
            self.register.setPlainText(L.read_text(reg[0], 2000000) if reg else "No '_ TUFLOW Simulations.log' next to the TCF yet.")

    def load(self, *_):
        name = self.sim.currentText()
        self.tlf.clear()
        self.hpc.clear()
        self.msg_table.setRowCount(0)
        self.counts.setText("")
        if not name:
            return
        res, chk, log = self.ctx.dirs()
        rf = L.RunFiles(name, log, res, chk)
        if rf.tlf:
            self.tlf.setPlainText(L.read_text(rf.tlf, 6000000))
            s = L.parse_tlf(rf.tlf)
            e, w, c = s.counts
            col = SEVERITY_COLORS["ERROR" if e or s.status == "UNSTABLE" else ("WARNING" if w else "PASS")].name()
            self.counts.setText("<b style='color:{}'>Status: {}</b>  |  {} errors, {} warnings, {} checks".format(
                col, s.status, e, w, c))
        if rf.hpc_tlf:
            self.hpc.setPlainText(L.read_text(rf.hpc_tlf, 6000000))
        self._msg_path = rf.messages or ""
        self._messages = L.read_messages(self._msg_path)
        self.msg_table.setRowCount(len(self._messages))
        for r, m in enumerate(self._messages):
            t = str(m.get("type", "")).upper()
            self.msg_table.setItem(r, 0, _sev_item(t if t in SEVERITY_COLORS else t.title()))
            num = m.get("number", "")
            self.msg_table.setItem(r, 1, QTableWidgetItem(str(int(num)) if isinstance(num, float) else str(num)))
            self.msg_table.setItem(r, 2, QTableWidgetItem(str(m.get("text", ""))))
            self.msg_table.setItem(r, 3, QTableWidgetItem(str(m.get("x", ""))))
            self.msg_table.setItem(r, 4, QTableWidgetItem(str(m.get("y", ""))))
            _tint_row(self.msg_table, r, t)

    def _find(self, text=None):
        return self.tlf.find_text(text or self.tlf.find_edit.text())

    def _msg_click(self, r, c):
        m = self._messages[r] if r < len(self._messages) else None
        if not m:
            return
        if c in (3, 4) and m.get("x") not in ("", None):
            qu.zoom_to(m.get("x"), m.get("y"))
        else:
            qu.open_url(L.message_url(m.get("number")))

    def _load_msg_layer(self):
        if self._msg_path:
            qu.add_layer(self._msg_path)


# ===========================================================================
class ResultsTab(QWidget):
    def __init__(self, context, parent=None):
        super().__init__(parent)
        self.ctx = context
        lay = QVBoxLayout(self)
        row = QHBoxLayout()
        row.addWidget(QLabel("Simulation"))
        self.sim = QComboBox()
        self.sim.setMinimumWidth(300)
        self.sim.currentTextChanged.connect(self.load)
        row.addWidget(self.sim, 1)
        row.addWidget(_btn("Refresh", self.refresh))
        row.addWidget(QLabel("Mass error warn / error (%)"))
        self.cme_w = SmartDoubleSpin()
        self.cme_w.setValue(1.0)
        self.cme_e = SmartDoubleSpin()
        self.cme_e.setValue(3.0)
        for s in (self.cme_w, self.cme_e):
            s.setRange(0.01, 100)
            s.valueChanged.connect(self.load)
            row.addWidget(s)
        row.addWidget(_btn("Open results folder", lambda: qu.open_path(self.ctx.dirs()[0])))
        lay.addLayout(row)
        split = QSplitter(Qt.Orientation.Vertical)
        top = QSplitter(Qt.Orientation.Horizontal)
        self.flags = QTableWidget(0, 2)
        self.flags.setHorizontalHeaderLabels(["Flag", "Stability / QC"])
        self.flags.horizontalHeader().setSectionResizeMode(1, QHeaderView.ResizeMode.Stretch)
        self.flags.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self.flags.cellDoubleClicked.connect(self._flag_click)
        top.addWidget(self.flags)
        cw = QWidget()
        cl = QVBoxLayout(cw)
        cl.setContentsMargins(0, 0, 0, 0)
        crow = QHBoxLayout()
        self.CHARTS = ["Mass error", "HPC timestep", "Control numbers", "PO time series"]
        self.chart_kind = RadioChoice(self.CHARTS)
        self.chart_kind.setValue(self.CHARTS[0])
        self.chart_kind.changed.connect(self.draw)
        self.po_col = QComboBox()
        self.po_col.setToolTip("Plot output column")
        self.po_col.currentIndexChanged.connect(self.draw)
        crow.addWidget(QLabel("Chart"))
        crow.addWidget(self.chart_kind)
        crow.addWidget(self.po_col, 1)
        cl.addLayout(crow)
        self.chart = LineChart()
        cl.addWidget(self.chart, 1)
        top.addWidget(cw)
        top.setSizes([420, 700])
        split.addWidget(top)
        fw = QWidget()
        fl = QVBoxLayout(fw)
        fl.setContentsMargins(0, 0, 0, 0)
        frow = QHBoxLayout()
        frow.addWidget(QLabel("<b>Result files</b>"))
        frow.addStretch(1)
        frow.addWidget(_btn("Load selected into QGIS", self.load_selected))
        frow.addWidget(_btn("TUFLOW Viewer (wiki)", lambda: qu.open_url("https://wiki.tuflow.com/TUFLOW_Viewer")))
        fl.addLayout(frow)
        self.files = QListWidget()
        self.files.setSelectionMode(QAbstractItemView.SelectionMode.ExtendedSelection)
        self.files.itemDoubleClicked.connect(lambda it: qu.add_layer(it.data(Qt.ItemDataRole.UserRole)))
        fl.addWidget(self.files)
        split.addWidget(fw)
        split.setSizes([420, 220])
        lay.addWidget(split, 1)
        self._mb = self._dt = None
        self._po = ([], [])
        self._flags = []

    def refresh(self):
        log = self.ctx.dirs()[2]
        cur = self.sim.currentText()
        self.sim.blockSignals(True)
        self.sim.clear()
        self.sim.addItems(L.list_simulations(log))
        if cur:
            self.sim.setCurrentText(cur)
        self.sim.blockSignals(False)
        self.load()

    def load(self, *_):
        name = self.sim.currentText()
        self.flags.setRowCount(0)
        self.files.clear()
        self._mb = self._dt = None
        self._po = ([], [])
        if not name:
            self.chart.set_data([], "No simulation selected")
            return
        res, chk, log = self.ctx.dirs()
        rf = L.RunFiles(name, log, res, chk)
        tlf = L.parse_tlf(rf.tlf) if rf.tlf else None
        hpc = L.parse_tlf(rf.hpc_tlf) if rf.hpc_tlf else None
        mbp = rf.mass_balance or rf.mass_balance_2d
        self._mb = L.MassBalance(mbp) if mbp else None
        self._dt = L.HpcTimestep(rf.hpc_dt) if rf.hpc_dt else None
        rep = L.StabilityReport(self.cme_w.value(), self.cme_e.value())
        self._flags = rep.evaluate(tlf, hpc, self._mb, self._dt)
        if not rf.tlf:
            self._flags.insert(0, ("INFO", "No .tlf found for this simulation in {}".format(log), ""))
        self.flags.setRowCount(len(self._flags))
        for r, (sev, text, url) in enumerate(self._flags):
            self.flags.setItem(r, 0, _sev_item(sev))
            it = QTableWidgetItem(text)
            it.setToolTip(url or text)
            self.flags.setItem(r, 1, it)
            _tint_row(self.flags, r, sev)
        self.flags.resizeRowsToContents()
        files = rf.result_grids() + rf.xmdf() + rf.po_csv() + ([mbp] if mbp else [])
        for p in files:
            it = QListWidgetItem(os.path.relpath(p, res) if res and p.startswith(res) else p)
            it.setData(Qt.ItemDataRole.UserRole, p)
            self.files.addItem(it)
        po = rf.po_csv()
        self.po_col.blockSignals(True)
        self.po_col.clear()
        if po:
            header, rows = L.read_csv_table(po[0])
            self._po = (header, rows)
            for i, h in enumerate(header[1:], 1):
                self.po_col.addItem(h, i)
        self.po_col.blockSignals(False)
        self.draw()

    def draw(self, *_):
        v = self.chart_kind.value()
        k = self.CHARTS.index(v) if v in self.CHARTS else 0
        self.po_col.setVisible(k == 3)
        if k == 0:
            mb = self._mb
            if mb and mb.ok:
                self.chart.set_data([("Cum ME (%)", mb.time[:len(mb.cum_me)], mb.cum_me)], "Cumulative mass error",
                                    "Time (h)", "%", [(self.cme_w.value(), "+warn", "#d68400"),
                                                      (-self.cme_w.value(), "-warn", "#d68400")])
            else:
                self.chart.set_data([], "No mass balance file (_MB.csv)")
        elif k == 1:
            d = self._dt
            if d and d.ok:
                self.chart.set_data([("dt", d.time[:len(d.dt)] or list(range(len(d.dt))), d.dt)], "HPC timestep",
                                    "Time (h)", "s")
            else:
                self.chart.set_data([], "No HPC timestep file (hpc.dt.csv)")
        elif k == 2:
            d = self._dt
            if d and d.ok:
                t = d.time or list(range(len(d.dt)))
                self.chart.set_data([(n, t[:len(v)], v) for n, v in (("Nu", d.nu), ("Nc", d.nc), ("Nd", d.nd)) if v],
                                    "HPC control numbers", "Time (h)", "", [(1.0, "Nu/Nc limit", "#c0392b"),
                                                                            (0.3, "Nd limit", "#8e44ad")])
            else:
                self.chart.set_data([], "No HPC control numbers")
        else:
            header, rows = self._po
            col = self.po_col.currentData()
            if header and col:
                xs, ys = [], []
                for r in rows:
                    if len(r) > col and isinstance(r[0], float) and isinstance(r[col], float):
                        xs.append(r[0])
                        ys.append(r[col])
                self.chart.set_data([(header[col], xs, ys)], header[col], header[0], "")
            else:
                self.chart.set_data([], "No PO time series")

    def _flag_click(self, r, _c):
        if 0 <= r < len(self._flags) and self._flags[r][2]:
            qu.open_url(self._flags[r][2])

    def load_selected(self):
        for it in self.files.selectedItems():
            p = it.data(Qt.ItemDataRole.UserRole)
            if p.lower().endswith(".csv"):
                qu.open_path(p)
            else:
                qu.add_layer(p)


# ===========================================================================
class HelpTab(QWidget):
    """Help: plugin guide, every control file explained, the Essentials command guide and
    explained links to the TUFLOW manual and wiki. Each entry shows a brief explanation under its
    title; select it for details, double-click to open the page."""
    ROLE_URL = Qt.ItemDataRole.UserRole
    ROLE_HTML = Qt.ItemDataRole.UserRole + 1
    ROLE_BRIEF = Qt.ItemDataRole.UserRole + 6

    def __init__(self, parent=None):
        super().__init__(parent)
        lay = QHBoxLayout(self)
        split = QSplitter(Qt.Orientation.Horizontal)
        lay.addWidget(split)
        left = QWidget()
        ll = QVBoxLayout(left)
        ll.setContentsMargins(0, 0, 0, 0)
        row = QHBoxLayout()
        self.search = QLineEdit()
        self.search.setPlaceholderText("Search help, commands and explanations...")
        self.search.textChanged.connect(self._filter)
        row.addWidget(self.search, 1)
        for text, on in (("Expand all", True), ("Collapse all", False)):
            b = QToolButton()
            b.setText(text)
            b.clicked.connect(lambda _=False, v=on: self._expand(v))
            row.addWidget(b)
        self.explain_cb = QCheckBox("Explain")
        self.explain_cb.setChecked(True)
        self.explain_cb.setToolTip("Show a brief explanation under each entry")
        row.addWidget(self.explain_cb)
        ll.addLayout(row)
        self.tree = QTreeWidget()
        self.tree.setHeaderHidden(True)
        self.tree.setUniformRowHeights(False)
        self.delegate = ExplainDelegate(self.tree, self.ROLE_BRIEF)
        self.tree.setItemDelegate(self.delegate)
        self.explain_cb.toggled.connect(self._toggle_explain)
        self.tree.itemDoubleClicked.connect(self._open)
        self.tree.itemSelectionChanged.connect(self._show)
        ll.addWidget(self.tree)
        split.addWidget(left)
        right = QWidget()
        rl = QVBoxLayout(right)
        rl.setContentsMargins(0, 0, 0, 0)
        self.info = QTextBrowser()
        self.info.setOpenExternalLinks(True)
        rl.addWidget(self.info, 1)
        brow = QHBoxLayout()
        self.open_btn = _btn("Open page", lambda: self._open(self.tree.currentItem()),
                             "Open the selected page in your browser")
        brow.addWidget(self.open_btn)
        brow.addWidget(_btn("Plugin guide", lambda: self.info.setHtml(ABOUT_HTML),
                            "How FMB tools works"))
        brow.addStretch(1)
        rl.addLayout(brow)
        split.addWidget(right)
        split.setSizes([620, 480])
        self._build()
        self.info.setHtml(ABOUT_HTML)

    # -- tree -------------------------------------------------------------
    def _item(self, parent, title, brief="", url="", html="", bold=False):
        it = QTreeWidgetItem([title])
        it.setData(0, self.ROLE_BRIEF, brief)
        it.setData(0, self.ROLE_URL, url)
        it.setData(0, self.ROLE_HTML, html)
        if brief or url:
            tip = brief + ("\n" + url if url else "")
            it.setToolTip(0, "<qt>{}</qt>".format(_html_esc(tip).replace("\n", "<br>")))
        if bold:
            it.setFont(0, bold_font())
        if parent is None:
            self.tree.addTopLevelItem(it)
        else:
            parent.addChild(it)
        return it

    def _build(self):
        from ..core.catalog import catalog
        from ..core.essentials import ESSENTIALS
        from ..core.explanations import FILE_OVERVIEW, GROUP_EXPLAIN, explain
        from ..core.help_links import GROUP_NOTES
        self.tree.clear()
        self._item(None, "How FMB tools works", "Tabs, workflow and TUFLOW syntax reminders for this plugin.",
                   html=ABOUT_HTML, bold=True)
        # every control file in one sentence or two, with its reference pages
        top = self._item(None, "Control files explained",
                         "What each TUFLOW control file does, with its command reference and tutorials.", bold=True)
        for ft in CONTROL_FILE_TYPES:
            name, desc = FILE_TYPE_INFO[ft][0], FILE_TYPE_INFO[ft][1]
            f = self._item(top, "{} - {}".format(name, desc), FILE_OVERVIEW.get(ft, ""),
                           url=CONTROL_FILE_HELP.get(ft, [("", "", "")])[0][1])
            for label, url, note in CONTROL_FILE_HELP.get(ft, []):
                self._item(f, label, note, url)
        # the Essentials command guide
        top = self._item(None, "Essentials guide - what each command does",
                         "The guided commands of every control file tab, each with a brief explanation. "
                         "* = required, + = recommended.", bold=True)
        for ft in CONTROL_FILE_TYPES:
            groups = ESSENTIALS.get(ft)
            if not groups:
                continue
            n = sum(len(c) for _g, c in groups)
            f = self._item(top, "{}  ({} commands)".format(FILE_TYPE_INFO[ft][0], n), FILE_OVERVIEW.get(ft, ""))
            for group, cmds in groups:
                g = self._item(f, group, GROUP_EXPLAIN.get((ft, group), ""))
                for key, level, value, tip in cmds:
                    spec, _c = catalog().match(ft, key)
                    brief = explain(ft, key, tip)
                    mark = {"req": "  *", "rec": "  +"}.get(level, "")
                    it = self._item(g, key + mark, brief, spec.url if spec else "",
                                    html=self._command_html(ft, key, level, value, tip, brief, spec))
                    it.setForeground(0, QBrush(LEVEL_COLORS[level]))
        # links to the manual and wiki
        for group, links in HELP_TREE:
            g = self._item(None, group, GROUP_NOTES.get(group, ""), bold=True)
            for label, url, note in links:
                self._item(g, label, note, url)
        for i in range(self.tree.topLevelItemCount()):
            self.tree.topLevelItem(i).setExpanded(i in (1, 2))

    @staticmethod
    def _command_html(ft, key, level, value, tip, brief, spec):
        e = _html_esc
        lvl = {"req": "Required", "rec": "Recommended", "opt": "Optional"}[level]
        h = ["<h3>{}</h3>".format(e(spec.name if spec else key)),
             "<p style='color:gray'>{} - {} for a typical model</p>".format(e(ft), lvl),
             "<p style='background:#eef4fb; padding:4px'>{}</p>".format(e(brief))]
        if spec:
            h.append("<p>Syntax:<br><code>{}</code></p>".format(e(spec.syntax)))
            if spec.default:
                h.append("<p>Default: <b>{}</b></p>".format(e(spec.default)))
        if tip and tip not in brief:
            h.append("<p><b>Tip:</b> {}</p>".format(e(tip)))
        if value:
            h.append("<p>Suggested value: <code>{}</code></p>".format(e(value)))
        h.append("<p><i>Add it from the {} tab: Essentials (guided), double-click the command.</i></p>".format(e(ft)))
        if spec:
            h.append("<p><a href='{}'>Open this command in the TUFLOW manual</a></p>".format(spec.url))
        return "".join(h)

    def _show(self):
        it = self.tree.currentItem()
        if it is None:
            return
        url = it.data(0, self.ROLE_URL) or ""
        self.open_btn.setEnabled(bool(url))
        html = it.data(0, self.ROLE_HTML)
        if html:
            self.info.setHtml(html)
            return
        e = _html_esc
        h = ["<h3>{}</h3>".format(e(it.text(0)))]
        brief = it.data(0, self.ROLE_BRIEF)
        if brief:
            h.append("<p style='background:#eef4fb; padding:4px'>{}</p>".format(e(brief)))
        if it.childCount():
            h.append("<ul>")
            for i in range(it.childCount()):
                c = it.child(i)
                h.append("<li><b>{}</b>{}</li>".format(e(c.text(0)), (" - " + e(c.data(0, self.ROLE_BRIEF)))
                                                        if c.data(0, self.ROLE_BRIEF) else ""))
            h.append("</ul>")
        if url:
            h.append("<p><a href='{0}'>{0}</a></p>".format(url))
        self.info.setHtml("".join(h))

    def _open(self, it, _col=0):
        if it is not None and it.data(0, self.ROLE_URL):
            qu.open_url(it.data(0, self.ROLE_URL))

    def _toggle_explain(self, on):
        self.delegate.enabled = bool(on)
        self.tree.doItemsLayout()
        self.tree.viewport().update()

    def _expand(self, on):
        def walk(item):
            if item.childCount():
                item.setExpanded(on)
                for i in range(item.childCount()):
                    walk(item.child(i))
        for i in range(self.tree.topLevelItemCount()):
            walk(self.tree.topLevelItem(i))

    def _filter(self, text):
        t = text.lower().strip()

        def walk(item):
            fields = (item.text(0),) if item.childCount() else \
                (item.text(0), item.data(0, self.ROLE_BRIEF), item.data(0, self.ROLE_URL))
            own = not t or any(t in (x or "").lower() for x in fields)
            child_vis = False
            for i in range(item.childCount()):
                c = item.child(i)
                if own and t:
                    self._show_all(c)
                    child_vis = True
                elif walk(c):
                    child_vis = True
            vis = own or child_vis
            item.setHidden(not vis)
            if t and child_vis:
                item.setExpanded(True)
            return vis

        for i in range(self.tree.topLevelItemCount()):
            walk(self.tree.topLevelItem(i))

    def _show_all(self, item):
        item.setHidden(False)
        for i in range(item.childCount()):
            self._show_all(item.child(i))


def _html_esc(t):
    return (t or "").replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")


ABOUT_HTML = """
<h3>How this plugin works</h3>
<ol>
<li><b>Project</b> - create a new model (folders, TCF/TGC/TBC, databases) or open an existing .tcf.
<i>Create TUFLOW folder structure</i> makes just the standard folders (bc_dbase, check, model/gis, model/grid,
results, runs/log ...) at any location, with optional extra folders and readme notes.</li>
<li><b>Empty layers</b> - tick the TUFLOW layers you need (2d_code, 2d_mat, 2d_bc, 2d_po, 1d_nwk ...) and the
geometries (points / lines / regions). Each layer shows what to draw and lets you set default attribute values.
The layers are written as one GeoPackage, one GeoPackage per layer or Shapefiles with the attribute order TUFLOW
expects, opened in QGIS with those defaults and dropdowns, and their <code>Read GIS</code> commands are added to
the control files. For other layer types, point the tab at TUFLOW's own empty files (or click <i>Write with
TUFLOW</i>) and FMB tools copies their exact structure.</li>
<li><b>Control file tabs</b> - pick commands from the <i>Essentials</i> list (<span style='color:#c82828'>*</span> required,
<span style='color:#d68400'>+</span> recommended) or from <i>All commands</i>, which lists every command of the manual.
Each Essentials command shows a brief explanation of what it does underneath (untick <i>Explain</i> for a compact
list); select a command for its syntax, default, tips and a link to the manual.
Every value gets a matching input: <b>radio buttons</b> for short option sets (ON/OFF, CPU/GPU, METHOD A/B),
<b>dropdowns</b> for longer lists, <b>number boxes with units</b> (h, s, m, %, &deg;) and <b>X / Y pairs</b> for coordinates and
sizes, keyword + value choices such as <i>( ) AUTO ( ) 0.5 s</i>, file and QGIS-layer pickers for inputs, and dropdowns filled
from your model (scenario and event names, BC database names, material IDs). The <b>abc</b> button next to a number box
switches it to text for <code>&lt;&lt;variables&gt;&gt;</code> or <code>~s1~</code> tokens. Number boxes and dropdowns ignore the
mouse wheel until clicked, so scrolling never changes a value.
The preview on the right is the exact file that will be written. Tick <i>Edit text directly</i> for free editing.</li>
<li><b>Databases</b> - edit bc_dbase.csv, materials.csv and time-series CSVs, check source files, plot them.</li>
<li><b>Batch &amp; Run</b> - build .bat/.sh files for every scenario/event combination, or run from QGIS.</li>
<li><b>QC &amp; Checks</b> - pre-run checks (missing files, required commands, If/Define blocks, timestep vs cell size,
wet/dry depth for rainfall, materials, BC database ...) and TUFLOW's own check layers.</li>
<li><b>Outputs</b> - tick result grids, meshes, plot output and check files and load them with TUFLOW-style
colours (depth / velocity / hazard classes, stretched water levels).</li>
<li><b>Help</b> - every control file explained, the <i>Essentials guide</i> (each guided command with a brief
explanation) and explained links to the TUFLOW manual, wiki, tutorials and message pages. Type in the search box
to find a command or topic; double-click an entry to open its page.</li>
<li><b>Pasting</b> - every number box accepts Ctrl+V / right-click Paste of values such as <code>312,345.6 m</code>
or <code>5,25</code>; pasting <code>X, Y</code> (or <code>X Y</code>, a tab-separated pair from Excel, a QGIS
coordinate) into the first box of a pair fills both. Database tables take Ctrl+C / Ctrl+V blocks of cells.</li>
<li><b>Logs / Stability</b> - .tlf, .hpc.tlf and the run console are colour coded: <span style='color:#b71c1c;background:#fdecea'>errors red</span>,
<span style='color:#8a5300;background:#fff1d6'>warnings amber</span>, <span style='color:#1a5a96;background:#e8f1fb'>checks blue</span>,
<span style='color:#1b7a3a;background:#e3f4e8'>finished green</span>. Click a count to jump to the next one, or show only
the problem lines. Messages (linked to the wiki), mass error, HPC timestep and control numbers with stability flags.</li>
</ol>
<h3>TUFLOW syntax reminders</h3>
<ul>
<li><code>Command == value</code>; comments start with <code>!</code> or <code>#</code>.</li>
<li>Paths are relative to the folder of the control file that contains them.</li>
<li>GeoPackage layers: <code>..\\model\\gis\\model.gpkg &gt;&gt; 2d_code_M01_R</code>; with a Spatial Database just the layer name.</li>
<li>Several layers on one command: separate with <code>|</code>.</li>
<li>Scenario/event tokens <code>~s1~</code>, <code>~e1~</code> are replaced by the <code>-s1</code>/<code>-e1</code> switches.</li>
<li>Commands are read top to bottom - in the TGC later commands overwrite earlier ones.</li>
</ul>
<h3>Disclaimer</h3>
<p>FMB tools is an independent, open-source (GPL-2.0-or-later) plugin. It is <b>not</b> developed,
endorsed or supported by BMT or the TUFLOW team. TUFLOW is a trademark of BMT. You need your own TUFLOW licence
(or the free demo mode) to run simulations. Command help links point to the official
<a href="https://docs.tuflow.com/classic-hpc/manual/latest/">TUFLOW manual</a> and
<a href="https://wiki.tuflow.com/Main_Page">TUFLOW Wiki</a>. Always check results against the manual.</p>
"""
