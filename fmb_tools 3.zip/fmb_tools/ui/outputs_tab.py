# -*- coding: utf-8 -*-
"""
'Outputs' tab: every result of a simulation in one tick list, loaded into QGIS
with TUFLOW-style symbology (grids, meshes, plot output, 1D results, check
files and messages).
"""
import os

from qgis.PyQt.QtCore import Qt
from qgis.PyQt.QtWidgets import (QWidget, QVBoxLayout, QHBoxLayout, QLabel, QComboBox, QPushButton, QSplitter,
                                 QTreeWidget, QTreeWidgetItem, QHeaderView, QTextBrowser, QCheckBox, QLineEdit,
                                 QSpinBox, QMessageBox)

from ..core import results as R
from . import qgis_utils as qu
from . import styles as ST
from .widgets import RadioChoice, NumberSpin, bold_font, SmartIntSpin

ROLE_ITEM = Qt.ItemDataRole.UserRole
STYLE_OPTS = ["TUFLOW style", "QGIS default"]


def _size(n):
    for unit in ("B", "KB", "MB", "GB"):
        if n < 1024 or unit == "GB":
            return "{:.0f} {}".format(n, unit) if unit == "B" else "{:.1f} {}".format(n, unit)
        n /= 1024.0


class OutputsTab(QWidget):
    def __init__(self, context, parent=None):
        super().__init__(parent)
        self.ctx = context
        self.items = []
        self._building = False
        lay = QVBoxLayout(self)
        row = QHBoxLayout()
        row.addWidget(QLabel("Simulation"))
        self.sim = QComboBox()
        self.sim.setMinimumWidth(320)
        self.sim.currentTextChanged.connect(self.scan)
        row.addWidget(self.sim, 1)
        for text, slot, tip in (("Refresh", self.refresh, "Look for new simulations and files"),
                                ("Folders...", lambda: self.ctx.edit_dirs(), "Results / check / log folders"),
                                ("Open results folder", lambda: qu.open_path(self.ctx.dirs()[0]), "")):
            b = QPushButton(text)
            b.setToolTip(tip)
            b.clicked.connect(slot)
            row.addWidget(b)
        lay.addLayout(row)

        split = QSplitter(Qt.Orientation.Horizontal)
        lay.addWidget(split, 1)
        left = QWidget()
        ll = QVBoxLayout(left)
        ll.setContentsMargins(0, 0, 0, 0)
        qrow = QHBoxLayout()
        for text, slot in (("Tick maximum grids", self.tick_max), ("Tick all", lambda: self.tick_all(True)),
                           ("Tick none", lambda: self.tick_all(False))):
            b = QPushButton(text)
            b.clicked.connect(slot)
            qrow.addWidget(b)
        self.filter = QLineEdit()
        self.filter.setPlaceholderText("Filter...")
        self.filter.textChanged.connect(self._filter)
        qrow.addWidget(self.filter, 1)
        ll.addLayout(qrow)
        self.tree = QTreeWidget()
        self.tree.setHeaderLabels(["Output", "Data", "File", "Size"])
        self.tree.header().setSectionResizeMode(0, QHeaderView.ResizeMode.Interactive)
        self.tree.setColumnWidth(0, 330)
        self.tree.setColumnWidth(1, 80)
        self.tree.setColumnWidth(2, 330)
        self.tree.itemChanged.connect(self._changed)
        self.tree.currentItemChanged.connect(lambda cur, _p: self._preview(cur))
        self.tree.itemDoubleClicked.connect(lambda it, _c: self._load_one(it))
        ll.addWidget(self.tree, 1)
        self.count = QLabel("")
        ll.addWidget(self.count)
        split.addWidget(left)
        self.legend = QTextBrowser()
        self.legend.setOpenExternalLinks(True)
        split.addWidget(self.legend)
        split.setSizes([860, 360])

        opts = QHBoxLayout()
        opts.addWidget(QLabel("Symbology"))
        self.style = RadioChoice(STYLE_OPTS)
        self.style.setValue(STYLE_OPTS[0])
        self.style.setToolTip("TUFLOW style: flood-mapping classes for depth / velocity / hazard, stretched colours "
                              "for levels, and the official TUFLOW plugin styles for check files and plot output "
                              "(when that plugin is installed).")
        opts.addWidget(self.style)
        opts.addWidget(QLabel("Hide depth below"))
        self.cutoff = NumberSpin("m", False, 0.0, 10.0, 0.01)
        self.cutoff.setValue(0.01)
        self.cutoff.setToolTip("Depth classes start at this value - shallower cells are transparent")
        opts.addWidget(self.cutoff)
        opts.addWidget(QLabel("Opacity"))
        self.opacity = SmartIntSpin()
        self.opacity.setRange(10, 100)
        self.opacity.setValue(85)
        self.opacity.setSuffix(" %")
        opts.addWidget(self.opacity)
        self.per_sim = QCheckBox("Group per simulation")
        self.per_sim.setChecked(True)
        self.replace = QCheckBox("Replace layers already loaded")
        self.replace.setChecked(True)
        opts.addWidget(self.per_sim)
        opts.addWidget(self.replace)
        opts.addStretch(1)
        self.load_btn = QPushButton("Load ticked")
        self.load_btn.setStyleSheet("font-weight: bold; padding: 6px 16px;")
        self.load_btn.clicked.connect(self.load_ticked)
        opts.addWidget(self.load_btn)
        lay.addLayout(opts)
        self._show_help()

    # ---------------------------------------------------------------- data
    def refresh(self):
        res, _chk, log = self.ctx.dirs()
        cur = self.sim.currentText()
        self.sim.blockSignals(True)
        self.sim.clear()
        self.sim.addItems(R.list_result_simulations(res, log))
        if cur:
            self.sim.setCurrentText(cur)
        self.sim.blockSignals(False)
        self.scan()

    def scan(self, *_):
        name = self.sim.currentText().strip()
        res, chk, log = self.ctx.dirs()
        self.items = R.scan_outputs(name, res, chk, log) if name else []
        self._fill()

    def _fill(self):
        self._building = True
        self.tree.clear()
        groups = {}
        for it in self.items:
            g = groups.get(it.category)
            if g is None:
                g = QTreeWidgetItem([it.category])
                g.setFont(0, bold_font())
                g.setFlags(Qt.ItemFlag.ItemIsEnabled | Qt.ItemFlag.ItemIsUserCheckable | Qt.ItemFlag.ItemIsAutoTristate)
                g.setCheckState(0, Qt.CheckState.Unchecked)
                self.tree.addTopLevelItem(g)
                groups[it.category] = g
            parent = g
            if it.category == R.CAT_TIME:          # one sub-group per data type
                key = ("time", it.dtype)
                sub = groups.get(key)
                if sub is None:
                    sub = QTreeWidgetItem([R.describe_dtype(it.dtype)])
                    sub.setFlags(Qt.ItemFlag.ItemIsEnabled | Qt.ItemFlag.ItemIsUserCheckable |
                                 Qt.ItemFlag.ItemIsAutoTristate)
                    sub.setCheckState(0, Qt.CheckState.Unchecked)
                    g.addChild(sub)
                    groups[key] = sub
                parent = sub
            node = QTreeWidgetItem([it.label, it.dtype if it.kind in ("raster", "mesh") else it.kind,
                                    os.path.basename(it.path) + (" >> " + it.layer if it.layer else ""),
                                    _size(it.size)])
            node.setData(0, ROLE_ITEM, it)
            node.setFlags(Qt.ItemFlag.ItemIsEnabled | Qt.ItemFlag.ItemIsSelectable | Qt.ItemFlag.ItemIsUserCheckable)
            node.setCheckState(0, Qt.CheckState.Unchecked)
            node.setToolTip(2, it.path)
            parent.addChild(node)
        for i in range(self.tree.topLevelItemCount()):
            g = self.tree.topLevelItem(i)
            g.setExpanded(g.text(0) != R.CAT_TIME)
        self._building = False
        self._update_count()
        if not self.items:
            self._show_help()

    def _nodes(self):
        stack = [self.tree.topLevelItem(i) for i in range(self.tree.topLevelItemCount())]
        while stack:
            n = stack.pop()
            for j in range(n.childCount()):
                stack.append(n.child(j))
            if n.data(0, ROLE_ITEM) is not None:
                yield n

    def ticked(self):
        return [n.data(0, ROLE_ITEM) for n in self._nodes() if n.checkState(0) == Qt.CheckState.Checked]

    def _changed(self, _item, col):
        if not self._building and col == 0:
            self._update_count()

    def _update_count(self):
        n = len(self.ticked())
        self.load_btn.setText("Load {} ticked".format(n))
        self.load_btn.setEnabled(n > 0)
        self.count.setText("{} output files found".format(len(self.items)) if self.items else
                           "No outputs found for this simulation - check the folders (Folders...).")

    def tick_all(self, on):
        for i in range(self.tree.topLevelItemCount()):
            self.tree.topLevelItem(i).setCheckState(0, Qt.CheckState.Checked if on else Qt.CheckState.Unchecked)
        self._update_count()

    def tick_max(self):
        for n in self._nodes():
            it = n.data(0, ROLE_ITEM)
            if it.category == R.CAT_MAX:
                n.setCheckState(0, Qt.CheckState.Checked)
        self._update_count()

    def _filter(self, text):
        t = text.lower().strip()
        for n in self._nodes():
            it = n.data(0, ROLE_ITEM)
            n.setHidden(bool(t) and t not in it.label.lower() and t not in os.path.basename(it.path).lower())

    # -------------------------------------------------------------- legend
    def _show_help(self):
        sd = ST.tuflow_style_dir()
        self.legend.setHtml(
            "<h3>Outputs</h3><p>Pick a simulation, tick the outputs and press <b>Load ticked</b> "
            "(or double-click one). Layers go into <i>Results / &lt;simulation&gt;</i> in the layer panel.</p>"
            "<p><b>Symbology</b><br>Depth, velocity, Z0 and hazard grids use fixed flood-mapping classes; water "
            "level and other grids are stretched between their minimum and maximum. Mesh results (XMDF / NetCDF) "
            "get the same colours per dataset. Check files and plot-output layers use the official TUFLOW plugin "
            "styles: <b>{}</b>.</p><p>CSV files open in your default application.</p>"
            "<p><a href='https://wiki.tuflow.com/TUFLOW_Viewer'>TUFLOW Viewer</a> gives animated / time-series "
            "viewing of the same results.</p>".format(
                "found" if sd else "TUFLOW plugin not installed - simple colours are used instead"))

    def _preview(self, node):
        it = node.data(0, ROLE_ITEM) if node is not None else None
        if it is None:
            return
        h = ["<h3>{}</h3><p><code>{}</code></p>".format(it.label, it.path)]
        if it.layer:
            h.append("<p>Layer: <code>{}</code></p>".format(it.layer))
        if it.kind == "raster":
            h.append(ST.legend_html(it.dtype))
        elif it.kind == "mesh":
            mesh = R.mesh_for(it)
            h.append("<p>Mesh: {}</p>".format(mesh or ("inside the NetCDF file" if it.path.lower().endswith(".nc")
                                                        else "<b>no .2dm found next to the result</b>")))
            h.append(ST.legend_html("d"))
        elif it.kind == "vector":
            qml = ST.tuflow_qml_for(it.name)
            h.append("<p>Style: {}</p>".format(os.path.basename(qml) + " (TUFLOW plugin)" if qml else "FMB simple style"))
        else:
            h.append("<p>Opens in your default application.</p>")
        self.legend.setHtml("".join(h))

    # ---------------------------------------------------------------- load
    def _load_one(self, node):
        it = node.data(0, ROLE_ITEM) if node is not None else None
        if it is not None:
            self.load([it])

    def load_ticked(self):
        items = self.ticked()
        if not items:
            return
        if len(items) > 40 and QMessageBox.question(
                self, "Outputs", "Load {} layers?".format(len(items))) != QMessageBox.StandardButton.Yes:
            return
        self.load(items)

    def load(self, items):
        sim = self.sim.currentText().strip()
        base = "Results/{}".format(sim) if self.per_sim.isChecked() else "Results"
        tuflow = self.style.value() == STYLE_OPTS[0]
        cutoff = self.cutoff.value() if self.cutoff.is_set() else None
        op = self.opacity.value() / 100.0
        ok, failed = 0, []
        # load in reverse so the first ticked item ends on top
        for it in reversed(items):
            try:
                lyr = self._make_layer(it, tuflow, cutoff, op)
            except Exception as ex:          # pragma: no cover - needs QGIS
                lyr = None
                failed.append("{} ({})".format(it.name, ex))
                continue
            if lyr is None:
                if it.kind == "csv":
                    qu.open_path(it.path)
                    ok += 1
                else:
                    failed.append(it.name)
                continue
            qu.add_to_group(lyr, "{}/{}".format(base, it.category), replace=self.replace.isChecked())
            ok += 1
        msg = "Loaded {} output(s)".format(ok) + (" - could not load: {}".format(", ".join(failed)) if failed else "")
        qu.message(msg, "warning" if failed else "success")
        self.count.setText(msg)
        return ok, failed

    def _make_layer(self, it, tuflow, cutoff, opacity):
        if not qu.HAS_QGIS or it.kind == "csv":
            return None
        from qgis.core import QgsRasterLayer, QgsVectorLayer, QgsMeshLayer
        if it.kind == "raster":
            lyr = QgsRasterLayer(it.uri, it.name)
            if not lyr.isValid():
                return None
            if tuflow:
                ST.style_raster(lyr, it.dtype, cutoff, opacity)
            return lyr
        if it.kind == "mesh":
            if it.path.lower().endswith(".nc"):
                lyr = QgsMeshLayer(it.path, it.name, "mdal")
            else:
                mesh = R.mesh_for(it)
                if not mesh:
                    raise IOError("no .2dm mesh next to {}".format(os.path.basename(it.path)))
                lyr = QgsMeshLayer(mesh, it.name, "mdal")
                if lyr.isValid():
                    lyr.dataProvider().addDataset(it.path)
            if not lyr.isValid():
                return None
            if tuflow:
                ST.style_mesh(lyr, cutoff, opacity)
            return lyr
        lyr = QgsVectorLayer(it.uri, it.name, "ogr")
        if not lyr.isValid():
            return None
        if tuflow:
            ST.style_vector(lyr, it.dtype, True, 1.0)
        return lyr

    def clear(self):
        self.sim.clear()
        self.items = []
        self._fill()
