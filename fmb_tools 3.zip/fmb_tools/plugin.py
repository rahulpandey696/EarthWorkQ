# -*- coding: utf-8 -*-
"""QGIS plugin wrapper: menu entry, toolbar button and the main window."""
import os

from qgis.PyQt.QtGui import QIcon
try:
    from qgis.PyQt.QtWidgets import QAction
except ImportError:          # Qt6 / QGIS 4
    from qgis.PyQt.QtGui import QAction

MENU = "&FMB tools"


class FmbToolsPlugin(object):
    def __init__(self, iface):
        self.iface = iface
        self.dialog = None
        self.actions = []
        self.plugin_dir = os.path.dirname(__file__)

    def initGui(self):  # noqa: N802
        icon = QIcon(os.path.join(self.plugin_dir, "icon.png"))
        a = QAction(icon, "FMB tools", self.iface.mainWindow())
        a.setToolTip("Build, check and run TUFLOW models")
        a.triggered.connect(self.show)
        self.iface.addToolBarIcon(a)
        self.iface.addPluginToMenu(MENU, a)
        self.actions.append(a)
        h = QAction("Help (TUFLOW Wiki)", self.iface.mainWindow())
        h.triggered.connect(self._wiki)
        self.iface.addPluginToMenu(MENU, h)
        self.actions.append(h)

    def unload(self):
        for a in self.actions:
            self.iface.removePluginMenu(MENU, a)
            self.iface.removeToolBarIcon(a)
        self.actions = []
        if self.dialog is not None:
            self.dialog.close()
            self.dialog.deleteLater()
            self.dialog = None

    def show(self):
        if self.dialog is None:
            from .ui.main_dialog import MainDialog
            self.dialog = MainDialog(self.iface, self.iface.mainWindow())
        self.dialog.show()
        self.dialog.raise_()
        self.dialog.activateWindow()

    def _wiki(self):
        from .ui.qgis_utils import open_url
        open_url("https://wiki.tuflow.com/Main_Page")
