# -*- coding: utf-8 -*-
"""
Find every output file of a TUFLOW simulation and classify it for loading:
maximum / time-step grids, mesh results (XMDF / NetCDF / DAT), plot-output and
1D result GIS layers, time-series CSVs, check files and the messages layer.
"""
import glob
import os
import re

from .logs import describe_check_file

# map output data types (TUFLOW manual, Outputs chapter)
DATA_TYPES = {
    "h": ("Water level", "m"), "d": ("Depth", "m"), "V": ("Velocity", "m/s"), "q": ("Unit flow", "m2/s"),
    "Z0": ("Velocity x depth (Z0)", "m2/s"), "ZUK0": ("UK hazard rating", ""),
    "ZAEM1": ("Hazard category H1-H6 (AEM 2017)", ""), "BSS": ("Bed shear stress", "N/m2"),
    "SP": ("Stream power", "W/m2"), "n": ("Manning's n", ""), "MB1": ("Mass error", ""), "MB2": ("Mass error", ""),
    "CI": ("Cumulative infiltration", "mm"), "dt": ("Minimum timestep", "s"), "E": ("Energy level", "m"),
    "R": ("Flow regime", ""), "Fr": ("Froude number", ""), "t": ("Viscosity", ""), "ZH": ("Hazard", ""),
    "Vx": ("Velocity X", "m/s"), "Vy": ("Velocity Y", "m/s"), "SS": ("Sink / source", ""),
}
SUMMARY_TAGS = ("Max", "Min", "max", "min")
GRID_EXT = (".tif", ".tiff", ".asc", ".flt", ".nc", ".gpkg")
VECTOR_EXT = (".shp", ".gpkg", ".mif")

CAT_MAX = "Maximum / summary grids"
CAT_TIME = "Time-step grids"
CAT_MESH = "Mesh results (XMDF / NetCDF / DAT)"
CAT_PLOT = "Plot output & 1D results (GIS)"
CAT_CSV = "Time series & mass balance (CSV)"
CAT_CHECK = "Check files"
CAT_MSG = "Messages"
CATEGORIES = [CAT_MAX, CAT_TIME, CAT_MESH, CAT_PLOT, CAT_CSV, CAT_CHECK, CAT_MSG]


class OutputItem(object):
    __slots__ = ("category", "dtype", "tag", "label", "path", "kind", "layer", "size")

    def __init__(self, category, dtype, tag, label, path, kind, layer=""):
        self.category = category
        self.dtype = dtype        # h, d, V ... (grids / mesh) or a result key
        self.tag = tag            # Max, TMax, 001.00 ...
        self.label = label
        self.path = path
        self.kind = kind          # raster | mesh | vector | csv
        self.layer = layer        # layer name inside a GeoPackage
        try:
            self.size = os.path.getsize(path)
        except OSError:
            self.size = 0

    @property
    def uri(self):
        if self.kind == "vector" and self.layer:
            return "{}|layername={}".format(self.path, self.layer)
        if self.kind == "raster" and self.layer:
            return "GPKG:{}:{}".format(self.path, self.layer)
        return self.path

    @property
    def name(self):
        return self.layer or os.path.splitext(os.path.basename(self.path))[0]

    def __repr__(self):
        return "OutputItem({}, {}, {})".format(self.category, self.dtype, self.name)


def describe_dtype(dtype):
    base = dtype
    for pre in ("TMax_", "TMin_", "tMax_", "tMin_", "Tmax_", "Tmin_"):
        if dtype.startswith(pre):
            n, _u = DATA_TYPES.get(dtype[len(pre):], (dtype[len(pre):], ""))
            return "Time of {} {}".format("peak" if "ax" in pre else "minimum", n.lower())
    if dtype.startswith(("TDur", "tDur")):
        return "Duration of inundation"
    if dtype.startswith(("TInun", "tInun")):
        return "Time of first inundation"
    return DATA_TYPES.get(base, (base, ""))[0]


def parse_grid_name(stem, sim):
    """'<sim>_d_Max' -> ('d', 'Max'); '<sim>_h_001.00' -> ('h', '001.00');
    '<sim>_TMax_h' -> ('TMax_h', 'Max'). Returns None if not a result grid of `sim`."""
    if not stem.lower().startswith(sim.lower() + "_"):
        return None
    rest = stem[len(sim) + 1:]
    if not rest:
        return None
    m = re.match(r"^(?P<dtype>(?:[Tt](?:Max|Min|Dur|Inun)[A-Za-z0-9.]*_)?[A-Za-z][A-Za-z0-9]*)"
                 r"(?:_(?P<tag>Max|Min|max|min|\d+(?:[._]\d+)*))?$", rest)
    if not m:
        return None
    dtype, tag = m.group("dtype"), m.group("tag") or ""
    if dtype.lower().startswith(("tmax_", "tmin_", "tdur", "tinun")):
        tag = tag or "Max"
    return dtype, tag


def _files(folder, sim, depth=3):
    if not folder or not os.path.isdir(folder):
        return []
    out = []
    root_depth = folder.rstrip(os.sep).count(os.sep)
    for root, dirs, files in os.walk(folder):
        if root.count(os.sep) - root_depth >= depth:
            dirs[:] = []
        for f in files:
            if f.lower().startswith(sim.lower()):
                out.append(os.path.join(root, f))
    return sorted(out)


def scan_outputs(sim, results_dir, check_dir="", log_dir=""):
    """List every output of simulation `sim` as OutputItems."""
    from .qc import gpkg_layers
    items = []
    seen = set()

    def add(item):
        key = (item.path, item.layer)
        if key not in seen:
            seen.add(key)
            items.append(item)

    for path in _files(results_dir, sim):
        base = os.path.basename(path)
        stem, ext = os.path.splitext(base)
        ext = ext.lower()
        low = stem.lower()
        if ext in (".xmdf", ".dat", ".2dm") or (ext == ".nc" and parse_grid_name(stem, sim) is None):
            if ext == ".2dm":
                continue
            add(OutputItem(CAT_MESH, "mesh", "", "Mesh results ({})".format(ext[1:].upper()), path, "mesh"))
            continue
        if ext == ".csv":
            add(OutputItem(CAT_CSV, "csv", "", _csv_label(low), path, "csv"))
            continue
        if ext in (".tif", ".tiff", ".asc", ".flt", ".nc"):
            parsed = parse_grid_name(stem, sim)
            if parsed:
                dtype, tag = parsed
                cat = CAT_MAX if tag in SUMMARY_TAGS or dtype.lower().startswith(("tmax", "tmin", "tdur", "tinun")) \
                    else CAT_TIME
                lbl = describe_dtype(dtype) + ("" if cat == CAT_MAX and tag in ("Max", "max") else
                                               (" - minimum" if tag in ("Min", "min") else
                                                ("" if cat == CAT_MAX else " @ {} h".format(tag.replace("_", ".")))))
                add(OutputItem(cat, dtype, tag, lbl, path, "raster"))
            continue
        if ext in VECTOR_EXT:
            if ext == ".gpkg":
                for lyr in gpkg_layers(path) or []:
                    add(OutputItem(CAT_PLOT, _vector_key(lyr), "", _vector_label(lyr), path, "vector", lyr))
            else:
                add(OutputItem(CAT_PLOT, _vector_key(stem), "", _vector_label(stem), path, "vector"))
    for path in _files(check_dir, sim, depth=2):
        stem, ext = os.path.splitext(os.path.basename(path))
        ext = ext.lower()
        if ext in (".shp", ".mif"):
            add(OutputItem(CAT_CHECK, "check", "", describe_check_file(path) or stem, path, "vector"))
        elif ext in (".tif", ".asc", ".flt"):
            dt = "DEM_Z" if "dem_z" in stem.lower() else ("DEM_M" if "dem_m" in stem.lower() else "check")
            add(OutputItem(CAT_CHECK, dt, "", describe_check_file(path) or stem, path, "raster"))
        elif ext == ".gpkg":
            for lyr in gpkg_layers(path) or []:
                add(OutputItem(CAT_CHECK, "check", "", describe_check_file(lyr) or lyr, path, "vector", lyr))
    for path in _files(log_dir, sim, depth=1):
        stem, ext = os.path.splitext(os.path.basename(path))
        if "messages" in stem.lower() and ext.lower() in (".shp", ".mif", ".gpkg"):
            if ext.lower() == ".gpkg":
                for lyr in gpkg_layers(path) or []:
                    add(OutputItem(CAT_MSG, "messages", "", "Messages ({})".format(lyr[-1:]), path, "vector", lyr))
            else:
                add(OutputItem(CAT_MSG, "messages", "", "Messages", path, "vector"))
    order = {c: i for i, c in enumerate(CATEGORIES)}
    items.sort(key=lambda it: (order.get(it.category, 99), _dtype_order(it.dtype), it.tag, it.name))
    return items


_DTYPE_ORDER = ["d", "h", "V", "q", "Z0", "ZAEM1", "ZUK0"]


def _dtype_order(dtype):
    return _DTYPE_ORDER.index(dtype) if dtype in _DTYPE_ORDER else len(_DTYPE_ORDER)


def _csv_label(low):
    for key, lbl in (("_mb2d", "2D mass balance"), ("_mb1d", "1D mass balance"), ("_mb", "Mass balance"),
                     ("_po", "2D plot output (PO) time series"), ("_1d_h", "1D water levels"),
                     ("_1d_q", "1D flows"), ("_1d_v", "1D velocities"), ("_1d_mmh", "1D max water levels"),
                     ("_1d_ccA", "1D channel capacity"), ("_rlp", "Reporting locations"),
                     ("_1d_", "1D time series")):
        if key.lower() in low:
            return lbl
    return "Time series"


_VECTOR_KEYS = [("_plot_p", "PLOT_P", "Plot output points"), ("_plot_l", "PLOT_L", "Plot output lines"),
                ("_plot_r", "PLOT_R", "Plot output regions"), ("_1d_cca_l", "1d_ccA_L", "1D channel capacity"),
                ("_1d_mmh_p", "1d_mmH_P", "1D maximum water levels"), ("_1d_mmq_p", "1d_mmQ_P", "1D maximum flows"),
                ("_1d_mmv_p", "1d_mmV_P", "1D maximum velocities"), ("_ts_p", "TS_P", "Time-series points"),
                ("_ts_l", "TS_L", "Time-series lines"), ("_rl_", "RL", "Reporting locations")]


def _vector_key(name):
    low = name.lower()
    for k, key, _l in _VECTOR_KEYS:
        if k in low or low.endswith(k.rstrip("_")):
            return key
    return "vector"


def _vector_label(name):
    low = name.lower()
    for k, _key, lbl in _VECTOR_KEYS:
        if k in low or low.endswith(k.rstrip("_")):
            return lbl
    return name


def list_result_simulations(results_dir, log_dir=""):
    """Simulation names: from .tlf logs first, then from *_d_Max / *_h_Max grids and .xmdf files."""
    from .logs import list_simulations
    names = list(list_simulations(log_dir))
    if results_dir and os.path.isdir(results_dir):
        pats = [os.path.join(results_dir, "**", "*_h_Max.*"), os.path.join(results_dir, "**", "*_d_Max.*"),
                os.path.join(results_dir, "**", "*.xmdf")]
        for pat in pats:
            for p in glob.glob(pat, recursive=True):
                stem = os.path.splitext(os.path.basename(p))[0]
                stem = re.sub(r"_(h|d)_Max$", "", stem)
                if stem not in names:
                    names.append(stem)
    return names


def mesh_for(item):
    """The .2dm mesh that goes with an XMDF / DAT result (same folder, same name) or ''."""
    if item.kind != "mesh" or item.path.lower().endswith(".nc"):
        return ""
    stem = os.path.splitext(item.path)[0]
    cands = [stem + ".2dm"] + glob.glob(os.path.join(os.path.dirname(item.path), "*.2dm"))
    for c in cands:
        if os.path.isfile(c):
            return c
    return ""
