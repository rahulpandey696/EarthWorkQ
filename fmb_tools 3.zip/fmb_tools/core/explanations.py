# -*- coding: utf-8 -*-
"""
Plain-language explanations used by the guided "Essentials" lists and the Help
tab. Written for FMB tools (not copied from the TUFLOW manual) - every entry
links to the manual page of the command for the authoritative wording.

FILE_OVERVIEW   what each control file is for and where it sits in a model
GROUP_EXPLAIN   one line per Essentials group
EXPLAIN         one to three sentences per Essentials command: what it does,
                when you need it and what a typical value looks like
"""

FILE_OVERVIEW = {
    "TCF": "The TUFLOW Control File is the master file of a simulation - the one you run. It chooses the solver "
           "and hardware, points to every other control file and database, sets the simulation times and says "
           "which results are written, where and how often.",
    "TGC": "The Geometry Control File builds the 2D grid: where it sits, the cell size, which cells are active, "
           "ground elevations and roughness (material) IDs. Commands are applied top to bottom, so later layers "
           "overwrite earlier ones.",
    "TBC": "The Boundary Control File places the 2D boundary conditions - inflows, water level boundaries, "
           "source areas and rainfall. The time series behind each boundary live in the BC database (.csv).",
    "ECF": "The ESTRY Control File sets up the 1D network (channels, culverts, pipes, pits and nodes), its "
           "cross-sections, 1D boundaries, 1D timestep and 1D output.",
    "TEF": "The Event File defines each design event (for example 1% AEP, 2 h storm) as a block of commands. "
           "Selecting an event with -e1 / -e2 switches applies that block, so one model can run many events.",
    "QCF": "The Quadtree Control File (HPC only) lets the 2D mesh use smaller cells where detail matters and "
           "larger cells elsewhere, controlled by nesting-level polygons.",
    "TRFC": "The Rainfall Control File turns rain-gauge time series into spatially varying rainfall grids "
            "(by inverse-distance weighting, polygons or a triangulation) that TUFLOW applies to the 2D domain.",
    "TOC": "The Operational Controls File gives 1D structures (gates, pumps, weirs, breaches ...) rules that change "
           "their behaviour during the run, e.g. open a gate when a water level is reached.",
    "TESF": "The External Stress File applies wind stress to the 2D domain from a global wind time series or "
            "from spatially interpolated wind inputs.",
    "TSCF": "The SWMM Control File links an EPA SWMM 1D network (.inp) to the 2D domain, including inlet "
            "connections and SWMM output.",
    "ADCF": "The Advection Dispersion Control File models the transport of constituents (pollutants, salinity, "
            "tracers) carried by the flow, with their own boundary and parameter databases.",
}

GROUP_EXPLAIN = {
    ("TCF", "Solver & hardware"): "Which solver runs the model and on what hardware.",
    ("TCF", "Units, GIS & projection"): "Units, GIS file format and the projection all inputs are checked against.",
    ("TCF", "Control files & databases"): "Links to the other control files and the CSV databases the model reads.",
    ("TCF", "Scenarios & events"): "Default scenario / event names and user variables.",
    ("TCF", "Time control"): "When the simulation starts and stops and how the timestep is controlled.",
    ("TCF", "2D solution settings"): "Wet/dry, turbulence and initial-water-level settings of the 2D solver.",
    ("TCF", "Output"): "Where results, logs and check files go, which results are written and how often.",
    ("TGC", "Domain extent"): "Position, rotation and size of the 2D grid.",
    ("TGC", "Active area (codes)"): "Which cells take part in the calculation.",
    ("TGC", "Elevation (Zpts)"): "Ground levels from a DEM, points, TINs and break lines.",
    ("TGC", "Materials & roughness"): "Material IDs that link each cell to Manning's n in the materials file.",
    ("TGC", "Soils / infiltration"): "Soil IDs that link cells to infiltration parameters in the soils file.",
    ("TGC", "Structures & losses"): "Bridges, culverts and energy losses represented in the 2D grid.",
    ("TGC", "Initial water level & SGS"): "Starting water levels and sub-grid sampling resolution.",
    ("TBC", "Boundaries"): "Where water enters or leaves the 2D domain.",
    ("TBC", "Global (direct) rainfall"): "One rainfall hyetograph applied over the whole 2D domain, with losses.",
    ("ECF", "Network"): "1D channels, pipes, pits, manholes and their tables.",
    ("ECF", "Boundaries & initial conditions"): "1D boundaries and starting water levels.",
    ("ECF", "Time & output"): "1D timestep, output and mapping of 1D results.",
    ("ECF", "Structures"): "Methods used for culvert, bridge and structure losses.",
    ("QCF", "Quadtree"): "Base cell size, extent and the nesting polygons that refine the mesh.",
    ("TRFC", "Rainfall"): "How gauge rainfall is spread across the model.",
    ("TESF", "Wind"): "Wind inputs and how they are interpolated.",
    ("TSCF", "SWMM"): "The SWMM network, inlets and SWMM-specific settings.",
    ("ADCF", "Advection dispersion"): "Databases and outputs of the transport model.",
    ("TOC", "Operational structures"): "A control block for one structure and its settings.",
    ("TEF", "Event block"): "One named event and the commands / text replacements it applies.",
}

EXPLAIN = {
    # ------------------------------------------------------------------ TCF
    ("TCF", "Solution Scheme"):
        "Chooses the 2D solver. HPC is the explicit, adaptive-timestep solver that runs on CPU or GPU and is used "
        "for most new models; CLASSIC is the original implicit fixed-timestep solver (the default if omitted).",
    ("TCF", "Hardware"):
        "Runs the HPC solver on the CPU (default) or on an NVIDIA GPU. GPU runs are usually much faster but need "
        "a GPU licence and Solution Scheme == HPC.",
    ("TCF", "GPU Device IDs"):
        "Which GPU(s) to use when the computer has more than one, numbered from 0. Several IDs split the model "
        "across GPUs. Normally set with the -pu batch switch instead.",
    ("TCF", "CPU Threads"):
        "Number of CPU threads the HPC solver uses when Hardware == CPU (default 4). More threads are faster up "
        "to the number of physical cores.",
    ("TCF", "SGS"):
        "Sub-Grid Sampling: each cell stores how volume and flow width vary with depth, sampled from the DEM. "
        "This keeps small channels and slopes conveying realistically with larger cells (HPC only).",
    ("TCF", "SGS Sample Target Distance"):
        "Spacing of the elevation samples used by SGS inside each cell. Leave it out to let TUFLOW choose from "
        "the DEM resolution; a smaller distance is more detailed but slower to pre-process.",
    ("TCF", "Quadtree Control File"):
        "Points to a .qcf file to use a Quadtree mesh (variable cell sizes) instead of a single fixed cell size. "
        "HPC only.",
    ("TCF", "Defaults"):
        "Makes TUFLOW use the default settings of an older release (e.g. PRE 2023) so an old model gives the same "
        "results. Leave it out for new models so the current, recommended defaults apply.",
    ("TCF", "Units"):
        "Unit system of all inputs and outputs. METRIC (m, m3/s) is the default; US Customary / Imperial use "
        "feet and cfs.",
    ("TCF", "GIS Format"):
        "File format TUFLOW writes check files and GIS results in: GPKG (recommended for QGIS), SHP or MIF.",
    ("TCF", "Spatial Database"):
        "One GeoPackage that holds the input layers. Once set, commands can use just the layer name instead of "
        "a full path, which keeps control files short.",
    ("TCF", "GPKG Projection"):
        "A GeoPackage layer whose coordinate system every GeoPackage input must match. TUFLOW does not reproject "
        "inputs, so this catches layers in the wrong projection.",
    ("TCF", "SHP Projection"):
        "A .prj file that defines the model projection for Shapefile inputs; each input's .prj is compared "
        "with it.",
    ("TCF", "GIS Projection Check"):
        "What happens when an input layer's projection differs from the model projection: ERROR stops the run "
        "(default and safest), WARNING only writes a message.",
    ("TCF", "Tutorial Model"):
        "Lets the official tutorial models run without a licence. Only works with the tutorial datasets.",
    ("TCF", "Demo Model"):
        "Runs in free demo mode, which is limited to small models (a maximum number of cells and 1D elements). "
        "Useful for learning and testing without a licence.",
    ("TCF", "Geometry Control File"):
        "Path to the .tgc file that builds the 2D grid (extent, active cells, elevations, materials). Required "
        "for every 2D model.",
    ("TCF", "BC Control File"):
        "Path to the .tbc file that places the 2D boundaries (inflows, levels, rainfall). Required for 2D models.",
    ("TCF", "BC Database"):
        "The CSV table that links each boundary name to its time series file and columns. Boundary layers refer "
        "to it by the Name attribute.",
    ("TCF", "Read Materials File"):
        "CSV (or .tmf) listing each material ID with its Manning's n and optional losses and depth-varying "
        "roughness. The IDs come from Set Mat / Read GIS Mat in the TGC.",
    ("TCF", "Read Soils File"):
        "A .tsoilf file with infiltration parameters (e.g. initial/continuing loss, Green-Ampt, Horton) per "
        "soil ID used by Set Soil / Read GIS Soil.",
    ("TCF", "ESTRY Control File"):
        "Path to the .ecf that adds a 1D network (channels, culverts, pipes). Use AUTO to read 1D commands from "
        "a file with the same name as the TCF.",
    ("TCF", "Rainfall Control File"):
        "Path to a .trfc that interpolates rainfall from gauges into grids. Only needed for spatially varying "
        "rainfall from point gauges.",
    ("TCF", "External Stress File"):
        "Path to a .tesf that applies wind stress, typically for large lakes, estuaries and coastal models.",
    ("TCF", "SWMM Control File"):
        "Path to a .tscf that couples an EPA SWMM pipe network to the 2D domain (alternative to ESTRY for "
        "urban drainage).",
    ("TCF", "AD Control File"):
        "Path to an .adcf that turns on advection-dispersion (water quality / tracer transport).",
    ("TCF", "Read File"):
        "Reads commands from another text file (.trd) as if they were written here - useful for sharing blocks "
        "of commands between models.",
    ("TCF", "Model Scenarios"):
        "Scenario names used when the run is started without -s switches, e.g. 5m | EXG. Command-line switches "
        "override them.",
    ("TCF", "Model Events"):
        "Event names used when the run is started without -e switches, e.g. 1p | 2hr. Command-line switches "
        "override them.",
    ("TCF", "Set Variable <name>"):
        "Defines a user variable, e.g. Set Variable CELL == 5, that can be used anywhere as <<CELL>>. Handy "
        "inside If Scenario blocks to change several values at once.",
    ("TCF", "Start Time"):
        "Simulation start time in hours. Usually 0 so it lines up with the start of the boundary time series.",
    ("TCF", "End Time"):
        "Simulation end time in hours. Allow time after the peak so the flood recedes and peak results are "
        "captured everywhere.",
    ("TCF", "Timestep"):
        "Timestep in seconds. Classic uses it as a fixed step - typically 1/4 to 1/2 of the cell size in metres. "
        "HPC treats it as the first step only and then adapts it automatically.",
    ("TCF", "Timestep Maximum"):
        "Upper limit for the HPC adaptive timestep (default Auto). Rarely needed; can help keep outputs smooth "
        "in very deep, slow models.",
    ("TCF", "Timestep Minimum"):
        "Lower limit for the HPC adaptive timestep. If the timestep keeps falling below it the run is treated "
        "as unstable and stopped, which saves waiting for a model that is going wrong.",
    ("TCF", "Control Number Factor"):
        "Scales the HPC stability limits (Courant, diffusion and wave numbers). Values below 1.0 give smaller, "
        "safer timesteps; the default 1.0 suits most models.",
    ("TCF", "End After Maximum"):
        "Ends the run early once maximum levels have stopped rising (within a tolerance) for the given number "
        "of hours, instead of always running to End Time (see the manual for the tolerance value).",
    ("TCF", "Cell Wet/Dry Depth"):
        "Depth below which a cell is treated as dry (default 0.002 m). Use about 0.0002 m for direct rainfall "
        "models so thin sheet flow is not lost.",
    ("TCF", "Viscosity Formulation"):
        "Turbulence (eddy viscosity) model: WU (HPC default), SMAGORINSKY (Classic default), CONSTANT or "
        "NONNEWTONIAN for mud flows. Affects how momentum spreads, e.g. at flow contractions.",
    ("TCF", "Viscosity Coefficient"):
        "Coefficient(s) for the chosen viscosity formulation. The defaults are suitable for most models - change "
        "only with a sensitivity test.",
    ("TCF", "Set IWL"):
        "Initial water level (m) applied to all wet cells at the start, e.g. a normal lake or tide level. AUTO "
        "sets it from the boundary levels at the start time.",
    ("TCF", "Read GIS IWL"):
        "Polygons that give different starting water levels in different areas (for example a lake and a river).",
    ("TCF", "Latitude"):
        "Latitude in degrees used to include the Coriolis force. Only matters for very large coastal or ocean "
        "models.",
    ("TCF", "Instability Water Level"):
        "Classic solver: if any water level rises above this value the run is flagged as unstable and stopped. "
        "Set it well above the highest possible flood level.",
    ("TCF", "Log Folder"):
        "Folder (relative to the TCF) for the .tlf log, the HPC log and the messages layer. 'log' keeps them "
        "next to the runs folder.",
    ("TCF", "Output Folder"):
        "Folder for all map, time-series and mass-balance results. Using ~s1~ / ~e1~ in the path keeps "
        "results of different scenarios and events apart.",
    ("TCF", "Write Check Files"):
        "Writes the check layers (elevations, materials, codes, boundary locations ...) to this folder. Always "
        "review them before trusting results.",
    ("TCF", "Map Output Format"):
        "Formats for map results: XMDF (mesh, animations in QGIS), TIF / ASC / FLT (grids for GIS), NC "
        "(NetCDF) and others. List several separated by spaces.",
    ("TCF", "Map Output Data Types"):
        "Which results are written, e.g. h (level), d (depth), V (velocity), q (unit flow), Z0 (velocity x "
        "depth hazard), n (Manning's n).",
    ("TCF", "Map Output Interval"):
        "Seconds between map outputs (time-step results). Short intervals give smoother animations but large "
        "result files; the maximums are tracked regardless.",
    ("TCF", "Start Map Output"):
        "Time in hours when map output begins; earlier times are skipped to keep files smaller.",
    ("TCF", "Time Series Output Interval"):
        "Seconds between time-series outputs at plot output (PO) points and lines and for 1D results.",
    ("TCF", "Read GIS PO"):
        "Plot-output points and lines (2d_po) where TUFLOW records hydrographs of level, flow, velocity etc. "
        "Put them at gauges, road crossings and key structures.",
    ("TCF", "Grid Output Cell Size"):
        "Cell size of TIF / ASC / FLT result grids. If left out TUFLOW picks a size from the 2D cell size; set "
        "it to match your mapping requirements.",
    ("TCF", "Map Cutoff Depth"):
        "Cells shallower than this depth (m) are left blank in map outputs, which removes very shallow rainfall "
        "flow from flood maps.",
    ("TCF", "Maximums and Minimums"):
        "Tracks the peak (and optionally minimum) of each result every timestep, so the _Max outputs capture "
        "true peaks. Default: ON MAXIMUMS ONLY.",
    ("TCF", "Mass Balance Output"):
        "Writes mass-balance CSV files (volume in, out, stored and cumulative mass error). Check them - large "
        "mass errors point to instability. Default ON.",
    ("TCF", "Mass Balance Output Interval"):
        "Seconds between mass-balance records, if you want them more or less often than the default.",
    ("TCF", "Event File"):
        "Path to the .tef file that defines the events. Place it near the end of the TCF so event blocks can "
        "override earlier commands.",
    # ------------------------------------------------------------------ TGC
    ("TGC", "Read GIS Location"):
        "A 2d_loc line whose start point sets the grid origin and whose direction sets the grid orientation. "
        "The easiest way to position a rotated grid.",
    ("TGC", "Origin"):
        "X, Y of the grid's lower-left corner - an alternative to Read GIS Location for an unrotated grid.",
    ("TGC", "Orientation Angle"):
        "Rotation of the grid in degrees, used together with Origin. Aligning the grid with the main flow "
        "direction can reduce the number of cells.",
    ("TGC", "Grid Size (X,Y)"):
        "Length and width of the 2D domain in metres. Make it cover the whole floodplain; cells outside the "
        "code polygon are switched off anyway.",
    ("TGC", "Cell Size"):
        "2D cell size in metres. Smaller cells show more detail but run time rises roughly with the cube of the "
        "refinement (four times the cells and a smaller timestep).",
    ("TGC", "Set Code"):
        "Sets the code of every cell: 0 = inactive, 1 = active. The usual pattern is Set Code == 0 followed by "
        "Read GIS Code to switch on the model area.",
    ("TGC", "Read GIS Code"):
        "2d_code polygon(s) whose Code attribute switches cells on (1) or off (0), defining the active model "
        "area.",
    ("TGC", "Read Grid Code"):
        "A raster (TIF/ASC/FLT) of code values, as an alternative to code polygons.",
    ("TGC", "Set Zpt"):
        "Gives every Zpt a background elevation before the DEM is read, so any gaps in the DEM get a known "
        "value (often a high number so gaps are obvious in the check files).",
    ("TGC", "Read Grid Zpts"):
        "Reads ground levels from a DEM raster onto the cell centres, sides and corners (Zpts). The main source "
        "of elevations in most models.",
    ("TGC", "Read GIS Zpts"):
        "Points (2d_zpt) that set elevations at individual Zpts, optionally only raising (MAX) or lowering (MIN) "
        "the existing value.",
    ("TGC", "Read TIN Zpts"):
        "Samples a triangulated surface (TIN) onto the Zpts - useful when the terrain comes from a design model.",
    ("TGC", "Read GIS Z Shape"):
        "Lines and polygons (2d_zsh) that modify elevations: embankments, levees, channels, break lines. Options "
        "such as RIDGE (only raise) and GULLY (only lower) control how they are applied.",
    ("TGC", "Read GIS Z HX Line"):
        "Sets the elevations of the 2D cells along a 1D/2D HX link line, usually the bank tops of a 1D channel.",
    ("TGC", "Read GIS Variable Z Shape"):
        "Z shapes that change during the simulation, e.g. a levee breach or dam failure growing over time.",
    ("TGC", "Create TIN Zpts"):
        "Builds a TIN from points and lines (2d_ztin) and samples it onto the Zpts - for designed surfaces such "
        "as a new channel or platform.",
    ("TGC", "Set Mat"):
        "Default material ID for every cell. Must come before Read GIS Mat, which then overwrites it inside the "
        "polygons.",
    ("TGC", "Read GIS Mat"):
        "2d_mat polygons whose Material attribute (an ID in the materials file) sets the roughness - e.g. roads, "
        "grass, buildings, dense vegetation.",
    ("TGC", "Read Grid Mat"):
        "A raster of material IDs, e.g. from a land-use classification, as an alternative to polygons.",
    ("TGC", "Set Soil"):
        "Default soil ID (from the soils file) for every cell - the starting point for infiltration.",
    ("TGC", "Read GIS Soil"):
        "Polygons that assign soil IDs, so infiltration varies across the catchment.",
    ("TGC", "Read Grid Soil"):
        "A raster of soil IDs, as an alternative to soil polygons.",
    ("TGC", "Read GIS FC Shape"):
        "Flow-constriction shapes (2d_fcsh) that represent bridges and culverts in 2D by blocking flow and "
        "adding losses on the cells they cover.",
    ("TGC", "Read GIS Layered FC Shape"):
        "Layered flow constrictions (2d_lfcsh): up to three layers - under the deck, the deck and the rail - "
        "each with its own blockage and loss. The usual way to model a bridge in 2D.",
    ("TGC", "Read GIS BG Shape"):
        "Bridge geometry (2d_bg) - deck levels and loss tables applied to the cells under a bridge.",
    ("TGC", "Read GIS FLC"):
        "Adds a form-loss coefficient to cells (e.g. for obstructions not captured by the elevation data), which "
        "removes energy in proportion to velocity squared.",
    ("TGC", "Read GIS WrF"):
        "Weir factor applied to cell sides where flow goes over a crest (embankments, roads) to adjust how much "
        "flow passes.",
    ("TGC", "Set IWL"):
        "Initial water level for all cells, applied through the geometry rather than the TCF.",
    ("TGC", "Read GIS IWL"):
        "Polygons with starting water levels, e.g. a full reservoir or a lake at normal level.",
    ("TGC", "Read Grid IWL"):
        "A raster of starting water levels, e.g. from a previous simulation's results.",
    ("TGC", "SGS Sample Distance"):
        "Distance between elevation samples taken from DEM / TIN inputs for sub-grid sampling. "
        "Smaller values capture more detail at the cost of pre-processing time.",
    # ------------------------------------------------------------------ TBC
    ("TBC", "BC Database"):
        "A boundary database only for these boundaries - leave it out to use the one set in the TCF.",
    ("TBC", "Read GIS BC"):
        "2d_bc lines and points: HT (water level vs time), QT (flow vs time), HQ (rating curve outlet) and "
        "others. The Name attribute points to a row in the BC database.",
    ("TBC", "Read GIS SA"):
        "Source-area polygons (2d_sa) that add a flow hydrograph to cells inside each polygon, starting with the "
        "lowest - a common way to add sub-catchment inflows.",
    ("TBC", "Read GIS RF"):
        "Rainfall polygons (2d_rf) that apply a rainfall time series (mm) to all cells inside, optionally "
        "scaled by factors.",
    ("TBC", "Global Rainfall BC"):
        "Name of a rainfall boundary in the BC database applied to every active cell - the standard direct "
        "rainfall (rain-on-grid) approach.",
    ("TBC", "Global Rainfall Area Factor"):
        "Multiplier on the global rainfall (default 1.0), e.g. an areal reduction factor.",
    ("TBC", "Global Rainfall Initial Loss"):
        "Rainfall depth (mm) lost before runoff starts, applied to the global rainfall.",
    ("TBC", "Global Rainfall Continuing Loss"):
        "Rainfall rate (mm/h) lost continuously after the initial loss is satisfied.",
    # ------------------------------------------------------------------ ECF
    ("ECF", "Read GIS Network"):
        "The main 1d_nwk layer: channels, culverts, pipes and bridges with their type, inverts, sizes and "
        "roughness. Channels connect at nodes created at their ends.",
    ("ECF", "Read GIS Node"):
        "1d_nwk points that define nodes explicitly, e.g. storage nodes or nodes with a set elevation-area "
        "table.",
    ("ECF", "Read GIS Table Links"):
        "1d_xs lines that link cross-section (or other) tables in CSV files to the channels they cross.",
    ("ECF", "XS Database"):
        "A CSV database of cross-sections, so table links can refer to named entries in one file instead of "
        "many separate CSVs.",
    ("ECF", "Read GIS Pits"):
        "Pit (inlet) points that capture surface water from the 2D domain into the pipe network.",
    ("ECF", "Pit Inlet Database"):
        "CSV of inlet capture curves (flow vs depth) referenced by pit type, controlling how much surface flow "
        "each pit can take.",
    ("ECF", "Depth Discharge Database"):
        "CSV of depth-discharge relationships referenced by name from 1D elements, a more general way to give "
        "pits or structures a rating.",
    ("ECF", "Read GIS Manhole"):
        "Manhole layer that sets manhole type and energy losses where pipes join; without it TUFLOW can create "
        "manholes automatically.",
    ("ECF", "Read Operating Controls File"):
        "Path to a .toc file with operating rules for gates, pumps, weirs and breaches.",
    ("ECF", "BC Database"):
        "A boundary database only for the 1D boundaries - leave it out to use the TCF one.",
    ("ECF", "Read GIS BC"):
        "1d_bc points on nodes: inflows (QT), water levels (HT) or rating curves (HQ) at 1D boundaries, and "
        "links to 2D (SX / HX).",
    ("ECF", "Set IWL"):
        "Initial water level for all 1D nodes.",
    ("ECF", "Read GIS IWL"):
        "A layer that sets initial water levels at individual 1D nodes.",
    ("ECF", "Timestep"):
        "1D timestep in seconds. It is often half the 2D timestep or less for short culverts and pipes, "
        "because short 1D elements need small steps to stay stable.",
    ("ECF", "Output Interval"):
        "Seconds between 1D time-series outputs (levels, flows, velocities at nodes and channels).",
    ("ECF", "Output Folder"):
        "Folder for the 1D results if different from the TCF Output Folder.",
    ("ECF", "Write Check Files"):
        "Folder for the 1D check layers (network, nodes, tables, connections to 2D).",
    ("ECF", "Read GIS WLL"):
        "Water level lines (1d_wll) drawn across 1D channels so 1D results can be mapped as flood extents "
        "and depths alongside the 2D results.",
    ("ECF", "Read GIS WLL Points"):
        "Points that give extra control of how 1D results are mapped along the water level lines.",
    ("ECF", "Culvert Flow"):
        "Selects the method used to calculate culvert flow regimes (inlet / outlet control). The default suits "
        "most models.",
    ("ECF", "Structure Losses"):
        "Whether structure energy loss coefficients are adjusted during the run for approach and departure "
        "velocities (ADJUST) or kept as entered (FIX).",
    ("ECF", "Bridge Flow"):
        "Selects the calculation method for 1D bridges (Method B is the default).",
    # ------------------------------------------------------------------ QCF
    ("QCF", "Base Cell Size"):
        "The largest (level 1) cell size of the Quadtree mesh; each nesting level halves it. Defaults to the TGC "
        "Cell Size.",
    ("QCF", "Model Origin and Extent"):
        "Whether the Quadtree mesh extent is worked out automatically (Auto) or taken from the TGC grid (TGC).",
    ("QCF", "Orientation Angle"):
        "Rotation of the Quadtree mesh: taken from the TGC, optimised automatically, or a set angle in degrees.",
    ("QCF", "Read GIS Nesting"):
        "2d_qnl polygons whose nesting level sets where cells are refined (level 2 = half size, level 3 = "
        "quarter size ...). Put fine cells along channels and around structures.",
    ("QCF", "Quadtree Mesh Processing Method"):
        "FAST (default) builds the mesh quickly; Memory Efficient uses less RAM for very large meshes.",
    # ------------------------------------------------------------------ TRFC
    ("TRFC", "RF Interpolation Method"):
        "How gauge rainfall is spread between gauges: IDW (inverse distance weighting), POLYGON (each polygon "
        "takes one gauge) or TIN (linear interpolation over triangles).",
    ("TRFC", "Read GIS RF Point"):
        "Rain-gauge points; each gauge's name links to its rainfall time series in the BC database.",
    ("TRFC", "Read GIS RF Polygons"):
        "Polygons assigning a gauge to each area, used with the POLYGON method.",
    ("TRFC", "Read GIS RF Triangles"):
        "A user-defined triangulation between gauges, used with the TIN method.",
    ("TRFC", "RF Grid Cell Size"):
        "Cell size of the rainfall grids TUFLOW creates from the gauges; much coarser than the 2D cells is fine.",
    ("TRFC", "RF Grid Format"):
        "Format of the rainfall grids written for checking (ASC, FLT, NC or TIF).",
    ("TRFC", "IDW Exponent"):
        "Power used in inverse distance weighting (default 2). Higher values give nearby gauges more weight.",
    # ------------------------------------------------------------------ TESF
    ("TESF", "Global Wind BC"):
        "One wind speed / direction time series (from the BC database) applied over the whole model.",
    ("TESF", "Read GIS Wind Point"):
        "Wind stations as points; their time series are interpolated across the model.",
    ("TESF", "Read GIS Wind Poly"):
        "Polygons that each take one wind time series.",
    ("TESF", "Grid Interpolation Method"):
        "How point / polygon wind inputs are spread onto the model: inverse distance weighting or polygons.",
    # ------------------------------------------------------------------ TSCF
    ("TSCF", "Read SWMM"):
        "The EPA SWMM .inp file with the pipe network, junctions, storages and inlets.",
    ("TSCF", "Read GIS SWMM Inlet Usage"):
        "Layer that places SWMM inlets on the 2D surface and links them to their SWMM junctions, controlling "
        "where surface water can enter the pipes.",
    ("TSCF", "Output Folder"):
        "Folder for the SWMM results and report files.",
    ("TSCF", "SWMM Iterations"):
        "Number of 1D/2D exchange iterations per step (default 1). More iterations can help stability at busy "
        "inlets.",
    # ------------------------------------------------------------------ ADCF
    ("ADCF", "AD BC Database"):
        "CSV database of concentration boundaries - the constituent concentration carried in with each inflow.",
    ("ADCF", "AD Global Database"):
        "CSV of the parameters of each constituent (e.g. dispersion coefficients and decay).",
    ("ADCF", "Write Mass"):
        "Writes the total mass of each constituent in the model over time, useful to check mass conservation.",
    # ------------------------------------------------------------------ TOC
    ("TOC", "Define Control"):
        "Starts a control block for one structure (gate, pump, weir, orifice, breach ...) named by its 1D ID. "
        "Everything until End Define applies to that structure.",
    ("TOC", "Pump Capacity"):
        "Pump flow rate, either a fixed value or the name of a head-discharge curve.",
    ("TOC", "Gate Type"):
        "Shape and movement of the gate: vertical underflow (sluice), vertical overflow or horizontal "
        "(single / double).",
    ("TOC", "Gate Opening"):
        "How open the gate is: CLOSE, OPEN, NO CHANGE or an opening height (or percentage), usually set inside "
        "If rules that react to water levels.",
    ("TOC", "End Define"):
        "Closes the control block started with Define ... Control.",
    # ------------------------------------------------------------------ TEF
    ("TEF", "Define Event"):
        "Starts an event block. The name is what you pass with -e1 / -e2 in the batch file, e.g. 1p or 2hr.",
    ("TEF", "BC Event Source"):
        "Text replacement for the BC database: every occurrence of the placeholder text (e.g. ~AEP~) is "
        "replaced by the event value, so one database row serves every event.",
    ("TEF", "End Time"):
        "An event-specific end time (hours), e.g. longer for longer storm durations.",
    ("TEF", "End Define"):
        "Closes the event block. Every Define Event needs a matching End Define.",
}


def explain(ftype, key, tip=""):
    """Brief explanation of an Essentials command (falls back to its tip)."""
    return EXPLAIN.get((ftype, key)) or tip or ""


def missing():
    """Essentials entries without an explanation (used by the tests)."""
    from .essentials import ESSENTIALS
    out = []
    for ft, groups in ESSENTIALS.items():
        for g, cmds in groups:
            if (ft, g) not in GROUP_EXPLAIN:
                out.append((ft, g))
            for key, *_r in cmds:
                if not EXPLAIN.get((ft, key)):
                    out.append((ft, key))
    return out


_BY_SPEC = None


def explain_spec(spec):
    """Explanation for a catalog command (any file type) if it is one of the Essentials, else ''."""
    global _BY_SPEC
    if spec is None:
        return ""
    if _BY_SPEC is None:
        from .catalog import catalog
        _BY_SPEC = {}
        for (ft, key), text in EXPLAIN.items():
            s, _c = catalog().match(ft, key)
            if s is not None:
                _BY_SPEC.setdefault((s.ftype, s.name), text)
    return _BY_SPEC.get((spec.ftype, spec.name), "")
