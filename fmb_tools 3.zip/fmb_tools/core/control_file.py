# -*- coding: utf-8 -*-
"""
Control-file document model: read existing TUFLOW control files (keeping every
line, comment and block), edit them as a list of entries, and write them back
with consistent formatting.
"""
import io
import os
import re

from .catalog import catalog, BLOCK_OPEN, BLOCK_MID, BLOCK_CLOSE

COMMENT_CHARS = ("!", "#")


class Entry(object):
    """One line of a control file."""
    __slots__ = ("kind", "lhs", "value", "comment", "enabled", "spec", "choices")

    def __init__(self, kind="command", lhs="", value="", comment="", enabled=True, spec=None, choices=None):
        self.kind = kind            # command | comment | blank
        self.lhs = lhs
        self.value = value
        self.comment = comment
        self.enabled = enabled
        self.spec = spec
        self.choices = choices or []

    def copy(self):
        return Entry(self.kind, self.lhs, self.value, self.comment, self.enabled, self.spec, list(self.choices))

    @property
    def key(self):
        return self.spec.key if self.spec else " ".join(self.lhs.split())

    @property
    def block_role(self):
        """'open' | 'mid' | 'close' | None"""
        if self.kind != "command" or not self.enabled:
            return None
        k = " ".join((self.spec.key if self.spec is not None else self.lhs).lower().split())
        if k in BLOCK_CLOSE:
            return "close"
        if k in BLOCK_MID or k.startswith("else if"):
            return "mid"
        if k.startswith(BLOCK_OPEN):
            if k.startswith("define") and not (k.startswith("define event") or k.startswith("define output zone")
                                               or k.endswith("control")):
                return None
            return "open"
        return None

    def __repr__(self):
        return "Entry({} {!r} == {!r})".format(self.kind, self.lhs, self.value)


def split_comment(line):
    """Split 'cmd == value ! comment' -> ('cmd == value', 'comment')."""
    for i, ch in enumerate(line):
        if ch in COMMENT_CHARS:
            return line[:i], line[i + 1:].strip()
    return line, ""


def parse_line(ftype, raw):
    text = raw.rstrip("\r\n")
    stripped = text.strip()
    if not stripped:
        return Entry("blank")
    if stripped[0] in COMMENT_CHARS:
        body = stripped[1:].strip()
        # a commented-out command ("! Read GIS Code == ...") is kept as a disabled command
        if "==" in body and not body.startswith(("!", "#", "-", "=")):
            code, comment = split_comment(body)
            e = _command_entry(ftype, code)
            if e.spec is not None:
                e.enabled = False
                e.comment = comment
                return e
        return Entry("comment", comment=stripped[1:].rstrip())
    code, comment = split_comment(stripped)
    e = _command_entry(ftype, code)
    e.comment = comment
    return e


def _command_entry(ftype, code):
    code = code.strip()
    lhs, sep, value = code.partition("==")
    lhs = " ".join(lhs.split())
    value = value.strip()
    spec, choices = catalog().match(ftype, lhs)
    return Entry("command", lhs=lhs, value=value, spec=spec, choices=choices or [])


class ControlFile(object):
    def __init__(self, ftype, path=""):
        self.ftype = ftype
        self.path = path
        self.entries = []
        self.encoding = "utf-8"

    # -- reading --------------------------------------------------------
    @classmethod
    def read(cls, ftype, path):
        cf = cls(ftype, path)
        data = None
        for enc in ("utf-8", "cp1252", "latin-1"):
            try:
                with io.open(path, "r", encoding=enc) as fh:
                    data = fh.read()
                cf.encoding = enc
                break
            except UnicodeDecodeError:
                continue
        cf.set_text(data or "")
        return cf

    def set_text(self, text):
        self.entries = [parse_line(self.ftype, ln) for ln in text.splitlines()]
        # drop trailing blanks
        while self.entries and self.entries[-1].kind == "blank":
            self.entries.pop()

    # -- writing --------------------------------------------------------
    def to_text(self, indent="    ", align=True):
        lines = []
        depth = 0
        width = 0
        if align:
            for e in self.entries:
                if e.kind == "command" and e.value != "" and e.block_role is None:
                    width = max(width, len(e.lhs))
            width = min(width, 44)
        for e in self.entries:
            role = e.block_role
            if role in ("close", "mid"):
                depth = max(0, depth - 1)
            pad = indent * depth
            if e.kind == "blank":
                lines.append("")
            elif e.kind == "comment":
                lines.append(pad + "!" + (e.comment if e.comment.startswith((" ", "!", "-", "=")) else " " + e.comment))
            else:
                body = e.lhs
                has_value = e.value != "" or (e.spec is not None and e.spec.has_value)
                if has_value:
                    lhs = e.lhs.ljust(width) if (align and role is None) else e.lhs
                    body = "{} == {}".format(lhs, e.value).rstrip()
                if e.comment:
                    body = "{}  ! {}".format(body, e.comment)
                if not e.enabled:
                    body = "! " + body
                lines.append(pad + body)
            if role in ("open", "mid"):
                depth += 1
        return "\n".join(lines) + "\n"

    def save(self, path=None, newline="\r\n"):
        path = path or self.path
        if not path:
            raise ValueError("No file path set for {}".format(self.ftype))
        folder = os.path.dirname(path)
        if folder and not os.path.isdir(folder):
            os.makedirs(folder)
        with io.open(path, "w", encoding=self.encoding or "utf-8", newline=newline) as fh:
            fh.write(self.to_text())
        self.path = path
        return path

    # -- queries ------------------------------------------------------------
    def commands(self, include_disabled=False):
        return [e for e in self.entries if e.kind == "command" and (e.enabled or include_disabled)]

    def find(self, key):
        """All enabled entries whose command key matches `key` (case-insensitive)."""
        k = key.lower()
        return [e for e in self.commands() if e.key.lower() == k or e.lhs.lower() == k]

    def value(self, key, default=None):
        """Last active value of a command (TUFLOW uses the last occurrence)."""
        hits = self.find(key)
        return hits[-1].value if hits else default

    def set_value(self, key, value, comment=None, create=True):
        hits = self.find(key)
        if hits:
            hits[-1].value = value
            if comment is not None:
                hits[-1].comment = comment
            return hits[-1]
        if not create:
            return None
        spec, ch = catalog().match(self.ftype, key)
        e = Entry("command", lhs=spec.build_lhs(ch) if spec else key, value=value,
                  comment=comment or "", spec=spec, choices=ch or [])
        self.entries.append(e)
        return e

    def remove(self, key):
        k = key.lower()
        self.entries = [e for e in self.entries if not (e.kind == "command" and e.key.lower() == k)]

    def block_errors(self):
        """Check If/Define blocks are balanced. Returns list of (line_no, message)."""
        stack, errs = [], []
        for i, e in enumerate(self.entries, 1):
            r = e.block_role
            if r == "open":
                stack.append((i, e.lhs))
            elif r == "mid":
                if not stack:
                    errs.append((i, "'{}' without a matching If".format(e.lhs)))
            elif r == "close":
                if not stack:
                    errs.append((i, "'{}' without an opening block".format(e.lhs)))
                else:
                    opened = stack.pop()[1].lower()
                    closing = e.lhs.lower()
                    if closing == "end if" and not opened.startswith("if"):
                        errs.append((i, "'End If' closes '{}'".format(opened)))
                    if closing == "end define" and not opened.startswith("define"):
                        errs.append((i, "'End Define' closes '{}'".format(opened)))
        for ln, name in stack:
            errs.append((ln, "'{}' is never closed".format(name)))
        return errs


# ---------------------------------------------------------------------------
# path helpers
def split_value_paths(value):
    """Return file paths referenced in a value. Handles 'a | b', GPKG
    'db.gpkg >> layer && layer2', and optional '| number' suffixes."""
    out = []
    for part in [p.strip() for p in value.split("|")]:
        if not part:
            continue
        db, sep, layers = part.partition(">>")
        db = db.strip().strip('"')
        if sep:
            out.append((db, [l.strip() for l in re.split(r"&&|\|", layers) if l.strip()]))
        else:
            out.append((db, []))
    return out


def looks_like_path(text):
    t = text.strip().strip('"')
    if not t:
        return False
    if re.fullmatch(r"-?\d+(\.\d+)?", t):
        return False
    return bool(re.search(r"[\\/]|\.[A-Za-z0-9]{2,6}$", t))


def to_tuflow_path(target, relative_to_dir, forward_slash=False):
    """Make a path relative to the control file folder, TUFLOW style."""
    if not target:
        return target
    try:
        rel = os.path.relpath(target, relative_to_dir) if relative_to_dir else target
    except ValueError:            # different drive on Windows
        rel = target
    rel = rel.replace("/", "\\") if not forward_slash else rel.replace("\\", "/")
    return rel


def resolve_path(value_path, control_file_dir):
    p = value_path.strip().strip('"').replace("\\", os.sep).replace("/", os.sep)
    if not p:
        return p
    if os.path.isabs(p) or re.match(r"^[A-Za-z]:", value_path):
        return os.path.normpath(p)
    return os.path.normpath(os.path.join(control_file_dir or "", p))


TOKEN_RE = re.compile(r"~[se]\d?~|<<[^>]+>>", re.IGNORECASE)


def substitute_tokens(text, scenarios=None, events=None, variables=None):
    """Replace ~s1~/~e1~ style tokens and <<variables>>."""
    scenarios = scenarios or []
    events = events or []
    variables = variables or {}

    def rep(m):
        tok = m.group(0)
        low = tok.lower()
        if low.startswith("<<"):
            return str(variables.get(tok[2:-2].lower(), variables.get(tok[2:-2], tok)))
        kind = low[1]
        num = low[2:-1] or "1"
        lst = scenarios if kind == "s" else events
        idx = int(num) - 1
        return lst[idx] if 0 <= idx < len(lst) else tok
    return TOKEN_RE.sub(rep, text)
