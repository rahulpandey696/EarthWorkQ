# -*- coding: utf-8 -*-
"""
A TUFLOW model project: the TCF plus every control file it references,
the standard folder structure and the supporting databases.
"""
import csv
import io
import json
import os

from .catalog import FILE_TYPE_INFO, CONTROL_FILE_TYPES
from .control_file import ControlFile, Entry, resolve_path, to_tuflow_path, substitute_tokens
from .catalog import catalog

from .folders import DEFAULT_FOLDERS

STANDARD_FOLDERS = [os.path.join(*p.split("/")) for p in DEFAULT_FOLDERS]

BC_DBASE_HEADER = ["Name", "Source", "Column 1", "Column 2", "Add Col 1", "Mult Col 2", "Add Col 2", "Column 3", "Column 4"]
MATERIALS_HEADER = ["Material ID", "Manning's n", "Rainfall Loss Parameters", "Land Use Hazard ID",
                    "Storage Reduction Factor", "Fraction Impervious", "Comments"]
SOILS_TEMPLATE = ("! Soil ID, Method, parameters... (see manual section on infiltration)\n"
                  "! 1, GA, SAND\n")
PROJECT_STATE_FILE = ".fmb_tools.json"


class TuflowProject(object):
    def __init__(self, root="", name="model"):
        self.root = root
        self.name = name
        self.files = {}               # ftype -> ControlFile
        self.state = {"batch": {}, "exe": "", "events": [], "scenarios": []}

    # -- paths ----------------------------------------------------------
    @property
    def runs_dir(self):
        return os.path.join(self.root, "runs")

    @property
    def model_dir(self):
        return os.path.join(self.root, "model")

    @property
    def base_name(self):
        """Model name without ~s1~/~e1~ tokens - used for the child control files."""
        import re
        b = re.sub(r"~[se]\d?~", "", self.name)
        b = re.sub(r"[_\-]{2,}", "_", b).strip("_- ")
        return b or "model"

    def default_path(self, ftype):
        ext = FILE_TYPE_INFO[ftype][0]
        if ftype == "TCF":
            return os.path.join(self.runs_dir, self.name + ext)
        if ftype == "TEF":
            return os.path.join(self.model_dir, "event_file" + ext)
        return os.path.join(self.model_dir, self.base_name + ext)

    def tcf(self):
        return self.files.get("TCF")

    def dir_of(self, ftype):
        cf = self.files.get(ftype)
        path = cf.path if cf and cf.path else self.default_path(ftype)
        return os.path.dirname(path)

    # -- creation -----------------------------------------------------------
    def create_folders(self):
        made = []
        for f in STANDARD_FOLDERS:
            p = os.path.join(self.root, f)
            if not os.path.isdir(p):
                os.makedirs(p)
                made.append(p)
        return made

    def ensure(self, ftype):
        if ftype not in self.files:
            self.files[ftype] = ControlFile(ftype, self.default_path(ftype))
        return self.files[ftype]

    def link_child(self, ftype):
        """Make sure the parent file references the child control file."""
        cmd = FILE_TYPE_INFO[ftype][2]
        if not cmd:
            return
        parent = self.ensure("ECF" if ftype == "TOC" else "TCF")
        child = self.ensure(ftype)
        rel = to_tuflow_path(child.path, os.path.dirname(parent.path))
        if not parent.find(cmd):
            if ftype == "TEF":
                parent.entries.append(Entry("blank"))
            parent.set_value(cmd, rel)

    def new_from_template(self, opts):
        """Create a starter model. `opts` is a dict from the Project tab."""
        name = opts.get("name") or self.name
        self.name = name
        self.files = {}
        tcf = self.ensure("TCF")
        tgc = self.ensure("TGC")
        tbc = self.ensure("TBC")
        tdir = os.path.dirname(tcf.path)
        rel = lambda p: to_tuflow_path(p, tdir)

        def add(cf, key, value="", comment=""):
            spec, ch = catalog().match(cf.ftype, key)
            cf.entries.append(Entry("command", lhs=spec.build_lhs(ch) if spec else key, value=str(value),
                                    comment=comment, spec=spec, choices=ch or []))

        def note(cf, text):
            cf.entries.append(Entry("comment", comment=" " + text))

        def blank(cf):
            cf.entries.append(Entry("blank"))

        note(tcf, "=" * 70)
        note(tcf, "TUFLOW Control File - {}".format(name))
        note(tcf, "Created with FMB tools (QGIS plugin)")
        note(tcf, "=" * 70)
        blank(tcf)
        note(tcf, "--- Solver ---")
        add(tcf, "Solution Scheme", opts.get("solver", "HPC"))
        if opts.get("solver", "HPC").upper().startswith("HPC"):
            add(tcf, "Hardware", opts.get("hardware", "GPU"))
            if opts.get("sgs", True):
                add(tcf, "SGS", "ON")
        if opts.get("quadtree"):
            add(tcf, "Quadtree Control File", rel(self.default_path("QCF")))
        blank(tcf)
        note(tcf, "--- GIS ---")
        gis_fmt = opts.get("gis_format", "GPKG")
        add(tcf, "GIS Format", gis_fmt)
        if opts.get("units", "METRIC") != "METRIC":
            add(tcf, "Units", opts["units"])
        if gis_fmt == "GPKG":
            db = opts.get("spatial_db") or os.path.join(self.model_dir, "gis", self.base_name + ".gpkg")
            add(tcf, "Spatial Database", rel(db))
            if opts.get("projection_layer"):
                add(tcf, "GPKG Projection", opts["projection_layer"])
        elif opts.get("projection_layer"):
            add(tcf, "SHP Projection", rel(opts["projection_layer"]))
        blank(tcf)
        note(tcf, "--- Control files & databases ---")
        add(tcf, "Geometry Control File", rel(tgc.path))
        add(tcf, "BC Control File", rel(tbc.path))
        add(tcf, "BC Database", rel(os.path.join(self.root, "bc_dbase", "bc_dbase.csv")))
        add(tcf, "Read Materials File", rel(os.path.join(self.model_dir, "materials.csv")))
        if opts.get("one_d"):
            self.ensure("ECF")
            add(tcf, "ESTRY Control File", rel(self.files["ECF"].path))
        blank(tcf)
        note(tcf, "--- Time ---")
        add(tcf, "Start Time", opts.get("start", 0))
        add(tcf, "End Time", opts.get("end", 3))
        add(tcf, "Timestep", opts.get("timestep", 1))
        blank(tcf)
        note(tcf, "--- 2D settings ---")
        if opts.get("direct_rainfall"):
            add(tcf, "Cell Wet/Dry Depth", "0.0002", "recommended for direct rainfall")
        blank(tcf)
        note(tcf, "--- Output ---")
        add(tcf, "Log Folder", "log")
        add(tcf, "Output Folder", rel(os.path.join(self.root, "results")) + "\\")
        add(tcf, "Write Check Files", rel(os.path.join(self.root, "check")) + "\\")
        add(tcf, "Map Output Format", opts.get("map_format", "XMDF TIF"))
        add(tcf, "Map Output Data Types", opts.get("map_types", "h d V q Z0"))
        add(tcf, "Map Output Interval", opts.get("map_interval", 300))
        add(tcf, "Time Series Output Interval", opts.get("ts_interval", 60))
        if opts.get("events"):
            blank(tcf)
            note(tcf, "--- Events (keep last) ---")
            self.ensure("TEF")
            add(tcf, "Event File", rel(self.files["TEF"].path))

        # -- TGC
        tg = os.path.dirname(tgc.path)
        note(tgc, "TUFLOW Geometry Control File - {}".format(name))
        blank(tgc)
        if opts.get("loc_layer"):
            add(tgc, "Read GIS Location", opts["loc_layer"])
        elif opts.get("origin"):
            add(tgc, "Origin", opts["origin"])
        add(tgc, "Grid Size (X,Y)", opts.get("grid_size", ""))
        add(tgc, "Cell Size", opts.get("cell_size", ""))
        blank(tgc)
        add(tgc, "Set Code", "0")
        add(tgc, "Read GIS Code", opts.get("code_layer", ""))
        blank(tgc)
        add(tgc, "Set Zpt", "100")
        add(tgc, "Read Grid Zpts", to_tuflow_path(opts["dem"], tg) if opts.get("dem") else "")
        blank(tgc)
        add(tgc, "Set Mat", "1")
        add(tgc, "Read GIS Mat", opts.get("mat_layer", ""))

        # -- TBC
        note(tbc, "TUFLOW Boundary Control File - {}".format(name))
        blank(tbc)
        add(tbc, "Read GIS BC", opts.get("bc_layer", ""))
        if opts.get("direct_rainfall"):
            add(tbc, "Global Rainfall BC", "RAIN", "name of the rainfall row in bc_dbase.csv")

        if opts.get("one_d"):
            ecf = self.files["ECF"]
            note(ecf, "ESTRY (1D) Control File - {}".format(name))
            blank(ecf)
            add(ecf, "Timestep", opts.get("timestep_1d", 1))
            add(ecf, "Read GIS Network", "")
            add(ecf, "Read GIS Table Links", "")
            add(ecf, "Output Interval", opts.get("ts_interval", 60))
        if opts.get("quadtree"):
            qcf = self.ensure("QCF")
            add(qcf, "Base Cell Size", opts.get("cell_size", ""))
            add(qcf, "Read GIS Nesting", "")
        if opts.get("events"):
            tef = self.files["TEF"]
            note(tef, "TUFLOW Event File")
            for ev in opts["events"]:
                blank(tef)
                add(tef, "Define Event", ev)
                add(tef, "BC Event Source", "~EVENT~ | {}".format(ev))
                add(tef, "End Define", "")
            self.state["events"] = list(opts["events"])
        return self

    def write_databases(self, overwrite=False, direct_rainfall=False):
        written = []
        bc = os.path.join(self.root, "bc_dbase", "bc_dbase.csv")
        if overwrite or not os.path.exists(bc):
            os.makedirs(os.path.dirname(bc), exist_ok=True)
            with io.open(bc, "w", newline="", encoding="utf-8") as fh:
                w = csv.writer(fh)
                w.writerow(BC_DBASE_HEADER)
                if direct_rainfall:
                    w.writerow(["RAIN", "rainfall_~EVENT~.csv", "Time", "Rainfall", "", "", "", "", ""])
            written.append(bc)
        mat = os.path.join(self.model_dir, "materials.csv")
        if overwrite or not os.path.exists(mat):
            os.makedirs(os.path.dirname(mat), exist_ok=True)
            with io.open(mat, "w", newline="", encoding="utf-8") as fh:
                w = csv.writer(fh)
                w.writerow(MATERIALS_HEADER)
                for row in ([1, 0.06, "", "", "", "", "Default / grass"],
                            [2, 0.035, "", "", "", "", "Road"],
                            [3, 0.1, "", "", "", "", "Dense vegetation"]):
                    w.writerow(row)
            written.append(mat)
        return written

    # -- load / save ----------------------------------------------------
    @classmethod
    def from_tcf(cls, tcf_path):
        tcf_path = os.path.abspath(tcf_path)
        runs = os.path.dirname(tcf_path)
        root = os.path.dirname(runs) if os.path.basename(runs).lower() == "runs" else runs
        name = os.path.splitext(os.path.basename(tcf_path))[0]
        prj = cls(root, name)
        prj.files["TCF"] = ControlFile.read("TCF", tcf_path)
        prj.discover_children()
        prj.load_state()
        return prj

    def discover_children(self, scenarios=None, events=None):
        """Open child control files referenced from the TCF (and the TOC from the ECF)."""
        missing = []
        order = [("TCF", t) for t in CONTROL_FILE_TYPES if t not in ("TCF", "TOC")] + [("ECF", "TOC")]
        for parent_t, child_t in order:
            parent = self.files.get(parent_t)
            if parent is None:
                continue
            cmd = FILE_TYPE_INFO[child_t][2]
            hits = parent.find(cmd)
            if not hits:
                continue
            val = hits[-1].value.split("|")[0].strip()
            if cmd == "Quadtree Control File" and val.lower() == "single level":
                continue
            if cmd.startswith("ESTRY") and "auto" in hits[-1].lhs.lower():
                val = os.path.splitext(os.path.basename(parent.path))[0] + ".ecf"
            val = substitute_tokens(val, scenarios or self.state.get("scenarios"), events or self.state.get("events"))
            path = resolve_path(val, os.path.dirname(parent.path))
            if os.path.isfile(path):
                self.files[child_t] = ControlFile.read(child_t, path)
            else:
                self.files[child_t] = ControlFile(child_t, path)
                missing.append(path)
        return missing

    def save_all(self):
        saved = []
        for ftype, cf in self.files.items():
            if not cf.path:
                cf.path = self.default_path(ftype)
            saved.append(cf.save())
        self.save_state()
        return saved

    def state_path(self):
        return os.path.join(self.runs_dir if os.path.isdir(self.runs_dir) else self.root, PROJECT_STATE_FILE)

    def save_state(self):
        try:
            with io.open(self.state_path(), "w", encoding="utf-8") as fh:
                json.dump(self.state, fh, indent=2)
        except (IOError, OSError):
            pass

    def load_state(self):
        try:
            with io.open(self.state_path(), "r", encoding="utf-8") as fh:
                self.state.update(json.load(fh))
        except (IOError, OSError, ValueError):
            pass

    # -- facts used by QC ---------------------------------------------------
    def events_defined(self):
        tef = self.files.get("TEF")
        if not tef:
            return []
        return [e.value.strip() for e in tef.find("Define Event") if e.value.strip()]

    # -- names for dropdowns --------------------------------------------------
    def _values_of(self, keys):
        out = []
        for cf in self.files.values():
            for e in cf.commands():
                if e.key in keys:
                    for v in e.value.split("|"):
                        v = v.strip()
                        if v and v not in out:
                            out.append(v)
        return out

    def scenario_names(self):
        names = self._values_of(("If Scenario", "Else If Scenario", "Model Scenarios"))
        for slot in (self.state.get("batch") or {}).get("scenarios", []) or []:
            for v in slot or []:
                if v not in names:
                    names.append(v)
        return names

    def event_names(self):
        names = list(self.events_defined())
        for v in self._values_of(("If Event", "Else If Event", "Model Events")):
            if v not in names:
                names.append(v)
        for slot in (self.state.get("batch") or {}).get("events", []) or []:
            for v in slot or []:
                if v not in names:
                    names.append(v)
        return names

    def _csv_rows(self, key, ftype="TCF"):
        cf = self.files.get(ftype)
        val = cf.value(key) if cf else None
        if not val:
            return []
        path = resolve_path(substitute_tokens(val.split("|")[0], self.state.get("scenarios"),
                                              self.state.get("events")), os.path.dirname(cf.path))
        if not os.path.isfile(path):
            return []
        try:
            with io.open(path, newline="", encoding="utf-8-sig", errors="replace") as fh:
                return [r for r in csv.reader(fh) if r and r[0].strip() and not r[0].strip().startswith(("!", "#"))]
        except (IOError, OSError):
            return []

    def bc_names(self):
        rows = self._csv_rows("BC Database")
        return [(r[0].strip(), r[1].strip() if len(r) > 1 else "") for r in rows[1:]]

    def material_ids(self):
        out = []
        for r in self._csv_rows("Read Materials File"):
            try:
                mid = str(int(float(r[0])))
            except ValueError:
                continue                      # header row
            label = "n = {}".format(r[1].strip()) if len(r) > 1 and r[1].strip() else ""
            note = r[-1].strip() if len(r) > 2 else ""
            if note and not note.replace(".", "", 1).replace("-", "", 1).isdigit():
                label = (label + "  " + note).strip()
            out.append((mid, label))
        return out

    def names(self, kind):
        """Values offered in dropdowns: 'scenarios', 'events' -> [str]; 'bc', 'materials' -> [(value, label)]."""
        if kind == "scenarios":
            return self.scenario_names()
        if kind == "events":
            return self.event_names()
        if kind == "bc":
            return self.bc_names()
        if kind == "materials":
            return self.material_ids()
        return []

    def output_dirs(self):
        """Return (results_dir, check_dir, log_dir) resolved from the TCF."""
        tcf = self.tcf()
        base = os.path.dirname(tcf.path) if tcf and tcf.path else self.runs_dir
        sc, ev = self.state.get("scenarios"), self.state.get("events")

        def r(key, default):
            v = tcf.value(key) if tcf else None
            v = substitute_tokens(v, sc, ev) if v else default
            return resolve_path(v, base)
        return r("Output Folder", os.path.join("..", "results")), \
            r("Write Check Files", os.path.join("..", "check")), \
            r("Log Folder", "log")
