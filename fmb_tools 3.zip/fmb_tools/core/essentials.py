# -*- coding: utf-8 -*-
"""
Curated "guided" layer on top of the full command catalog.

For each control file the most-used commands are grouped in the order they are
normally written, with a short tip (written for this plugin) and whether the
command is required for a typical model. Every other command of the manual is
still available from the "All commands" list in each tab.
"""

# (command key, level, suggested value, tip)
# level: "req" = required, "rec" = recommended, "opt" = optional
ESSENTIALS = {
    "TCF": [
        ("Solver & hardware", [
            ("Solution Scheme", "req", "HPC", "HPC is the modern adaptive-timestep solver. Classic is the older implicit scheme."),
            ("Hardware", "rec", "GPU", "GPU requires Solution Scheme == HPC and a GPU licence."),
            ("GPU Device IDs", "opt", "0", "Only needed with several GPUs. Numbering starts at 0."),
            ("CPU Threads", "opt", "4", "HPC on CPU only."),
            ("SGS", "rec", "ON", "Sub-Grid Sampling: better conveyance with coarser cells (HPC)."),
            ("SGS Sample Target Distance", "opt", "", "Sampling distance for SGS; leave blank for default."),
            ("Quadtree Control File", "opt", "", "Variable cell size mesh (HPC only)."),
            ("Defaults", "opt", "", "Backward compatibility with an older release. Leave out for new models."),
        ]),
        ("Units, GIS & projection", [
            ("Units", "opt", "METRIC", ""),
            ("GIS Format", "rec", "GPKG", "Format of check files and GIS outputs."),
            ("Spatial Database", "opt", "", "One GeoPackage that holds all input layers; lets you use layer names only."),
            ("GPKG Projection", "rec", "", "Projection reference layer for GeoPackage inputs."),
            ("SHP Projection", "opt", "", "Projection reference (.prj) for Shapefile inputs."),
            ("GIS Projection Check", "opt", "ERROR", ""),
            ("Tutorial Model", "opt", "", "Only for the official tutorial dataset."),
            ("Demo Model", "opt", "", "Free/demo mode for small models without a licence."),
        ]),
        ("Control files & databases", [
            ("Geometry Control File", "req", r"..\model\{model}.tgc", "2D geometry (.tgc)."),
            ("BC Control File", "req", r"..\model\{model}.tbc", "2D boundaries (.tbc)."),
            ("BC Database", "req", r"..\bc_dbase\bc_dbase.csv", "Boundary condition database (.csv)."),
            ("Read Materials File", "rec", r"..\model\materials.csv", "Manning's n and losses per material ID."),
            ("Read Soils File", "opt", r"..\model\soils.tsoilf", "Infiltration parameters."),
            ("ESTRY Control File", "opt", r"..\model\{model}.ecf", "1D network (.ecf)."),
            ("Rainfall Control File", "opt", "", "Gridded/gauge rainfall interpolation (.trfc)."),
            ("External Stress File", "opt", "", "Wind stress (.tesf)."),
            ("SWMM Control File", "opt", "", "1D EPA SWMM (.tscf)."),
            ("AD Control File", "opt", "", "Advection dispersion (.adcf)."),
            ("Read File", "opt", "", "Include commands from a .trd file."),
        ]),
        ("Scenarios & events", [
            ("Model Scenarios", "opt", "", "Default scenario names (overridden by -s batch switches)."),
            ("Model Events", "opt", "", "Default event names (overridden by -e batch switches)."),
            ("Set Variable <name>", "opt", "", "User variables, referenced as <<name>>."),
        ]),
        ("Time control", [
            ("Start Time", "req", "0", "Hours."),
            ("End Time", "req", "3", "Hours. Must be larger than Start Time."),
            ("Timestep", "req", "1", "Seconds. Classic: fixed timestep, ~1/4 to 1/2 of the cell size (m). HPC: initial timestep only."),
            ("Timestep Maximum", "opt", "", "HPC upper limit."),
            ("Timestep Minimum", "opt", "", "HPC lower limit - a run stops below it."),
            ("Control Number Factor", "opt", "", "HPC: <1 underclocks for extra stability."),
            ("End After Maximum", "opt", "", "Stop the run once peaks have passed."),
        ]),
        ("2D solution settings", [
            ("Cell Wet/Dry Depth", "rec", "0.0002", "Use 0.0002 m for direct rainfall models."),
            ("Viscosity Formulation", "opt", "", "HPC default is WU; Classic default is SMAGORINSKY."),
            ("Viscosity Coefficient", "opt", "", ""),
            ("Set IWL", "opt", "", "Initial water level for the whole 2D domain."),
            ("Read GIS IWL", "opt", "", "Spatially varying initial water level."),
            ("Latitude", "opt", "", "Coriolis - only for large coastal models."),
            ("Instability Water Level", "opt", "", "Classic: level that flags an instability."),
        ]),
        ("Output", [
            ("Log Folder", "rec", "log", ""),
            ("Output Folder", "req", r"..\results", "Use ~s1~ / ~e1~ sub-folders once scenarios/events are defined."),
            ("Write Check Files", "rec", r"..\check", "Folder (and optional prefix) for check files."),
            ("Map Output Format", "req", "XMDF TIF", "e.g. XMDF TIF NC."),
            ("Map Output Data Types", "req", "h d V q Z0", "h level, d depth, V velocity, q unit flow, Z0 hazard, n Manning's n..."),
            ("Map Output Interval", "req", "300", "Seconds."),
            ("Start Map Output", "opt", "", "Hours."),
            ("Time Series Output Interval", "rec", "60", "Seconds (PO lines/points)."),
            ("Read GIS PO", "rec", "", "Plot output locations (2d_po)."),
            ("Grid Output Cell Size", "opt", "", "Resolution of TIF/ASC outputs."),
            ("Map Cutoff Depth", "opt", "", "Hide results shallower than this depth."),
            ("Maximums and Minimums", "opt", "", ""),
            ("Mass Balance Output", "opt", "ON", ""),
            ("Mass Balance Output Interval", "opt", "", "Seconds."),
            ("Event File", "rec", r"..\model\event_file.tef", "Place last in the TCF."),
        ]),
    ],
    "TGC": [
        ("Domain extent", [
            ("Read GIS Location", "rec", "", "2d_loc line: origin and orientation of the grid."),
            ("Origin", "opt", "", "Alternative to Read GIS Location: X, Y of the lower-left corner."),
            ("Orientation Angle", "opt", "", ""),
            ("Grid Size (X,Y)", "req", "", "Domain length in X and Y (m)."),
            ("Cell Size", "req", "", "2D cell size (m)."),
        ]),
        ("Active area (codes)", [
            ("Set Code", "req", "0", "0 = inactive, 1 = active. Set everything first, then read the code polygon."),
            ("Read GIS Code", "req", "", "2d_code polygon marking active cells."),
            ("Read Grid Code", "opt", "", ""),
        ]),
        ("Elevation (Zpts)", [
            ("Set Zpt", "rec", "100", "A background elevation before reading the DEM."),
            ("Read Grid Zpts", "req", "", "DEM raster (TIF/ASC/FLT)."),
            ("Read GIS Zpts", "opt", "", ""),
            ("Read TIN Zpts", "opt", "", ""),
            ("Read GIS Z Shape", "opt", "", "Break lines / embankments / channels (2d_zsh)."),
            ("Read GIS Z HX Line", "opt", "", "Set HX cell elevations from 1D bank lines."),
            ("Read GIS Variable Z Shape", "opt", "", "Time-varying geometry, e.g. breaches."),
            ("Create TIN Zpts", "opt", "", ""),
        ]),
        ("Materials & roughness", [
            ("Set Mat", "req", "1", "Default material ID. Must come before Read GIS Mat."),
            ("Read GIS Mat", "rec", "", "2d_mat polygons with material IDs."),
            ("Read Grid Mat", "opt", "", ""),
        ]),
        ("Soils / infiltration", [
            ("Set Soil", "opt", "", ""),
            ("Read GIS Soil", "opt", "", ""),
            ("Read Grid Soil", "opt", "", ""),
        ]),
        ("Structures & losses", [
            ("Read GIS FC Shape", "opt", "", "Flow constrictions (2d_fcsh)."),
            ("Read GIS Layered FC Shape", "opt", "", "Bridges/culverts in 2D (2d_lfcsh)."),
            ("Read GIS BG Shape", "opt", "", "Bridge geometry (2d_bg)."),
            ("Read GIS FLC", "opt", "", ""),
            ("Read GIS WrF", "opt", "", "Weir factor."),
        ]),
        ("Initial water level & SGS", [
            ("Set IWL", "opt", "", ""),
            ("Read GIS IWL", "opt", "", ""),
            ("Read Grid IWL", "opt", "", ""),
            ("SGS Sample Distance", "opt", "", ""),
        ]),
    ],
    "TBC": [
        ("Boundaries", [
            ("BC Database", "opt", "", "Only if different from the TCF BC Database."),
            ("Read GIS BC", "rec", "", "2d_bc lines/points: HT, QT, HQ, SA ..."),
            ("Read GIS SA", "opt", "", "Source-area polygons (2d_sa)."),
            ("Read GIS RF", "opt", "", "Rainfall polygons (2d_rf)."),
        ]),
        ("Global (direct) rainfall", [
            ("Global Rainfall BC", "opt", "", "Name of the rainfall BC in the BC database."),
            ("Global Rainfall Area Factor", "opt", "", ""),
            ("Global Rainfall Initial Loss", "opt", "", "mm"),
            ("Global Rainfall Continuing Loss", "opt", "", "mm/h"),
        ]),
    ],
    "ECF": [
        ("Network", [
            ("Read GIS Network", "req", "", "1d_nwk channels, culverts, pipes."),
            ("Read GIS Node", "opt", "", "1d_nwk nodes (storage)."),
            ("Read GIS Table Links", "rec", "", "1d_xs cross-section links."),
            ("XS Database", "opt", "", ""),
            ("Read GIS Pits", "opt", "", ""),
            ("Pit Inlet Database", "opt", "", ""),
            ("Depth Discharge Database", "opt", "", ""),
            ("Read GIS Manhole", "opt", "", ""),
            ("Read Operating Controls File", "opt", "", "Gates, pumps, breaches (.toc)."),
        ]),
        ("Boundaries & initial conditions", [
            ("BC Database", "opt", "", ""),
            ("Read GIS BC", "opt", "", "1d_bc boundaries."),
            ("Set IWL", "opt", "", ""),
            ("Read GIS IWL", "opt", "", ""),
        ]),
        ("Time & output", [
            ("Timestep", "req", "", "1D timestep (s); often half the 2D timestep."),
            ("Output Interval", "rec", "60", ""),
            ("Output Folder", "opt", "", ""),
            ("Write Check Files", "opt", "", ""),
            ("Read GIS WLL", "opt", "", "Water level lines for mapping 1D results."),
            ("Read GIS WLL Points", "opt", "", ""),
        ]),
        ("Structures", [
            ("Culvert Flow", "opt", "", ""),
            ("Structure Losses", "opt", "", ""),
            ("Bridge Flow", "opt", "", ""),
        ]),
    ],
    "QCF": [
        ("Quadtree", [
            ("Base Cell Size", "rec", "", "Largest cell size; defaults to the TGC Cell Size."),
            ("Model Origin and Extent", "opt", "", ""),
            ("Orientation Angle", "opt", "", ""),
            ("Read GIS Nesting", "req", "", "2d_qnl polygons with nesting levels."),
            ("Quadtree Mesh Processing Method", "opt", "", ""),
        ]),
    ],
    "TRFC": [
        ("Rainfall", [
            ("RF Interpolation Method", "req", "IDW", ""),
            ("Read GIS RF Point", "opt", "", "Gauges (2d_rf points)."),
            ("Read GIS RF Polygons", "opt", "", ""),
            ("Read GIS RF Triangles", "opt", "", ""),
            ("RF Grid Cell Size", "opt", "", ""),
            ("RF Grid Format", "opt", "", ""),
            ("IDW Exponent", "opt", "", ""),
        ]),
    ],
    "TESF": [
        ("Wind", [
            ("Global Wind BC", "opt", "", ""),
            ("Read GIS Wind Point", "opt", "", ""),
            ("Read GIS Wind Poly", "opt", "", ""),
            ("Grid Interpolation Method", "opt", "", ""),
        ]),
    ],
    "TSCF": [
        ("SWMM", [
            ("Read SWMM", "req", "", "EPA SWMM .inp file."),
            ("Read GIS SWMM Inlet Usage", "opt", "", ""),
            ("Output Folder", "opt", "", ""),
            ("SWMM Iterations", "opt", "", ""),
        ]),
    ],
    "ADCF": [
        ("Advection dispersion", [
            ("AD BC Database", "req", "", ""),
            ("AD Global Database", "rec", "", ""),
            ("Write Mass", "opt", "", ""),
        ]),
    ],
    "TOC": [
        ("Operational structures", [
            ("Define Control", "req", "", "Start a control block; pick Gate / Pump / Weir ..."),
            ("Pump Capacity", "opt", "", ""),
            ("Gate Type", "opt", "", ""),
            ("Gate Opening", "opt", "", ""),
            ("End Define", "req", "", "Close the control block."),
        ]),
    ],
    "TEF": [
        ("Event block", [
            ("Define Event", "req", "", "Start an event block."),
            ("BC Event Source", "req", "", "<text in bc_dbase> | <replacement>"),
            ("End Time", "opt", "", "Event-specific duration."),
            ("End Define", "req", "", "Close the event block."),
        ]),
    ],
}

# Which QC facts each tab relies on (used by qc.py for 'required' checks)
REQUIRED = {ft: [c for _, cmds in groups for (c, lvl, _v, _t) in cmds if lvl == "req"]
            for ft, groups in ESSENTIALS.items()}

MAP_DATA_TYPES = [
    ("h", "Water level"), ("d", "Depth"), ("V", "Velocity"), ("q", "Unit flow"),
    ("Z0", "Hazard (Z0)"), ("ZUK0", "UK hazard"), ("n", "Manning's n"), ("MB1", "Mass error"),
    ("CI", "Cumulative infiltration"), ("BSS", "Bed shear stress"), ("SP", "Stream power"),
]
MAP_FORMATS = ["XMDF", "TIF", "NC", "ASC", "FLT", "GPKG", "COG", "DAT", "WRR", "TGO"]
